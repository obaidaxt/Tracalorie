import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '@core/guards/auth.guard';

const appRoutes: Routes = [
  {
    path: 'public',
    loadChildren: './modules/public/public.module#PublicModule'
  },
  {
    path: '',
    loadChildren: './modules/protected/protected.module#ProtectedModule',
    canActivate: [AuthGuard]
  },
  { path: '**', redirectTo: '' }
];

export const AppRouterModule = RouterModule.forRoot(appRoutes, {
  preloadingStrategy: PreloadAllModules
});
