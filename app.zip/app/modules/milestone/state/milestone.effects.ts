import { MilestoneCorrectionsEffects } from '@milestone/state/milestone-corrections/milestone-corrections.effects';
import { MilestoneShapesEffects } from '@milestone/state/milestone-shapes/milestone-shapes.effects';
import { MilestonesEffects } from '@milestone/state/milestones/milestones.effects';

export const milestoneEffects = [
  MilestonesEffects,
  MilestoneShapesEffects,
  MilestoneCorrectionsEffects
];
