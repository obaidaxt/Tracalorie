import * as fromRoot from '@root';
import * as fromMilestones from './milestones.reducer';
import { createSelector } from '@ngrx/store';
import { selectMilestoneState } from '@milestone/state/milestone.reducers';
import { milestoneStoredToDetails } from '@milestone/models/mapper/milestone-stored-to-details';
import { MilestoneDetails } from '@milestone/models/view/milestone-details';
import { selectMilestoneShapeEntities } from '@milestone/state/milestone-shapes';
import { selectUserEntities } from '@organization/state';
import { ApprovalUser } from '@milestone/models/view/approval-user';

export const selectMilestonesState = createSelector(
  selectMilestoneState,
  state => state.milestones
);

export const selectMilestoneLoadingStatus = createSelector(
  selectMilestonesState,
  fromMilestones.selectLoadingStatus
);

export const selectMilestoneLoadingError = createSelector(
  selectMilestonesState,
  fromMilestones.selectLoadingError
);

export const selectMilestoneFormStatus = createSelector(
  selectMilestonesState,
  fromMilestones.selectFormStatus
);

export const selectMilestoneFormError = createSelector(
  selectMilestonesState,
  fromMilestones.selectFormError
);

export const selectMilestoneApproveStatus = createSelector(
  selectMilestonesState,
  fromMilestones.selectApproveStatus
);

export const selectMilestoneApproveError = createSelector(
  selectMilestonesState,
  fromMilestones.selectApproveError
);

export const selectAllMilestones = createSelector(
  selectMilestonesState,
  fromMilestones.selectAll
);

export const selectMilestoneEntities = createSelector(
  selectMilestonesState,
  fromMilestones.selectEntities
);

export const selectSelectedMilestoneId = createSelector(
  selectMilestonesState,
  fromMilestones.selectSelectedMilestone
);

export const selectCurrentMilestones = createSelector(
  selectAllMilestones,
  fromRoot.selectCurrentProjectId,
  (milestones, projectId) =>
    milestones
      .filter(m => m.projectId === projectId)
      .sort((a, b) => b.createdAt.valueOf() - a.createdAt.valueOf())
);

export const selectMilestoneListDetails = createSelector(
  selectCurrentMilestones,
  selectMilestoneShapeEntities,
  (milestones, shapes) =>
    milestones.map<MilestoneDetails>(milestone =>
      milestoneStoredToDetails(milestone, shapes)
    )
);

export const selectCurrentMilestoneDetails = createSelector(
  selectMilestoneListDetails,
  selectSelectedMilestoneId,
  (milestones, id) => milestones.find(m => m.id === id)
);

export const selectCurrentMilestone = createSelector(
  selectMilestoneEntities,
  selectSelectedMilestoneId,
  (entities, id) => entities[id]
);
