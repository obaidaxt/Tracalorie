import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { MilestonesEffects } from './milestones.effects';

describe('MilestonesEffects', () => {
  let actions$: Observable<any>;
  let effects: MilestonesEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MilestonesEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(MilestonesEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
