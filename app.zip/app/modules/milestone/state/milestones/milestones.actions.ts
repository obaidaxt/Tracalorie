import { MilestoneApi } from '@milestone/models/api/milestone.api';
import { MilestonePost } from '@milestone/models/api/milestone.post';
import { Action } from '@ngrx/store';

export enum MilestonesActionTypes {
  Load = '[Project Details] Load Milestones',
  LoadSuccess = '[API] Load Milestones Success',
  LoadFailed = '[API] Load Milestones Failed',
  Added = '[Websocket] Milestone Added',
  Modified = '[Websocket] Milestone Modified',
  Removed = '[Websocket] Milestone Removed',
  Select = '[Project Info] Select Milestone',
  ResetForm = '[Milestone Form] Reset Form',
  Create = '[Milestone Form] Create Milestone',
  CreateSuccess = '[API] Create Milestone Success',
  CreateFailed = '[API] Create Milestone Failed',
  Update = '[Milestone Form] Update Milestone',
  UpdateSuccess = '[API] Update Milestone Success',
  UpdateFailed = '[API] Update Milestone Failed',
  Delete = '[Project Info] Delete Milestone',
  DeleteSuccess = '[API] Delete Milestone Success',
  DeleteFailed = '[API] Delete Milestone Failed',
  ResetApprove = '[Project Confirm] Reset Milestone Approve',
  Approve = '[Project Confirm] Approve Milestone',
  ApproveSuccess = '[API] Approve Milestone Success',
  ApproveFailed = '[API] Approve Milestone Failed'
}

export class LoadMilestones implements Action {
  readonly type = MilestonesActionTypes.Load;
  constructor(public projectId: number) {}
}

export class LoadMilestonesSuccess implements Action {
  readonly type = MilestonesActionTypes.LoadSuccess;
  constructor(public milestones: MilestoneApi[]) {}
}

export class LoadMilestonesFailed implements Action {
  readonly type = MilestonesActionTypes.LoadFailed;
  constructor(public error: string) {}
}

export class MilestoneAdded implements Action {
  readonly type = MilestonesActionTypes.Added;
  constructor(public milestone: MilestoneApi) {}
}

export class MilestoneModified implements Action {
  readonly type = MilestonesActionTypes.Modified;
  constructor(public changes: MilestoneApi) {}
}

export class MilestoneRemoved implements Action {
  readonly type = MilestonesActionTypes.Removed;
  constructor(public milestoneId: number) {}
}

export class ResetMilestoneForm implements Action {
  readonly type = MilestonesActionTypes.ResetForm;
  constructor() {}
}

export class SelectMilestone implements Action {
  readonly type = MilestonesActionTypes.Select;
  constructor(public milestoneId: number) {}
}

export class CreateMilestone implements Action {
  readonly type = MilestonesActionTypes.Create;
  constructor(public payload: MilestonePost) {}
}

export class CreateMilestoneSuccess implements Action {
  readonly type = MilestonesActionTypes.CreateSuccess;
  constructor(public milestone: MilestoneApi) {}
}

export class CreateMilestoneFailed implements Action {
  readonly type = MilestonesActionTypes.CreateFailed;
  constructor(public error: string) {}
}

export class UpdateMilestone implements Action {
  readonly type = MilestonesActionTypes.Update;
  constructor(public id: number, public changes: MilestonePost) {}
}

export class UpdateMilestoneSuccess implements Action {
  readonly type = MilestonesActionTypes.UpdateSuccess;
  constructor(public milestone: MilestoneApi) {}
}

export class UpdateMilestoneFailed implements Action {
  readonly type = MilestonesActionTypes.UpdateFailed;
  constructor(public error: string) {}
}

export class DeleteMilestone implements Action {
  readonly type = MilestonesActionTypes.Delete;
  constructor(public milestoneId: number) {}
}

export class DeleteMilestoneSuccess implements Action {
  readonly type = MilestonesActionTypes.DeleteSuccess;
  constructor(public milestoneId: number) {}
}

export class DeleteMilestoneFailed implements Action {
  readonly type = MilestonesActionTypes.DeleteFailed;
  constructor(public error: string) {}
}

export class ResetMilestoneApprove implements Action {
  readonly type = MilestonesActionTypes.ResetApprove;
  constructor() {}
}

export class ApproveMilestone implements Action {
  readonly type = MilestonesActionTypes.Approve;
  constructor(public milestoneId: number) {}
}

export class ApproveMilestoneSuccess implements Action {
  readonly type = MilestonesActionTypes.ApproveSuccess;
  constructor(public milestoneId: number, public userId: string) {}
}

export class ApproveMilestoneFailed implements Action {
  readonly type = MilestonesActionTypes.ApproveFailed;
  constructor(public error: string) {}
}

export type MilestonesActions =
  | LoadMilestones
  | LoadMilestonesSuccess
  | LoadMilestonesFailed
  | MilestoneAdded
  | MilestoneModified
  | MilestoneRemoved
  | SelectMilestone
  | ResetMilestoneForm
  | CreateMilestone
  | CreateMilestoneSuccess
  | CreateMilestoneFailed
  | UpdateMilestone
  | UpdateMilestoneSuccess
  | UpdateMilestoneFailed
  | DeleteMilestone
  | DeleteMilestoneSuccess
  | DeleteMilestoneFailed
  | ResetMilestoneApprove
  | ApproveMilestone
  | ApproveMilestoneSuccess
  | ApproveMilestoneFailed;
