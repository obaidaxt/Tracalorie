import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { MilestoneService } from '@milestone/services/milestone.service';
import { Observable, of } from 'rxjs';
import { Action, Store } from '@ngrx/store';
import {
  MilestonesActionTypes,
  LoadMilestones,
  LoadMilestonesSuccess,
  LoadMilestonesFailed,
  MilestoneAdded,
  MilestoneRemoved,
  MilestoneModified,
  CreateMilestone,
  CreateMilestoneSuccess,
  CreateMilestoneFailed,
  UpdateMilestone,
  UpdateMilestoneSuccess,
  UpdateMilestoneFailed,
  DeleteMilestone,
  DeleteMilestoneSuccess,
  DeleteMilestoneFailed,
  ApproveMilestone,
  ApproveMilestoneSuccess,
  ApproveMilestoneFailed
} from '@milestone/state/milestones/milestones.actions';
import {
  switchMap,
  map,
  catchError,
  takeUntil,
  filter,
  withLatestFrom
} from 'rxjs/operators';
import { DataChangeType } from '../../../../common/models/data-change-type';
import { RootState } from '@root';
import { selectUserId } from '@account/state';

@Injectable()
export class MilestonesEffects {
  constructor(
    private actions$: Actions,
    private milestoneService: MilestoneService,
    private store: Store<RootState>
  ) {}

  loadProjectId$: Observable<number> = this.actions$.pipe(
    ofType(MilestonesActionTypes.Load),
    map(({ projectId }: LoadMilestones) => projectId)
  );

  @Effect()
  load$: Observable<Action> = this.loadProjectId$.pipe(
    switchMap(projectId =>
      this.milestoneService.loadMilestones(projectId).pipe(
        map(milestones => new LoadMilestonesSuccess(milestones)),
        catchError(err => of(new LoadMilestonesFailed(err)))
      )
    )
  );

  @Effect()
  changes$: Observable<Action> = this.loadProjectId$.pipe(
    switchMap(projectId =>
      this.milestoneService.getMilestoneChanges(projectId).pipe(
        // TODO: takeuntil
        map(change => {
          switch (change.type) {
            case DataChangeType.Added: {
              return new MilestoneAdded(change.data);
            }
            case DataChangeType.Modified: {
              return new MilestoneModified(change.data);
            }
            case DataChangeType.Removed: {
              return new MilestoneRemoved(change.id);
            }
          }
        })
      )
    )
  );

  @Effect()
  create$: Observable<Action> = this.actions$.pipe(
    ofType(MilestonesActionTypes.Create),
    switchMap(({ payload }: CreateMilestone) =>
      this.milestoneService.createMilestone(payload).pipe(
        map(milestone => new CreateMilestoneSuccess(milestone)),
        catchError(err => of(new CreateMilestoneFailed(err)))
      )
    )
  );

  @Effect()
  update$: Observable<Action> = this.actions$.pipe(
    ofType(MilestonesActionTypes.Update),
    switchMap(({ id, changes }: UpdateMilestone) =>
      this.milestoneService.updateMilestone(id, changes).pipe(
        map(milestone => new UpdateMilestoneSuccess(milestone)),
        catchError(err => of(new UpdateMilestoneFailed(err)))
      )
    )
  );

  @Effect()
  delete$: Observable<Action> = this.actions$.pipe(
    ofType(MilestonesActionTypes.Delete),
    switchMap(({ milestoneId }: DeleteMilestone) =>
      this.milestoneService.deleteMilestone(milestoneId).pipe(
        map(() => new DeleteMilestoneSuccess(milestoneId)),
        catchError(err => of(new DeleteMilestoneFailed(err)))
      )
    )
  );

  @Effect()
  approve$: Observable<Action> = this.actions$.pipe(
    ofType(MilestonesActionTypes.Approve),
    switchMap(({ milestoneId }: ApproveMilestone) =>
      this.milestoneService.approveMilestone(milestoneId).pipe(
        withLatestFrom(this.store.select(selectUserId)),
        map(([_, userId]) => new ApproveMilestoneSuccess(milestoneId, userId)),
        catchError(err => of(new ApproveMilestoneFailed(err)))
      )
    )
  );
}
