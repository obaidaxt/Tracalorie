import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import { MilestonesActions, MilestonesActionTypes } from './milestones.actions';
import { MilestoneStored } from '@milestone/models/stored/milestone.stored';
import { LoadingStatus } from '../../../../common/models/loading-status';
import { milestoneApiToStored } from '@milestone/models/mapper/milestone-api-to-stored';
import { MilestoneApprovalApi } from '@milestone/models/api/milestone-approval.api';

export interface State extends EntityState<MilestoneStored> {
  loadingStatus: LoadingStatus;
  loadingError: string;
  formStatus: LoadingStatus;
  formError: string;
  approveStatus: LoadingStatus;
  approveError: string;
  selectedMilestone: number;
}

export const adapter = createEntityAdapter<MilestoneStored>({
  selectId: milestone => milestone.id
});

export const initialState: State = adapter.getInitialState({
  loadingStatus: LoadingStatus.Waiting,
  loadingError: null,
  formStatus: LoadingStatus.Waiting,
  formError: null,
  approveStatus: LoadingStatus.Waiting,
  approveError: null,
  selectedMilestone: null
});

export function reducer(
  state = initialState,
  action: MilestonesActions
): State {
  switch (action.type) {
    case MilestonesActionTypes.Load: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Loading
      };
    }

    case MilestonesActionTypes.LoadSuccess: {
      const milestones = action.milestones.map(milestoneApiToStored);
      return adapter.upsertMany(milestones, {
        ...state,
        loadingStatus: LoadingStatus.Completed,
        selectedMilestone:
          milestones.length === 0
            ? null
            : milestones.sort(
                (a, b) => b.createdAt.valueOf() - a.createdAt.valueOf()
              )[0].id
      });
    }

    case MilestonesActionTypes.LoadFailed: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Failed
      };
    }

    case MilestonesActionTypes.Added: {
      return adapter.addOne(milestoneApiToStored(action.milestone), state);
    }

    case MilestonesActionTypes.Modified: {
      return adapter.updateOne(
        {
          id: action.changes.id,
          changes: milestoneApiToStored(action.changes)
        },
        state
      );
    }

    case MilestonesActionTypes.Removed: {
      return adapter.removeOne(action.milestoneId, state);
    }

    case MilestonesActionTypes.Select: {
      return {
        ...state,
        selectedMilestone: action.milestoneId
      };
    }

    case MilestonesActionTypes.ResetForm: {
      return {
        ...state,
        formStatus: LoadingStatus.Waiting,
        formError: null
      };
    }

    case MilestonesActionTypes.Create: {
      return {
        ...state,
        formStatus: LoadingStatus.Loading
      };
    }

    case MilestonesActionTypes.CreateSuccess: {
      return adapter.addOne(milestoneApiToStored(action.milestone), {
        ...state,
        formStatus: LoadingStatus.Completed,
        selectedMilestone: action.milestone.id
      });
    }

    case MilestonesActionTypes.CreateFailed: {
      return {
        ...state,
        formStatus: LoadingStatus.Failed,
        formError: action.error
      };
    }

    case MilestonesActionTypes.Update: {
      return {
        ...state,
        formStatus: LoadingStatus.Loading
      };
    }

    case MilestonesActionTypes.UpdateSuccess: {
      return adapter.updateOne(
        {
          id: action.milestone.id,
          changes: milestoneApiToStored(action.milestone)
        },
        {
          ...state,
          formStatus: LoadingStatus.Completed
        }
      );
    }

    case MilestonesActionTypes.UpdateFailed: {
      return {
        ...state,
        formStatus: LoadingStatus.Failed,
        formError: action.error
      };
    }

    case MilestonesActionTypes.DeleteSuccess: {
      return adapter.removeOne(action.milestoneId, state);
    }

    case MilestonesActionTypes.ResetApprove: {
      return {
        ...state,
        approveStatus: LoadingStatus.Waiting,
        approveError: null
      };
    }

    case MilestonesActionTypes.Approve: {
      return {
        ...state,
        approveStatus: LoadingStatus.Loading
      };
    }

    case MilestonesActionTypes.ApproveSuccess: {
      const milestone = state.entities[action.milestoneId];
      if (!milestone) {
        return state;
      }
      return adapter.updateOne(
        {
          id: milestone.id,
          changes: {
            approvals: milestone.approvals.map<MilestoneApprovalApi>(
              a =>
                a.userId === action.userId
                  ? {
                      ...a,
                      approved: true
                    }
                  : a
            )
          }
        },
        {
          ...state,
          approveStatus: LoadingStatus.Completed
        }
      );
    }

    case MilestonesActionTypes.ApproveFailed: {
      return {
        ...state,
        approveStatus: LoadingStatus.Failed,
        approveError: action.error
      };
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
export const selectLoadingStatus = (state: State) => state.loadingStatus;
export const selectLoadingError = (state: State) => state.loadingError;
export const selectFormStatus = (state: State) => state.formStatus;
export const selectFormError = (state: State) => state.formError;
export const selectSelectedMilestone = (state: State) =>
  state.selectedMilestone;
export const selectApproveStatus = (state: State) => state.approveStatus;
export const selectApproveError = (state: State) => state.approveError;
