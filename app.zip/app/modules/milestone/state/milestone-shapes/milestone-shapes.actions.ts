import { MilestoneShapeApi } from '@milestone/models/api/milestone-shape.api';
import { MilestoneShapePost } from '@milestone/models/api/milestone-shop.post';
import { Action } from '@ngrx/store';

export enum MilestoneShapesActionTypes {
  Load = '[Admin] Load Milestone Shapes',
  LoadSuccess = '[API] Load Milestone Shapes Success',
  LoadFailed = '[API] Load Milestone Shapes Failed',
  LoadOwn = '[Overview] Load Own Milestone Shapes',
  LoadOwnSuccess = '[API] Load Own Milestone Shapes Success',
  LoadOwnFailed = '[API] Load Own Milestone Shapes Failed',
  Added = '[Websocket] Milestone Shape Added',
  Modified = '[Websocket] Milestone Shape Modified',
  Removed = '[Websocket] Milestone Shape Removed',
  ResetForm = '[Milestone Shape Form] Reset Form',
  Create = '[Milestone Shape Form] Create Milestone Shape',
  CreateSuccess = '[API] Create Milestone Shape Success',
  CreateFailed = '[API] Create Milestone Shape Failed',
  Update = '[Milestone Shape Form] Update Milestone Shape',
  UpdateSuccess = '[API] Update Milestone Shape Success',
  UpdateFailed = '[API] Update Milestone Shape Failed',
  Delete = '[Milestone Shape Overview] Delete Milestone Shape',
  DeleteSuccess = '[API] Delete Milestone Shape Success',
  DeleteFailed = '[API] Delete Milestone Shape Failed'
}

export class LoadMilestoneShapes implements Action {
  readonly type = MilestoneShapesActionTypes.Load;
  constructor() {}
}

export class LoadMilestoneShapesSuccess implements Action {
  readonly type = MilestoneShapesActionTypes.LoadSuccess;
  constructor(public shapes: MilestoneShapeApi[]) {}
}

export class LoadMilestoneShapesFailed implements Action {
  readonly type = MilestoneShapesActionTypes.LoadFailed;
  constructor(public error: string) {}
}

export class LoadOwnMilestoneShapes implements Action {
  readonly type = MilestoneShapesActionTypes.LoadOwn;
}

export class LoadOwnMilestoneShapesSuccess implements Action {
  readonly type = MilestoneShapesActionTypes.LoadOwnSuccess;
  constructor(public shapes: MilestoneShapeApi[]) {}
}

export class LoadOwnMilestoneShapesFailed implements Action {
  readonly type = MilestoneShapesActionTypes.LoadOwnFailed;
  constructor(public error: string) {}
}

export class MilestoneShapeAdded implements Action {
  readonly type = MilestoneShapesActionTypes.Added;
  constructor(public shape: MilestoneShapeApi) {}
}

export class MilestoneShapeModified implements Action {
  readonly type = MilestoneShapesActionTypes.Modified;
  constructor(public shape: MilestoneShapeApi) {}
}

export class MilestoneShapeRemoved implements Action {
  readonly type = MilestoneShapesActionTypes.Removed;
  constructor(public shapeId: number) {}
}

export class ResetMilestoneShapeForm implements Action {
  readonly type = MilestoneShapesActionTypes.ResetForm;
  constructor() {}
}

export class CreateMilestoneShape implements Action {
  readonly type = MilestoneShapesActionTypes.Create;
  constructor(public payload: MilestoneShapePost) {}
}

export class CreateMilestoneShapeSuccess implements Action {
  readonly type = MilestoneShapesActionTypes.CreateSuccess;
  constructor(public shape: MilestoneShapeApi) {}
}

export class CreateMilestoneShapeFailed implements Action {
  readonly type = MilestoneShapesActionTypes.CreateFailed;
  constructor(public error: string) {}
}

export class UpdateMilestoneShape implements Action {
  readonly type = MilestoneShapesActionTypes.Update;
  constructor(public milestoneId: number, public payload: MilestoneShapePost) {}
}

export class UpdateMilestoneShapeSuccess implements Action {
  readonly type = MilestoneShapesActionTypes.UpdateSuccess;
  constructor(public shape: MilestoneShapeApi) {}
}

export class UpdateMilestoneShapeFailed implements Action {
  readonly type = MilestoneShapesActionTypes.UpdateFailed;
  constructor(public error: string) {}
}

export class DeleteMilestoneShape implements Action {
  readonly type = MilestoneShapesActionTypes.Delete;
  constructor(public shapeId: number) {}
}

export class DeleteMilestoneShapeSuccess implements Action {
  readonly type = MilestoneShapesActionTypes.DeleteSuccess;
  constructor(public shapeId: number) {}
}

export class DeleteMilestoneShapedFailed implements Action {
  readonly type = MilestoneShapesActionTypes.DeleteFailed;
  constructor(public error: string) {}
}

export type MilestoneShapesActions =
  | LoadMilestoneShapes
  | LoadMilestoneShapesSuccess
  | LoadMilestoneShapesFailed
  | LoadOwnMilestoneShapes
  | LoadOwnMilestoneShapesSuccess
  | LoadOwnMilestoneShapesFailed
  | MilestoneShapeAdded
  | MilestoneShapeModified
  | MilestoneShapeRemoved
  | ResetMilestoneShapeForm
  | CreateMilestoneShape
  | CreateMilestoneShapeSuccess
  | CreateMilestoneShapeFailed
  | UpdateMilestoneShape
  | UpdateMilestoneShapeSuccess
  | UpdateMilestoneShapeFailed
  | DeleteMilestoneShape
  | DeleteMilestoneShapeSuccess
  | DeleteMilestoneShapedFailed;
