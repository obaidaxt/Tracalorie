import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { MilestoneShapesEffects } from './milestone-shapes.effects';

describe('MilestoneShapesEffects', () => {
  let actions$: Observable<any>;
  let effects: MilestoneShapesEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MilestoneShapesEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(MilestoneShapesEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
