import * as fromShapes from './milestone-shapes.reducer';
import { createSelector } from '@ngrx/store';
import { selectMilestoneState } from '@milestone/state/milestone.reducers';
import { selectOrganizationId } from '@account/state';

export const selectMilestoneShapesState = createSelector(
  selectMilestoneState,
  state => state.milestoneShapes
);

export const selectMilestoneShapesLoadingStatus = createSelector(
  selectMilestoneShapesState,
  fromShapes.selectLoadingStatus
);

export const selectMilestoneShapesLoadingError = createSelector(
  selectMilestoneShapesState,
  fromShapes.selectLoadingError
);

export const selectMilestoneShapesFormStatus = createSelector(
  selectMilestoneShapesState,
  fromShapes.selectFormStatus
);

export const selectMilestoneShapesFormError = createSelector(
  selectMilestoneShapesState,
  fromShapes.selectFormError
);

export const selectAllMilestoneShapes = createSelector(
  selectMilestoneShapesState,
  fromShapes.selectAll
);

export const selectMilestoneShapeEntities = createSelector(
  selectMilestoneShapesState,
  fromShapes.selectEntities
);

export const selectOwnMilestoneShapes = createSelector(
  selectAllMilestoneShapes,
  selectOrganizationId,
  (shapes, orgId) => shapes.filter(s => s.organizationId === orgId)
);
