import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import {
  MilestoneShapesActions,
  MilestoneShapesActionTypes
} from './milestone-shapes.actions';
import { MilestoneShapeStored } from '@milestone/models/stored/milestone-shape.stored';
import { LoadingStatus } from '../../../../common/models/loading-status';

export interface State extends EntityState<MilestoneShapeStored> {
  loadingStatus: LoadingStatus;
  loadingError: string;
  formStatus: LoadingStatus;
  formError: string;
}

export const adapter = createEntityAdapter<MilestoneShapeStored>({
  selectId: shape => shape.id
});

export const initialState: State = adapter.getInitialState({
  loadingStatus: LoadingStatus.Waiting,
  loadingError: null,
  formStatus: LoadingStatus.Waiting,
  formError: null
});

export function reducer(
  state = initialState,
  action: MilestoneShapesActions
): State {
  switch (action.type) {
    case MilestoneShapesActionTypes.Load: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Loading
      };
    }

    case MilestoneShapesActionTypes.LoadSuccess: {
      return adapter.addAll(action.shapes, {
        ...state,
        loadingStatus: LoadingStatus.Completed
      });
    }

    case MilestoneShapesActionTypes.LoadFailed: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Failed,
        loadingError: action.error
      };
    }

    case MilestoneShapesActionTypes.LoadOwn: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Loading
      };
    }

    case MilestoneShapesActionTypes.LoadOwnSuccess: {
      return adapter.addAll(action.shapes, {
        ...state,
        loadingStatus: LoadingStatus.Completed
      });
    }

    case MilestoneShapesActionTypes.LoadOwnFailed: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Failed,
        loadingError: action.error
      };
    }

    case MilestoneShapesActionTypes.Added: {
      return adapter.addOne(action.shape, state);
    }

    case MilestoneShapesActionTypes.Modified: {
      return adapter.updateOne(
        {
          id: action.shape.id,
          changes: action.shape
        },
        state
      );
    }

    case MilestoneShapesActionTypes.Removed: {
      return adapter.removeOne(action.shapeId, state);
    }

    case MilestoneShapesActionTypes.ResetForm: {
      return {
        ...state,
        formStatus: LoadingStatus.Waiting,
        formError: null
      };
    }

    case MilestoneShapesActionTypes.Create: {
      return {
        ...state,
        formStatus: LoadingStatus.Loading
      };
    }

    case MilestoneShapesActionTypes.CreateSuccess: {
      return adapter.addOne(action.shape, {
        ...state,
        formStatus: LoadingStatus.Completed
      });
    }

    case MilestoneShapesActionTypes.CreateFailed: {
      return {
        ...state,
        formStatus: LoadingStatus.Failed,
        formError: action.error
      };
    }

    case MilestoneShapesActionTypes.Update: {
      return {
        ...state,
        formStatus: LoadingStatus.Loading
      };
    }

    case MilestoneShapesActionTypes.UpdateSuccess: {
      return adapter.updateOne(
        {
          id: action.shape.id,
          changes: action.shape
        },
        {
          ...state,
          formStatus: LoadingStatus.Completed
        }
      );
    }

    case MilestoneShapesActionTypes.UpdateFailed: {
      return {
        ...state,
        formStatus: LoadingStatus.Failed,
        formError: action.error
      };
    }

    case MilestoneShapesActionTypes.DeleteSuccess: {
      return adapter.removeOne(action.shapeId, state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
export const selectLoadingStatus = (state: State) => state.loadingStatus;
export const selectLoadingError = (state: State) => state.loadingError;
export const selectFormStatus = (state: State) => state.formStatus;
export const selectFormError = (state: State) => state.formError;
