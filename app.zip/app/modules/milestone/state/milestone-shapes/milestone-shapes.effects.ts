import { Injectable } from '@angular/core';
import { MilestoneShapeService } from '@milestone/services/milestone-shape.service';
import {
  CreateMilestoneShape,
  CreateMilestoneShapeFailed,
  CreateMilestoneShapeSuccess,
  DeleteMilestoneShape,
  DeleteMilestoneShapedFailed,
  DeleteMilestoneShapeSuccess,
  LoadMilestoneShapesFailed,
  LoadMilestoneShapesSuccess,
  MilestoneShapeAdded,
  MilestoneShapeModified,
  MilestoneShapeRemoved,
  MilestoneShapesActionTypes,
  UpdateMilestoneShape,
  UpdateMilestoneShapeFailed,
  UpdateMilestoneShapeSuccess,
  LoadOwnMilestoneShapesSuccess,
  LoadOwnMilestoneShapesFailed
} from '@milestone/state/milestone-shapes/milestone-shapes.actions';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { catchError, map, mergeMap, switchMap } from 'rxjs/operators';
import { DataChangeType } from '../../../../common/models/data-change-type';

@Injectable()
export class MilestoneShapesEffects {
  constructor(
    private actions$: Actions,
    private shapeService: MilestoneShapeService
  ) {}

  @Effect()
  load$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneShapesActionTypes.Load),
    switchMap(() =>
      this.shapeService.loadMilestoneShapes().pipe(
        map(shapes => new LoadMilestoneShapesSuccess(shapes)),
        catchError(err => of(new LoadMilestoneShapesFailed(err)))
      )
    )
  );

  @Effect()
  loadOwn$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneShapesActionTypes.LoadOwn),
    switchMap(() =>
      this.shapeService.loadOwnMilestoneShapes().pipe(
        map(shapes => new LoadOwnMilestoneShapesSuccess(shapes)),
        catchError(err => of(new LoadOwnMilestoneShapesFailed(err)))
      )
    )
  );

  @Effect()
  changes$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneShapesActionTypes.Load),
    switchMap(() =>
      this.shapeService.getMilestoneShapeChanges().pipe(
        map(change => {
          switch (change.type) {
            case DataChangeType.Added: {
              return new MilestoneShapeAdded(change.data);
            }
            case DataChangeType.Modified: {
              return new MilestoneShapeModified(change.data);
            }
            case DataChangeType.Removed: {
              return new MilestoneShapeRemoved(change.id);
            }
          }
        })
      )
    )
  );

  @Effect()
  create$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneShapesActionTypes.Create),
    switchMap(({ payload }: CreateMilestoneShape) =>
      this.shapeService.createMilestoneShape(payload).pipe(
        map(shape => new CreateMilestoneShapeSuccess(shape)),
        catchError(err => of(new CreateMilestoneShapeFailed(err)))
      )
    )
  );

  @Effect()
  update$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneShapesActionTypes.Update),
    switchMap(({ milestoneId, payload }: UpdateMilestoneShape) =>
      this.shapeService.updateMilestoneShape(milestoneId, payload).pipe(
        map(shape => new UpdateMilestoneShapeSuccess(shape)),
        catchError(err => of(new UpdateMilestoneShapeFailed(err)))
      )
    )
  );

  @Effect()
  delete$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneShapesActionTypes.Delete),
    mergeMap(({ shapeId }: DeleteMilestoneShape) =>
      this.shapeService.deleteMilestoneShape(shapeId).pipe(
        map(() => new DeleteMilestoneShapeSuccess(shapeId)),
        catchError(err => of(new DeleteMilestoneShapedFailed(err)))
      )
    )
  );
}
