import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import {
  MilestoneCorrectionsActions,
  MilestoneCorrectionsActionTypes
} from './milestone-corrections.actions';
import { MilestoneCorrectionStored } from '@milestone/models/stored/milestone-correction.stored';
import { LoadingStatus } from '../../../../common/models/loading-status';
import { milestoneCorrectionApiToStored } from '@milestone/models/mapper/milestone-correction-api-to-stored';

export interface State extends EntityState<MilestoneCorrectionStored> {
  loadingStatus: LoadingStatus;
  loadingError: string;
  formStatus: LoadingStatus;
  formError: string;
}

export const adapter = createEntityAdapter<MilestoneCorrectionStored>({
  selectId: correction => correction.id
});

export const initialState: State = adapter.getInitialState({
  loadingStatus: LoadingStatus.Waiting,
  loadingError: null,
  formStatus: LoadingStatus.Waiting,
  formError: null
});

export function reducer(
  state = initialState,
  action: MilestoneCorrectionsActions
): State {
  switch (action.type) {
    case MilestoneCorrectionsActionTypes.Load: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Loading
      };
    }

    case MilestoneCorrectionsActionTypes.LoadSuccess: {
      return adapter.addMany(
        action.corrections.map(milestoneCorrectionApiToStored),
        {
          ...state,
          loadingStatus: LoadingStatus.Completed
        }
      );
    }

    case MilestoneCorrectionsActionTypes.LoadFailed: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Failed
      };
    }

    case MilestoneCorrectionsActionTypes.ResetForm: {
      return {
        ...state,
        formStatus: LoadingStatus.Waiting,
        formError: null
      };
    }

    case MilestoneCorrectionsActionTypes.Create: {
      return {
        ...state,
        formStatus: LoadingStatus.Loading
      };
    }

    case MilestoneCorrectionsActionTypes.CreateSuccess: {
      return adapter.addOne(milestoneCorrectionApiToStored(action.correction), {
        ...state,
        formStatus: LoadingStatus.Completed
      });
    }

    case MilestoneCorrectionsActionTypes.CreateFailed: {
      return {
        ...state,
        formStatus: LoadingStatus.Failed,
        formError: action.error
      };
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
export const selectLoadingStatus = (state: State) => state.loadingStatus;
export const selectLoadingError = (state: State) => state.loadingError;
export const selectFormStatus = (state: State) => state.formStatus;
export const selectFormError = (state: State) => state.formError;
