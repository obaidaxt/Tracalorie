import { MilestoneDetails } from '@milestone/models/view/milestone-details';
import { MilestoneCorrectionStored } from '@milestone/models/stored/milestone-correction.stored';
import { CorrectionGrouping } from '@milestone/models/view/correction-grouping';
import { correctionStoredToListView } from '@milestone/models/mapper/correction-stored-to-list-view';
import { Dictionary } from '@ngrx/entity';
import { UserStored } from '@organization/models/stored/user.stored';

export const getCorrectionGroupings = (
  milestones: MilestoneDetails[],
  corrections: MilestoneCorrectionStored[],
  milestoneId: number,
  users: Dictionary<UserStored>
): CorrectionGrouping[] =>
  milestones.map<CorrectionGrouping>(milestone => ({
    milestone,
    selected: milestone.id === milestoneId,
    corrections: corrections
      .filter(c => c.milestoneId === milestone.id)
      .map(correction =>
        correctionStoredToListView(correction, milestone, users)
      )
  })).filter(g => g.corrections.length > 0);
