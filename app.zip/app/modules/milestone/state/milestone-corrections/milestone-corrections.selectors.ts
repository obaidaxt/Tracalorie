import * as fromCorrections from './milestone-corrections.reducer';
import { createSelector } from '@ngrx/store';
import { selectMilestoneState } from '@milestone/state/milestone.reducers';
import {
  selectCurrentMilestoneDetails,
  selectMilestoneListDetails,
  selectSelectedMilestoneId,
  selectCurrentMilestone
} from '@milestone/state/milestones';
import { selectUserEntities } from '@organization/state';
import { getCorrectionGroupings } from '@milestone/state/milestone-corrections/get-correction-groupings';
import { ApprovalUser } from '@milestone/models/view/approval-user';

export const selectCorrectionsState = createSelector(
  selectMilestoneState,
  state => state.corrections
);

export const selectCorrectionsLoadingStatus = createSelector(
  selectCorrectionsState,
  fromCorrections.selectLoadingStatus
);

export const selectCorrectionsLoadingError = createSelector(
  selectCorrectionsState,
  fromCorrections.selectLoadingError
);

export const selectCorrectionFormStatus = createSelector(
  selectCorrectionsState,
  fromCorrections.selectFormStatus
);

export const selectCorrectionFormError = createSelector(
  selectCorrectionsState,
  fromCorrections.selectFormError
);

export const selectAllCorrections = createSelector(
  selectCorrectionsState,
  fromCorrections.selectAll
);

export const selectCorrectionEntities = createSelector(
  selectCorrectionsState,
  fromCorrections.selectEntities
);

export const selectCorrectionGroupings = createSelector(
  selectMilestoneListDetails,
  selectAllCorrections,
  selectSelectedMilestoneId,
  selectUserEntities,
  getCorrectionGroupings
);

export const selectApprovalUsers = createSelector(
  selectCurrentMilestone,
  selectUserEntities,
  selectAllCorrections,
  (milestone, users, corrections) =>
    !milestone
      ? []
      : milestone.approvals.map<ApprovalUser>(approval => {
          const user = users[approval.userId];
          if (!user) {
            return null;
          }
          return {
            ...user,
            approvalStatus: approval.approved
              ? 'approved'
              : corrections.some(
                  c =>
                    c.milestoneId === milestone.id &&
                    c.createdById === approval.userId
                )
                ? 'correction'
                : 'waiting'
          };
        })
);
