import { Action } from '@ngrx/store';
import { Update } from '@ngrx/entity';
import { MilestoneCorrectionApi } from '@milestone/models/api/milestone-correction.api';
import { MilestoneCorrectionPost } from '@milestone/models/api/milestone-correction.post';

export enum MilestoneCorrectionsActionTypes {
  Load = '[Project Details] Load Milestone Corrections',
  LoadSuccess = '[API] Load Milestone Corrections Success',
  LoadFailed = '[API] Load Milestone Corrections Failed',
  Added = '[Websocket] Milestone Correction Added',
  Modified = '[Websocket] Milestone Correction Modified',
  Removed = '[Websocket] Milestone Correction Removed',
  ResetForm = '[Correction Form] Reset Form',
  Create = '[Correction Form] Create Correction',
  CreateSuccess = '[API] Create Correction Success',
  CreateFailed = '[API] Create Correction Failed',
  Update = '[Correction Form] Update Correction',
  UpdateSuccess = '[API] Update Correction Success',
  UpdateFailed = '[API] Update Correction Failed',
  Delete = '[Correction List] Delete Correction',
  DeleteSuccess = '[API] Delete Correction Success',
  DeleteFailed = '[API] Delete Correction Failed'
}

export class LoadMilestoneCorrections implements Action {
  readonly type = MilestoneCorrectionsActionTypes.Load;
  constructor(public projectId: number) {}
}

export class LoadMilestoneCorrectionsSuccess implements Action {
  readonly type = MilestoneCorrectionsActionTypes.LoadSuccess;
  constructor(public corrections: MilestoneCorrectionApi[]) {}
}

export class LoadMilestoneCorrectionsFailed implements Action {
  readonly type = MilestoneCorrectionsActionTypes.LoadFailed;
  constructor(public error: string) {}
}

export class MilestoneCorrectionAdded implements Action {
  readonly type = MilestoneCorrectionsActionTypes.Added;
  constructor(public correction: MilestoneCorrectionApi) {}
}

export class MilestoneCorrectionModified implements Action {
  readonly type = MilestoneCorrectionsActionTypes.Modified;
  constructor(public correction: MilestoneCorrectionApi) {}
}

export class MilestoneCorrectionRemoved implements Action {
  readonly type = MilestoneCorrectionsActionTypes.Removed;
  constructor(public correctionId: number) {}
}

export class ResetMilestoneCorrectionForm implements Action {
  readonly type = MilestoneCorrectionsActionTypes.ResetForm;
}

export class CreateMilestoneCorrection implements Action {
  readonly type = MilestoneCorrectionsActionTypes.Create;
  constructor(public payload: MilestoneCorrectionPost) {}
}

export class CreateMilestoneCorrectionSuccess implements Action {
  readonly type = MilestoneCorrectionsActionTypes.CreateSuccess;
  constructor(public correction: MilestoneCorrectionApi) {}
}

export class CreateMilestoneCorrectionFailed implements Action {
  readonly type = MilestoneCorrectionsActionTypes.CreateFailed;
  constructor(public error: string) {}
}

export class UpdateMilestoneCorrection implements Action {
  readonly type = MilestoneCorrectionsActionTypes.Update;
  constructor(public id: number, public payload: MilestoneCorrectionPost) {}
}

export class UpdateMilestoneCorrectionSuccess implements Action {
  readonly type = MilestoneCorrectionsActionTypes.UpdateSuccess;
  constructor(public correction: MilestoneCorrectionApi) {}
}

export class UpdateMilestoneCorrectionFailed implements Action {
  readonly type = MilestoneCorrectionsActionTypes.UpdateFailed;
  constructor(public error: string) {}
}

export class DeleteMilestoneCorrection implements Action {
  readonly type = MilestoneCorrectionsActionTypes.Delete;
  constructor(public correctionId: number) {}
}

export class DeleteMilestoneCorrectionSuccess implements Action {
  readonly type = MilestoneCorrectionsActionTypes.DeleteSuccess;
  constructor(public correctionId: number) {}
}

export class DeleteMilestoneCorrectionFailed implements Action {
  readonly type = MilestoneCorrectionsActionTypes.DeleteFailed;
  constructor(public error: string) {}
}

export type MilestoneCorrectionsActions =
  | LoadMilestoneCorrections
  | LoadMilestoneCorrectionsSuccess
  | LoadMilestoneCorrectionsFailed
  | MilestoneCorrectionAdded
  | MilestoneCorrectionModified
  | MilestoneCorrectionRemoved
  | ResetMilestoneCorrectionForm
  | CreateMilestoneCorrection
  | CreateMilestoneCorrectionSuccess
  | CreateMilestoneCorrectionFailed
  | UpdateMilestoneCorrection
  | UpdateMilestoneCorrectionSuccess
  | UpdateMilestoneCorrectionFailed
  | DeleteMilestoneCorrection
  | DeleteMilestoneCorrectionSuccess
  | DeleteMilestoneCorrectionFailed;
