import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { MilestoneCorrectionService } from '@milestone/services/milestone-correction.service';
import { Observable, of } from 'rxjs';
import {
  MilestoneCorrectionsActionTypes,
  LoadMilestoneCorrections,
  LoadMilestoneCorrectionsSuccess,
  LoadMilestoneCorrectionsFailed,
  MilestoneCorrectionAdded,
  MilestoneCorrectionModified,
  MilestoneCorrectionRemoved,
  CreateMilestoneCorrection,
  CreateMilestoneCorrectionSuccess,
  CreateMilestoneCorrectionFailed,
  UpdateMilestoneCorrection,
  UpdateMilestoneCorrectionSuccess,
  UpdateMilestoneCorrectionFailed,
  DeleteMilestoneCorrection,
  DeleteMilestoneCorrectionSuccess,
  DeleteMilestoneCorrectionFailed
} from '@milestone/state/milestone-corrections/milestone-corrections.actions';
import { switchMap, map, catchError } from 'rxjs/operators';
import { Action } from '@ngrx/store';
import { DataChangeType } from '../../../../common/models/data-change-type';

@Injectable()
export class MilestoneCorrectionsEffects {
  constructor(
    private actions$: Actions,
    private correctionService: MilestoneCorrectionService
  ) {}

  @Effect()
  load$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneCorrectionsActionTypes.Load),
    switchMap(({ projectId }: LoadMilestoneCorrections) =>
      this.correctionService.loadCorrections(projectId).pipe(
        map(corrections => new LoadMilestoneCorrectionsSuccess(corrections)),
        catchError(err => of(new LoadMilestoneCorrectionsFailed(err)))
      )
    )
  );

  @Effect()
  changes$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneCorrectionsActionTypes.Load),
    switchMap(({ projectId }: LoadMilestoneCorrections) =>
      this.correctionService.getCorrectionChanges(projectId).pipe(
        map(change => {
          switch (change.type) {
            case DataChangeType.Added: {
              return new MilestoneCorrectionAdded(change.data);
            }
            case DataChangeType.Modified: {
              return new MilestoneCorrectionModified(change.data);
            }
            case DataChangeType.Removed: {
              return new MilestoneCorrectionRemoved(change.id);
            }
          }
        })
      )
    )
  );

  @Effect()
  create$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneCorrectionsActionTypes.Create),
    switchMap(({ payload }: CreateMilestoneCorrection) =>
      this.correctionService.createCorrection(payload).pipe(
        map(correction => new CreateMilestoneCorrectionSuccess(correction)),
        catchError(err => of(new CreateMilestoneCorrectionFailed(err)))
      )
    )
  );

  @Effect()
  update$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneCorrectionsActionTypes.Update),
    switchMap(({ id, payload }: UpdateMilestoneCorrection) =>
      this.correctionService.updateCorrection(id, payload).pipe(
        map(correction => new UpdateMilestoneCorrectionSuccess(correction)),
        catchError(err => of(new UpdateMilestoneCorrectionFailed(err)))
      )
    )
  );

  @Effect()
  delete$: Observable<Action> = this.actions$.pipe(
    ofType(MilestoneCorrectionsActionTypes.Delete),
    switchMap(({ correctionId }: DeleteMilestoneCorrection) =>
      this.correctionService.deleteCorrection(correctionId).pipe(
        map(() => new DeleteMilestoneCorrectionSuccess(correctionId)),
        catchError(err => of(new DeleteMilestoneCorrectionFailed(err)))
      )
    )
  );
}
