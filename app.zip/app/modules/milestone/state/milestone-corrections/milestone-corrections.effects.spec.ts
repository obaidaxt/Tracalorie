import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { MilestoneCorrectionsEffects } from './milestone-corrections.effects';

describe('MilestoneCorrectionsEffects', () => {
  let actions$: Observable<any>;
  let effects: MilestoneCorrectionsEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MilestoneCorrectionsEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(MilestoneCorrectionsEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
