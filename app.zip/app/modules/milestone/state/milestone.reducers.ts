import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';
import * as fromShapes from './milestone-shapes/milestone-shapes.reducer';
import * as fromMilestones from './milestones/milestones.reducer';
import * as fromCorrections from './milestone-corrections/milestone-corrections.reducer';

export interface MilestoneState {
  milestones: fromMilestones.State;
  milestoneShapes: fromShapes.State;
  corrections: fromCorrections.State;
}

export interface State {
  milestone: MilestoneState;
}

export const reducers: ActionReducerMap<MilestoneState> = {
  milestones: fromMilestones.reducer,
  milestoneShapes: fromShapes.reducer,
  corrections: fromCorrections.reducer
};

export const selectMilestoneState = createFeatureSelector<MilestoneState>(
  'milestone'
);
