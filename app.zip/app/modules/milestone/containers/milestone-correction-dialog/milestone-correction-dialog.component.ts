import {
  ChangeDetectionStrategy,
  Component,
  Inject,
  OnDestroy,
  OnInit
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { LoadingStatus } from '@common/models/loading-status';
import { MilestoneCorrectionDialogOptions } from '@milestone/containers/milestone-correction-dialog/milestone-correction-dialog-options';
import { Observable, Subject } from 'rxjs';
import { Store } from '@ngrx/store';
import * as fromMilestone from '@milestone/state';
import { MilestoneCorrectionPost } from '@milestone/models/api/milestone-correction.post';
import { takeUntil, filter, take } from 'rxjs/operators';
import { ResetMilestoneCorrectionForm } from '@milestone/state';

@Component({
  selector: 'app-milestone-correction-dialog',
  templateUrl: './milestone-correction-dialog.component.html',
  styleUrls: ['./milestone-correction-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MilestoneCorrectionDialogComponent implements OnInit, OnDestroy {
  destroy$ = new Subject<void>();
  formStatus$: Observable<LoadingStatus>;
  formError$: Observable<string>;
  title: string;

  constructor(
    private dialgoRef: MatDialogRef<MilestoneCorrectionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public options: MilestoneCorrectionDialogOptions,
    private store: Store<fromMilestone.State>
  ) {}

  ngOnInit() {
    this.formStatus$ = this.store.select(
      fromMilestone.selectCorrectionFormStatus
    );
    this.formError$ = this.store.select(
      fromMilestone.selectCorrectionFormError
    );

    this.store.dispatch(new ResetMilestoneCorrectionForm());
    this.createTitle();

    this.formStatus$
      .pipe(
        takeUntil(this.destroy$),
        filter(status => status === LoadingStatus.Completed),
        take(1)
      )
      .subscribe(() => {
        this.dialgoRef.close();
      });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  createTitle() {
    if (this.options.type === 'create') {
      this.title = this.options.milestone.viewName + ': Korrektur erstellen';
    } else {
      this.title = 'Korrektur bearbeiten';
    }
  }

  handleSubmit(payload: MilestoneCorrectionPost) {
    if (this.options.type === 'create') {
      this.store.dispatch(new fromMilestone.CreateMilestoneCorrection(payload));
    } else {
      this.store.dispatch(
        new fromMilestone.UpdateMilestoneCorrection(
          this.options.correction.id,
          payload
        )
      );
    }
  }
}
