import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MilestoneCorrectionDialogComponent } from './milestone-correction-dialog.component';

describe('MilestoneCorrectionDialogComponent', () => {
  let component: MilestoneCorrectionDialogComponent;
  let fixture: ComponentFixture<MilestoneCorrectionDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MilestoneCorrectionDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MilestoneCorrectionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
