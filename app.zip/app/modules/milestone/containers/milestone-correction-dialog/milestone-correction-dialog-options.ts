import { MilestoneCorrectionStored } from '@milestone/models/stored/milestone-correction.stored';
import { MilestoneDetails } from '@milestone/models/view/milestone-details';

export interface MilestoneCorrectionDialogOptions {
  type: 'create' | 'update';
  milestone: MilestoneDetails;
  correction?: MilestoneCorrectionStored;
}
