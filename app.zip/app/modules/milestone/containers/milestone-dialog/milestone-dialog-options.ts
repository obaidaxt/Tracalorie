import { MilestoneShapeStored } from '@milestone/models/stored/milestone-shape.stored';
import { MilestoneDetails } from '@milestone/models/view/milestone-details';

export interface MilestoneDialogOptions {
  type: 'create' | 'update';
  milestoneShape: MilestoneShapeStored;
  milestone?: MilestoneDetails;
}
