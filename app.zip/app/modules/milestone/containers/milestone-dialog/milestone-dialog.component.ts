import {
  ChangeDetectionStrategy,
  Component,
  Inject,
  OnDestroy,
  OnInit
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { LoadingStatus } from '@common/models/loading-status';
import { MilestoneDialogOptions } from '@milestone/containers/milestone-dialog/milestone-dialog-options';
import { MilestonePost } from '@milestone/models/api/milestone.post';
import * as fromMilestone from '@milestone/state';
import { Store } from '@ngrx/store';
import { UserStored } from '@organization/models/stored/user.stored';
import * as fromOrg from '@organization/state';
import { ProjectStored } from '@project/models/stored/project.stored';
import * as fromProject from '@project/state';
import { combineLatest, Observable, Subject } from 'rxjs';
import { filter, map, take, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-milestone-dialog',
  templateUrl: './milestone-dialog.component.html',
  styleUrls: ['./milestone-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MilestoneDialogComponent implements OnInit, OnDestroy {
  usersServiceProvider$: Observable<UserStored[]>;
  usersCustomer$: Observable<UserStored[]>;
  project$: Observable<ProjectStored>;
  formStatus$: Observable<LoadingStatus>;
  formError$: Observable<string>;

  destroy$ = new Subject<void>();
  title: string;

  constructor(
    private dialogRef: MatDialogRef<MilestoneDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public options: MilestoneDialogOptions,
    private store: Store<fromMilestone.State>
  ) {}

  ngOnInit() {
    const users$ = this.store.select(fromOrg.selectAllUsers);
    this.project$ = this.store.select(fromProject.selectCurrentProject);
    this.usersCustomer$ = combineLatest(this.project$, users$).pipe(
      map(([project, users]) =>
        users.filter(u => u.organizationId === project.customerId)
      )
    );
    this.usersServiceProvider$ = combineLatest(this.project$, users$).pipe(
      map(([project, users]) =>
        users.filter(u => project.serviceProviders.includes(u.organizationId))
      )
    );
    this.formStatus$ = this.store.select(
      fromMilestone.selectMilestoneFormStatus
    );
    this.formError$ = this.store.select(fromMilestone.selectMilestoneFormError);

    this.store.dispatch(new fromMilestone.ResetMilestoneForm());
    this.formStatus$
      .pipe(
        takeUntil(this.destroy$),
        filter(status => status === LoadingStatus.Completed),
        take(1)
      )
      .subscribe(() => {
        this.dialogRef.close();
      });

    this.createTitle();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  createTitle() {
    if (this.options.type === 'create') {
      this.title = this.options.milestoneShape.name + ' erstellen';
    } else {
      this.title = this.options.milestone.viewName + ' bearbeiten';
    }
  }

  handleSubmit(payload: MilestonePost) {
    if (this.options.type === 'create') {
      this.store.dispatch(new fromMilestone.CreateMilestone(payload));
    } else {
      this.store.dispatch(
        new fromMilestone.UpdateMilestone(this.options.milestone.id, payload)
      );
    }
  }
}
