import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MilestoneCorrectionListComponent } from './milestone-correction-list.component';

describe('MilestoneCorrectionListComponent', () => {
  let component: MilestoneCorrectionListComponent;
  let fixture: ComponentFixture<MilestoneCorrectionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MilestoneCorrectionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MilestoneCorrectionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
