import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { MilestoneCorrectionDialogOptions } from '@milestone/containers/milestone-correction-dialog/milestone-correction-dialog-options';
import { CorrectionListView } from '@milestone/models/view/correction-list-view';
import { CorrectionGrouping } from '@milestone/models/view/correction-grouping';
import { MilestoneDetails } from '@milestone/models/view/milestone-details';

@Component({
  selector: 'app-milestone-correction-list',
  templateUrl: './milestone-correction-list.component.html',
  styleUrls: ['./milestone-correction-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MilestoneCorrectionListComponent implements OnInit {
  @Input()
  milestone: MilestoneDetails;
  @Input()
  corrections: CorrectionGrouping[];
  @Input()
  isCustomerResponsible: boolean;

  @Output()
  showCorrectionForm = new EventEmitter<MilestoneCorrectionDialogOptions>();

  constructor() {}

  ngOnInit() {}

  groupingTrackByFn(i: number, grouping: CorrectionGrouping) {
    return i;
  }

  correctionTrackByFn(i: number, correction: CorrectionListView) {
    return correction.id;
  }

  createCorrection() {
    this.showCorrectionForm.emit({
      milestone: this.milestone,
      type: 'create'
    });
  }

  updateCorrection(
    milestone: MilestoneDetails,
    correction: CorrectionListView
  ) {
    this.showCorrectionForm.emit({
      milestone,
      correction,
      type: 'update'
    });
  }
}
