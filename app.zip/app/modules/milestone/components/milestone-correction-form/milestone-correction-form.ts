import { FileStored } from "@file/models/stored/file.stored";

export interface MilestoneCorrectionForm {
  milestoneId: number;
  milestoneFileId: number | null;
  page: number | null;
  comment: string;
  files: FileStored[];
}
