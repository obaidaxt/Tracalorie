import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MilestoneCorrectionFormComponent } from './milestone-correction-form.component';

describe('MilestoneCorrectionFormComponent', () => {
  let component: MilestoneCorrectionFormComponent;
  let fixture: ComponentFixture<MilestoneCorrectionFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MilestoneCorrectionFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MilestoneCorrectionFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
