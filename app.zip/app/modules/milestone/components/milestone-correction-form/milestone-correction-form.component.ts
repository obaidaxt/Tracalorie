import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { MilestoneDetails } from '@milestone/models/view/milestone-details';
import { LoadingStatus } from '@common/models/loading-status';
import { MilestoneCorrectionPost } from '@milestone/models/api/milestone-correction.post';
import {
  FormGroup,
  FormBuilder,
  AbstractControl
} from 'ngx-strongly-typed-forms';
import { Validators, ValidationErrors } from '@angular/forms';
import { MilestoneCorrectionStored } from '@milestone/models/stored/milestone-correction.stored';
import { MilestoneCorrectionForm } from './milestone-correction-form';

@Component({
  selector: 'app-milestone-correction-form',
  templateUrl: './milestone-correction-form.component.html',
  styleUrls: ['./milestone-correction-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MilestoneCorrectionFormComponent implements OnInit, OnChanges {
  @Input()
  milestone: MilestoneDetails;
  @Input()
  correction: MilestoneCorrectionStored;
  @Input()
  formType: 'create' | 'update';
  @Input()
  formStatus: LoadingStatus;
  @Input()
  formError: string;

  @Output()
  onSubmit = new EventEmitter<MilestoneCorrectionPost>();

  correctionForm: FormGroup<MilestoneCorrectionForm>;

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.createForm();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['milestone'] && this.correctionForm) {
      this.correctionForm.get('milestoneId').setValue(this.milestone.id);
    }
  }

  createForm() {
    this.correctionForm = this.fb.group<MilestoneCorrectionForm>(
      {
        milestoneFileId: null,
        page: null,
        comment: null,
        files: [[]],
        milestoneId: [this.milestone && this.milestone.id, Validators.required]
      },
      {
        validator: [this.validateContent]
      }
    );
    if (this.formType === 'update') {
      this.correctionForm.patchValue({
        milestoneFileId: this.correction.fileId,
        page: this.correction.page,
        comment: this.correction.comment,
        files: this.correction.files
      });
    }
  }

  validateContent(
    control: AbstractControl<MilestoneCorrectionForm>
  ): ValidationErrors | null {
    const filesCtl = control.get('files');
    const commentCtl = control.get('comment');
    if (
      filesCtl.value.length === 0 &&
      (!commentCtl.value || commentCtl.value.length === 0)
    ) {
      return {
        noContent: true
      };
    }
    return null;
  }

  handleSubmit() {
    if (this.correctionForm.invalid) {
      return;
    }
    this.onSubmit.emit({
      ...this.correctionForm.value,
      files: this.correctionForm.value.files.map(f => f.id)
    });
  }
}
