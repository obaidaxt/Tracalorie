import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MilestoneApprovalListComponent } from './milestone-approval-list.component';

describe('MilestoneApprovalListComponent', () => {
  let component: MilestoneApprovalListComponent;
  let fixture: ComponentFixture<MilestoneApprovalListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MilestoneApprovalListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MilestoneApprovalListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
