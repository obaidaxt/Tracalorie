import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { ApprovalUser } from '@milestone/models/view/approval-user';

@Component({
  selector: 'app-milestone-approval-list',
  templateUrl: './milestone-approval-list.component.html',
  styleUrls: ['./milestone-approval-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MilestoneApprovalListComponent implements OnInit {
  @Input() approvals: ApprovalUser[];

  constructor() { }

  ngOnInit() {
  }

}
