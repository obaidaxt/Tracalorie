export interface MilestoneApproveForm {
  termsAccepted: boolean;
}
