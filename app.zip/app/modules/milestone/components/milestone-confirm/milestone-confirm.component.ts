import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { Validators } from '@angular/forms';
import { MilestoneApproveForm } from '@milestone/components/milestone-confirm/milestone-approve-form';
import { MilestoneCorrectionDialogOptions } from '@milestone/containers/milestone-correction-dialog/milestone-correction-dialog-options';
import { MilestoneDialogOptions } from '@milestone/containers/milestone-dialog/milestone-dialog-options';
import { MilestoneDetails } from '@milestone/models/view/milestone-details';
import { FormBuilder, FormGroup } from 'ngx-strongly-typed-forms';
import { LoadingStatus } from '../../../../common/models/loading-status';

@Component({
  selector: 'app-milestone-confirm',
  templateUrl: './milestone-confirm.component.html',
  styleUrls: ['./milestone-confirm.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MilestoneConfirmComponent implements OnInit {
  @Input()
  milestone: MilestoneDetails;
  @Input()
  approveStatus: LoadingStatus;
  @Input()
  approveError: string;
  @Input()
  isCustomerResponsible: boolean;
  @Input()
  isServiceProvider: boolean;

  @Output()
  approve = new EventEmitter<number>();
  @Output()
  showTerms = new EventEmitter<void>();
  @Output()
  showCorrectionForm = new EventEmitter<MilestoneCorrectionDialogOptions>();
  @Output()
  showMilestoneForm = new EventEmitter<MilestoneDialogOptions>();

  approveForm: FormGroup<MilestoneApproveForm>;

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.approveForm = this.fb.group<MilestoneApproveForm>({
      termsAccepted: [false, Validators.requiredTrue]
    });
  }

  handleTermsClick(event: Event) {
    event.preventDefault();
    this.showTerms.emit();
  }

  handleSubmit() {
    if (this.approveForm.invalid) {
      return;
    }
    this.approve.emit(this.milestone.id);
  }

  showCorrection() {
    this.showCorrectionForm.emit({
      milestone: this.milestone,
      type: 'create'
    });
  }

  showMilestone() {
    // TODO: shape auswahl
    // this.showMilestoneForm.emit({

    // })
  }
}
