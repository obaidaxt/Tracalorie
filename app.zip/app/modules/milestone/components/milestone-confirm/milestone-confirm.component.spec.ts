import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MilestoneConfirmComponent } from './milestone-confirm.component';

describe('MilestoneConfirmComponent', () => {
  let component: MilestoneConfirmComponent;
  let fixture: ComponentFixture<MilestoneConfirmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MilestoneConfirmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MilestoneConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
