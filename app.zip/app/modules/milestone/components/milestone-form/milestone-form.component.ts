import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter
} from '@angular/core';
import { MilestoneShapeStored } from '@milestone/models/stored/milestone-shape.stored';
import { MilestoneStored } from '@milestone/models/stored/milestone.stored';
import { UserStored } from '@organization/models/stored/user.stored';
import { ProjectStored } from '@project/models/stored/project.stored';
import { MilestonePost } from '@milestone/models/api/milestone.post';
import { FormGroup, FormBuilder } from 'ngx-strongly-typed-forms';
import { Validators } from '@angular/forms';
import { LoadingStatus } from '@common/models/loading-status';
import { MilestoneForm } from './milestone-form';

@Component({
  selector: 'app-milestone-form',
  templateUrl: './milestone-form.component.html',
  styleUrls: ['./milestone-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MilestoneFormComponent implements OnInit {
  @Input()
  milestone: MilestoneStored;
  @Input()
  project: ProjectStored;
  @Input()
  milestoneShape: MilestoneShapeStored;
  @Input()
  formType: 'create' | 'update';
  @Input()
  serviceProviderUsers: UserStored[];
  @Input()
  customerUsers: UserStored[];
  @Input()
  formStatus: LoadingStatus;
  @Input()
  formError: string;

  @Output()
  onSubmit = new EventEmitter<MilestonePost>();

  milestoneForm: FormGroup<MilestoneForm>;

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.milestoneForm = this.fb.group<MilestoneForm>({
      approvals: [[], Validators.minLength(1)],
      description: null,
      files: [[]],
      projectId: [this.project.id, Validators.required],
      responsibles: [[], Validators.minLength(1)],
      shapeId: [this.milestoneShape.id, Validators.required],
      identifier: [null, Validators.required]
    });
    if (this.formType === 'update') {
      this.milestoneForm.patchValue({
        approvals: this.milestone.approvals.map(a => a.userId),
        description: this.milestone.description,
        files: this.milestone.files,
        identifier: this.milestone.identifier,
        projectId: this.milestone.projectId,
        responsibles: this.milestone.responsibles,
        shapeId: this.milestone.shapeId
      });
    }
    if (this.formType === 'create') {
      this.milestoneForm.patchValue({
        approvals: this.project.responsibles,
        responsibles: this.project.responsibles,
        projectId: this.project.id,
        shapeId: this.milestoneShape.id
      });
    }
  }

  handleSubmit() {
    if (this.milestoneForm.invalid) {
      return;
    }
    this.onSubmit.emit({
      ...this.milestoneForm.value,
      files: this.milestoneForm.value.files.map(f => f.id)
    });
  }
}
