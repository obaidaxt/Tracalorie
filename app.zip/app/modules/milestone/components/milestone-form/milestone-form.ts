import { FileStored } from "@file/models/stored/file.stored";

export interface MilestoneForm {
  shapeId: number;
  projectId: number;
  identifier: string;
  description: string;
  files: FileStored[];
  responsibles: string[];
  approvals: string[];
}
