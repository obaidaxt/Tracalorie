import { TestBed } from '@angular/core/testing';

import { MilestoneCorrectionService } from './milestone-correction.service';

describe('MilestoneCorrectionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MilestoneCorrectionService = TestBed.get(MilestoneCorrectionService);
    expect(service).toBeTruthy();
  });
});
