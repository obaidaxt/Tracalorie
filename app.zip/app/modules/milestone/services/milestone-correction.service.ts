import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SignalRService } from '@core/services/signal-r.service';
import { MilestoneCorrectionApi } from '@milestone/models/api/milestone-correction.api';
import { MilestoneCorrectionPost } from '@milestone/models/api/milestone-correction.post';

@Injectable({
  providedIn: 'root'
})
export class MilestoneCorrectionService {
  constructor(private http: HttpClient, private signalR: SignalRService) {}

  loadCorrections(projectId: number) {
    return this.http.get<MilestoneCorrectionApi[]>(
      `api/Milestone/Correction/${projectId}`
    );
  }

  getCorrectionChanges(projectId: number) {
    return this.signalR.getChanges<MilestoneCorrectionApi, number>(
      'GetCorrectionChanges',
      projectId
    );
  }

  createCorrection(payload: MilestoneCorrectionPost) {
    return this.http.post<MilestoneCorrectionApi>(
      'api/Milestone/Correction/Create',
      payload
    );
  }

  updateCorrection(id: number, payload: MilestoneCorrectionPost) {
    return this.http.put<MilestoneCorrectionApi>(
      `api/Milestone/Correction/Update/${id}`,
      payload
    );
  }

  deleteCorrection(id: number) {
    return this.http.delete<void>(`api/Milestone/Correction/Delete/${id}`);
  }
}
