import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SignalRService } from '@core/services/signal-r.service';
import { MilestoneShapeApi } from '@milestone/models/api/milestone-shape.api';
import { MilestoneShapePost } from '@milestone/models/api/milestone-shop.post';

@Injectable({
  providedIn: 'root'
})
export class MilestoneShapeService {
  constructor(private http: HttpClient, private signalR: SignalRService) {}

  loadMilestoneShapes() {
    return this.http.get<MilestoneShapeApi[]>('api/Milestone/Shapes');
  }

  loadOwnMilestoneShapes() {
    return this.http.get<MilestoneShapeApi[]>('api/Milestone/OwnShapes');
  }

  getMilestoneShapeChanges() {
    return this.signalR.getChanges<MilestoneShapeApi, number>(
      'GetMilestoneShapeChanges'
    );
  }

  createMilestoneShape(payload: MilestoneShapePost) {
    return this.http.post<MilestoneShapeApi>(
      'api/Milestone/Shape/Create',
      payload
    );
  }

  updateMilestoneShape(id: number, payload: MilestoneShapePost) {
    return this.http.put<MilestoneShapeApi>(
      `api/Milestone/Shape/Update/${id}`,
      payload
    );
  }

  deleteMilestoneShape(id: number) {
    return this.http.delete<void>(`api/Milestone/Shape/Delete/${id}`);
  }
}
