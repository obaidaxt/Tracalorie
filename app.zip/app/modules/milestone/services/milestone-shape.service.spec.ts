import { TestBed } from '@angular/core/testing';

import { MilestoneShapeService } from './milestone-shape.service';

describe('MilestoneShapeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MilestoneShapeService = TestBed.get(MilestoneShapeService);
    expect(service).toBeTruthy();
  });
});
