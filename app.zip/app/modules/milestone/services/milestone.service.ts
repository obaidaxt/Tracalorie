import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SignalRService } from '@core/services/signal-r.service';
import { MilestoneApi } from '@milestone/models/api/milestone.api';
import { MilestonePost } from '@milestone/models/api/milestone.post';

@Injectable({
  providedIn: 'root'
})
export class MilestoneService {
  constructor(private http: HttpClient, private signalR: SignalRService) {}

  loadMilestones(projectId: number) {
    return this.http.get<MilestoneApi[]>(`api/Milestone/${projectId}`);
  }

  getMilestoneChanges(projectId: number) {
    return this.signalR.getChanges<MilestoneApi, number>(
      'GetMilestoneChanges',
      projectId
    );
  }

  createMilestone(payload: MilestonePost) {
    return this.http.post<MilestoneApi>('api/Milestone/Create', payload);
  }

  updateMilestone(milestoneId: number, payload: MilestonePost) {
    return this.http.put<MilestoneApi>(
      `api/Milestone/Update/${milestoneId}`,
      payload
    );
  }

  deleteMilestone(milestoneId: number) {
    return this.http.delete<void>(`api/Milestone/Delete/${milestoneId}`);
  }

  approveMilestone(id: number) {
    return this.http.get<void>(`api/Milestone/Approve/${id}`);
  }
}
