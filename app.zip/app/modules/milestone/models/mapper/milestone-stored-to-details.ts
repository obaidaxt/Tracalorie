import { MilestoneShapeStored } from '@milestone/models/stored/milestone-shape.stored';
import { MilestoneStored } from '@milestone/models/stored/milestone.stored';
import { MilestoneDetails } from '@milestone/models/view/milestone-details';
import { Dictionary } from '@ngrx/entity';

export const milestoneStoredToDetails = (
  milestone: MilestoneStored,
  shapes: Dictionary<MilestoneShapeStored>
): MilestoneDetails => {
  const shape = shapes[milestone.shapeId];
  if (!shape) {
    return null;
  }
  return {
    ...milestone,
    approved: !milestone.approvals.some(a => !a.approved),
    shape,
    viewName: `${shape.shortName} ${milestone.identifier}`
  };
};
