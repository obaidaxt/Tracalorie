import { MilestoneStored } from '@milestone/models/stored/milestone.stored';
import { MilestoneCorrectionStored } from '@milestone/models/stored/milestone-correction.stored';
import { Dictionary } from '@ngrx/entity';
import { UserStored } from '@organization/models/stored/user.stored';
import { CorrectionListView } from '@milestone/models/view/correction-list-view';

export const correctionStoredToListView = (
  correction: MilestoneCorrectionStored,
  milestone: MilestoneStored,
  users: Dictionary<UserStored>
): CorrectionListView => {
  return {
    ...correction,
    milestoneFile:
      milestone &&
      correction.fileId &&
      milestone.files.find(f => f.id === correction.fileId),
    createdBy: users[correction.createdById]
  };
};
