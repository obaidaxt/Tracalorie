import { MilestoneCorrectionStored } from '@milestone/models/stored/milestone-correction.stored';
import { MilestoneCorrectionApi } from '@milestone/models/api/milestone-correction.api';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';

export const milestoneCorrectionApiToStored = (
  correction: MilestoneCorrectionApi
): MilestoneCorrectionStored => ({
  ...correction,
  createdAt: new Date(correction.createdAt),
  files: correction.files.map(fileApiToStored)
});
