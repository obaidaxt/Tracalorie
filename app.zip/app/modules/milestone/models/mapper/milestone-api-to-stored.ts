import { MilestoneApi } from '@milestone/models/api/milestone.api';
import { MilestoneStored } from '@milestone/models/stored/milestone.stored';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';

export const milestoneApiToStored = (
  milestone: MilestoneApi
): MilestoneStored => ({
  ...milestone,
  createdAt: new Date(milestone.createdAt),
  files: milestone.files.map(fileApiToStored)
});
