import { FileApi } from '@file/models/api/file.api';
import { MilestoneApprovalApi } from '@milestone/models/api/milestone-approval.api';

export interface MilestoneApi {
  id: number;
  shapeId: number;
  projectId: number;
  identifier: string;
  description: string;
  createdById: string;
  createdAt: string;
  files: FileApi[];
  approvals: MilestoneApprovalApi[];
  responsibles: string[];
}
