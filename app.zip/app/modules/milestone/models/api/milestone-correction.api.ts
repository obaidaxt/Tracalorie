import { FileApi } from '@file/models/api/file.api';

export interface MilestoneCorrectionApi {
  id: number;
  milestoneId: number;
  createdById: string;
  createdAt: string;
  fileId: number | null;
  page: number | null;
  comment: string;
  files: FileApi[];
}
