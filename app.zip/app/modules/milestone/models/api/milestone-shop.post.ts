export interface MilestoneShapePost {
  name: string;
  shortName: string;
  serviceProviders: number[];
}
