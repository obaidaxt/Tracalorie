export interface MilestoneCorrectionPost {
  milestoneId: number;
  milestoneFileId: number | null;
  page: number | null;
  comment: string;
  files: number[];
}
