export interface MilestoneApprovalApi {
  userId: string;
  approved: boolean;
}
