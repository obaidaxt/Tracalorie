export interface MilestoneShapeApi {
  id: number;
  name: string;
  shortName: string;
  default: boolean;
  organizationId: number | null;
  serviceProviderIds: number[];
}
