export interface MilestonePost {
  shapeId: number;
  projectId: number;
  identifier: string;
  description: string;
  files: number[];
  responsibles: string[];
  approvals: string[];
}
