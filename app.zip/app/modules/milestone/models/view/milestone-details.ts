import { MilestoneShapeStored } from '@milestone/models/stored/milestone-shape.stored';
import { MilestoneStored } from '@milestone/models/stored/milestone.stored';

export interface MilestoneDetails extends MilestoneStored {
  shape: MilestoneShapeStored;
  approved: boolean;
  viewName: string;
}
