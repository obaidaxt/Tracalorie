import { MilestoneCorrectionStored } from '@milestone/models/stored/milestone-correction.stored';
import { FileStored } from '@file/models/stored/file.stored';
import { UserStored } from '@organization/models/stored/user.stored';

export interface CorrectionListView extends MilestoneCorrectionStored {
  milestoneFile: FileStored | null;
  createdBy: UserStored;
}
