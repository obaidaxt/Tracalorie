import { MilestoneDetails } from '@milestone/models/view/milestone-details';
import { CorrectionListView } from '@milestone/models/view/correction-list-view';

export interface CorrectionGrouping {
  milestone: MilestoneDetails;
  corrections: CorrectionListView[];
  selected: boolean;
}
