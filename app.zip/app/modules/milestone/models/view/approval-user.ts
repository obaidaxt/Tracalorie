import { UserStored } from '@organization/models/stored/user.stored';

export interface ApprovalUser extends UserStored {
  approvalStatus: 'waiting' | 'approved' | 'correction';
}
