import { FileStored } from '@file/models/stored/file.stored';
import { MilestoneApprovalApi } from '@milestone/models/api/milestone-approval.api';

export interface MilestoneStored {
  id: number;
  shapeId: number;
  projectId: number;
  identifier: string;
  description: string;
  createdById: string;
  createdAt: Date;
  files: FileStored[];
  approvals: MilestoneApprovalApi[];
  responsibles: string[];
}
