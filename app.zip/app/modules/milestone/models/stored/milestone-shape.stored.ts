import { MilestoneShapeApi } from '@milestone/models/api/milestone-shape.api';

export interface MilestoneShapeStored extends MilestoneShapeApi {}
