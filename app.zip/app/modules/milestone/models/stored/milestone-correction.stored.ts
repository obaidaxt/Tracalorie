import { FileStored } from '@file/models/stored/file.stored';

export interface MilestoneCorrectionStored {
  id: number;
  milestoneId: number;
  createdById: string;
  createdAt: Date;
  fileId: number | null;
  page: number | null;
  comment: string;
  files: FileStored[];
}
