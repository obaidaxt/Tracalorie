import { NgModule } from '@angular/core';
import { FileModule } from '@file/file.module';
import { reducers } from '@milestone/state';
import { milestoneEffects } from '@milestone/state/milestone.effects';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SharedModule } from '@shared/shared.module';
import { MilestoneApprovalListComponent } from './components/milestone-approval-list/milestone-approval-list.component';
import { MilestoneConfirmComponent } from './components/milestone-confirm/milestone-confirm.component';
import { MilestoneCorrectionFormComponent } from './components/milestone-correction-form/milestone-correction-form.component';
import { MilestoneCorrectionListComponent } from './components/milestone-correction-list/milestone-correction-list.component';
import { MilestoneFormComponent } from './components/milestone-form/milestone-form.component';
import { MilestoneCorrectionDialogComponent } from './containers/milestone-correction-dialog/milestone-correction-dialog.component';
import { MilestoneDialogComponent } from './containers/milestone-dialog/milestone-dialog.component';
import { AccountModule } from '@account/account.module';

@NgModule({
  imports: [
    SharedModule,
    StoreModule.forFeature('milestone', reducers),
    EffectsModule.forFeature(milestoneEffects),
    FileModule,
    AccountModule
  ],
  declarations: [
    MilestoneApprovalListComponent,
    MilestoneConfirmComponent,
    MilestoneCorrectionFormComponent,
    MilestoneCorrectionListComponent,
    MilestoneFormComponent,
    MilestoneCorrectionDialogComponent,
    MilestoneDialogComponent
  ],
  entryComponents: [
    MilestoneCorrectionDialogComponent,
    MilestoneDialogComponent
  ],
  exports: [
    MilestoneDialogComponent,
    MilestoneCorrectionDialogComponent,
    MilestoneApprovalListComponent,
    MilestoneConfirmComponent,
    MilestoneCorrectionListComponent
  ]
})
export class MilestoneModule {}
