import { Action } from '@ngrx/store';
import { AccountApi } from '../../models/api/account.api';

export enum UserActionTypes {
  LoadAccount = '[User] Load Account',
  LoadAccountSuccess = '[API] Load Account Success',
  LoadAccountFailed = '[API] Load Account Failed',
  Logout = '[User] Logout'
}

export class LoadAccount implements Action {
  readonly type = UserActionTypes.LoadAccount;
}

export class LoadAccountSuccess implements Action {
  readonly type = UserActionTypes.LoadAccountSuccess;
  constructor(public payload: AccountApi) {}
}

export class LoadAccountFailed implements Action {
  readonly type = UserActionTypes.LoadAccountFailed;
  constructor(public error: string) {}
}

export class Logout implements Action {
  readonly type = UserActionTypes.Logout;
  constructor() {}
}

export type UserActions =
  | LoadAccount
  | LoadAccountSuccess
  | LoadAccountFailed
  | Logout;
