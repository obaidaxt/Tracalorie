import * as fromAccount from '../account.reducers';
import { createSelector } from '@ngrx/store';

export const selectUserState = createSelector(
  fromAccount.selectAccountState,
  state => state.user
);

export const selectUserId = createSelector(selectUserState, state => state.id);

export const selectOrganizationId = createSelector(
  selectUserState,
  state => state.organizationId
);

export const selectIsAdmin = createSelector(
  selectUserState,
  state => state.isAdmin
);

export const selectAccountLoadingStatus = createSelector(
  selectUserState,
  state => state.loadingStatus
);

export const selectAccountLoadingError = createSelector(
  selectUserState,
  state => state.loadingError
);
