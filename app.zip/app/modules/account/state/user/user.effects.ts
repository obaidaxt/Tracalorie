import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { AccountService } from '@account/services/account.service';
import { Observable, of } from 'rxjs';
import { Action } from '@ngrx/store';
import {
  UserActionTypes,
  LoadAccountSuccess,
  LoadAccountFailed
} from '@account/state/user/user.actions';
import { switchMap, map, catchError } from 'rxjs/operators';

@Injectable()
export class UserEffects {
  constructor(
    private actions$: Actions,
    private accountService: AccountService
  ) {}

  @Effect()
  loadAccount$: Observable<Action> = this.actions$.pipe(
    ofType(UserActionTypes.LoadAccount),
    switchMap(() =>
      this.accountService.loadAccount().pipe(
        map(account => new LoadAccountSuccess(account)),
        catchError(err => of(new LoadAccountFailed(err)))
      )
    )
  );
}
