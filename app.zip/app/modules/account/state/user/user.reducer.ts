import { LoadingStatus } from '../../../../common/models/loading-status';
import { UserActions, UserActionTypes } from '@account/state/user/user.actions';

export interface State {
  loadingStatus: LoadingStatus;
  loadingError: string;
  id: string;
  organizationId: number;
  isAdmin: boolean;
}

const initialState: State = {
  loadingStatus: LoadingStatus.Waiting,
  loadingError: null,
  id: null,
  organizationId: null,
  isAdmin: false
};

export function reducer(
  state: State = initialState,
  action: UserActions
): State {
  switch (action.type) {
    case UserActionTypes.LoadAccount: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Loading
      };
    }

    case UserActionTypes.LoadAccountSuccess: {
      return {
        loadingStatus: LoadingStatus.Completed,
        id: action.payload.id,
        isAdmin: action.payload.isAdmin,
        loadingError: null,
        organizationId: action.payload.organizationId
      };
    }

    case UserActionTypes.LoadAccountFailed: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Failed,
        loadingError: action.error
      };
    }

    case UserActionTypes.Logout: {
      return initialState;
    }

    default: {
      return state;
    }
  }
}
