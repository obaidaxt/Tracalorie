import { PermissionsEffects } from '@account/state/permissions/permissions.effects';
import { ProfileEffects } from '@account/state/profile/profile.effects';
import { UserEffects } from '@account/state/user/user.effects';

export const accountEffects = [UserEffects, ProfileEffects, PermissionsEffects];
