import { Action } from '@ngrx/store';
import { ProfileStored } from '@account/models/stored/profile.stored';
import {
  ProfileActions,
  ProfileActionTypes
} from '@account/state/profile/profile.actions';
import { LoadAccountSuccess, UserActionTypes } from '../user/user.actions';
import { profileApiToStored } from '@account/models/mapper/profile-api-to-stored';

export interface State {
  profile: ProfileStored;
}

export const initialState: State = {
  profile: null
};

export function reducer(
  state = initialState,
  action: ProfileActions | LoadAccountSuccess
): State {
  switch (action.type) {
    case UserActionTypes.LoadAccountSuccess: {
      return {
        ...state,
        profile: profileApiToStored(action.payload.profile)
      };
    }

    case ProfileActionTypes.Modified: {
      return {
        ...state,
        profile: profileApiToStored(action.payload)
      };
    }

    default: {
      return state;
    }
  }
}
