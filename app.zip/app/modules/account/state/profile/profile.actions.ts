import { Action } from '@ngrx/store';
import { ProfileApi } from '@account/models/api/profile.api';

export enum ProfileActionTypes {
  Modified = '[Websocket] Profile Modified'
}

export class ProfileModified implements Action {
  readonly type = ProfileActionTypes.Modified;
  constructor(public payload: ProfileApi) {}
}

export type ProfileActions = ProfileModified;
