import { createSelector } from '@ngrx/store';
import * as fromAccount from '../account.reducers';

export const selectProfileState = createSelector(
  fromAccount.selectAccountState,
  state => state.profile
);

export const selectProfile = createSelector(
  selectProfileState,
  state => state.profile
);
