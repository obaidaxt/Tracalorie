import {
  PermissionsActions,
  PermissionsActionTypes
} from '@account/state/permissions/permissions.actions';
import { LoadAccountSuccess, UserActionTypes } from '../user/user.actions';

export interface State {
  [permission: string]: State | boolean;
}

export const initialState: State = {};

export function reducer(
  state = initialState,
  action: PermissionsActions | LoadAccountSuccess
): State {
  switch (action.type) {
    case PermissionsActionTypes.Modified: {
      return state;
    }

    case UserActionTypes.LoadAccountSuccess: {
      return action.payload.rights.reduce<State>((prev, curr) => {
        const split = curr.split('.');
        let obj = prev;
        for (let i = 0; i < split.length; i++) {
          if (i === split.length - 1) {
            obj[split[i]] = true;
          } else {
            const subState = {};
            obj[split[i]] = subState;
            obj = subState;
          }
        }
        return prev;
      }, {});
    }

    default: {
      return state;
    }
  }
}
