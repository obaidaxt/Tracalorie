import * as fromAccount from '../account.reducers';
import { createSelector } from '@ngrx/store';

export const selectPermissionsState = createSelector(
  fromAccount.selectAccountState,
  state => state.permissions
);
