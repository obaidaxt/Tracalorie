import { Action } from '@ngrx/store';

export enum PermissionsActionTypes {
  Modified = '[Websocket] Permissions Modified'
}

export class PermissionsModified implements Action {
  readonly type = PermissionsActionTypes.Modified;
  constructor(public changes: { [permission: string]: boolean }) {}
}

export type PermissionsActions = PermissionsModified;
