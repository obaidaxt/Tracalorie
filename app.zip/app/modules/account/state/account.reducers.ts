import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';
import * as fromUser from './user/user.reducer';
import * as fromProfile from './profile/profile.reducer';
import * as fromPermissions from './permissions/permissions.reducer';

export interface AccountState {
  user: fromUser.State;
  profile: fromProfile.State;
  permissions: fromPermissions.State;
}

export interface State {
  account: AccountState;
}

export const reducers: ActionReducerMap<AccountState> = {
  user: fromUser.reducer,
  profile: fromProfile.reducer,
  permissions: fromPermissions.reducer
};

export const selectAccountState = createFeatureSelector<AccountState>(
  'account'
);
