import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { StoreModule } from '@ngrx/store';
import { reducers } from '@account/state/account.reducers';
import { EffectsModule } from '@ngrx/effects';
import { accountEffects } from '@account/state/account.effects';
import { HasPermissionDirective } from '@account/directives/has-permission.directive';

@NgModule({
  imports: [
    SharedModule,
    StoreModule.forFeature('account', reducers),
    EffectsModule.forFeature(accountEffects)
  ],
  declarations: [HasPermissionDirective],
  exports: [HasPermissionDirective]
})
export class AccountModule {}
