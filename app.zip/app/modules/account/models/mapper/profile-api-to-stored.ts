import { ProfileApi } from '@account/models/api/profile.api';
import { ProfileStored } from '@account/models/stored/profile.stored';
import { getInitials } from '@common/functions/get-initials';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';

export const profileApiToStored = (profile: ProfileApi): ProfileStored => ({
  ...profile,
  image: profile.image ? fileApiToStored(profile.image) : null,
  initials: getInitials(profile.name)
});
