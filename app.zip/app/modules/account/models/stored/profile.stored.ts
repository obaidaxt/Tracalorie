import { FileStored } from '@file/models/stored/file.stored';

export interface ProfileStored {
  email: string;
  name: string;
  phone: string;
  emailSignature: string;
  image: FileStored | null;
  initials: string;
}
