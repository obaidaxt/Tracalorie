import { FileApi } from "@file/models/api/file.api";

export interface ProfileApi {
  email: string;
  name: string;
  phone: string;
  emailSignature: string;
  image: FileApi | null;
}
