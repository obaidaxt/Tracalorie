import { ProfileApi } from './profile.api';

export interface AccountApi {
  id: string;
  organizationId: number | null;
  profile: ProfileApi;
  rights: string[];
  isAdmin: boolean;
}
