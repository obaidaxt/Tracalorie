import {
  Directive,
  Input,
  OnDestroy,
  OnInit,
  TemplateRef,
  ViewContainerRef
} from '@angular/core';
import { BehaviorSubject, of, Subject } from 'rxjs';
import { switchMap, takeUntil, withLatestFrom, map } from 'rxjs/operators';
import * as fromAccount from '@account/state';
import { Store } from '@ngrx/store';
import { selectPermissionsState } from '@account/state';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[hasPermission]'
})
export class HasPermissionDirective implements OnInit, OnDestroy {
  @Input()
  set hasPermission(val: string) {
    this.permission$.next(val);
  }
  @Input()
  hasPermissionElse: TemplateRef<any>;
  @Input()
  hasPermissionThen: TemplateRef<any>;

  permission$ = new BehaviorSubject<string>('');
  destroy$ = new Subject<void>();

  constructor(
    private template: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private store: Store<fromAccount.State>
  ) {}

  ngOnInit(): void {
    this.permission$
      .pipe(
        takeUntil(this.destroy$),
        withLatestFrom(this.store.select(selectPermissionsState)),
        map(([permission, permissions]) => {
          const split = permission.split('.');
          let state = permissions;
          for (const sub of split) {
            const permissionState = state[sub];
            if (!permissionState) {
              return false;
            }
            if (typeof permissionState === 'boolean') {
              return permissionState;
            }
            if (permissionState['*']) {
              return true;
            }
            state = permissionState;
          }
          return true;
        })
      )
      .subscribe(hasPermission => {
        this.updateView(hasPermission);
      });
  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  private updateView(show: boolean) {
    this.viewContainer.clear();
    if (show) {
      if (this.hasPermissionThen) {
        this.viewContainer.createEmbeddedView(this.hasPermissionThen);
      } else {
        this.viewContainer.createEmbeddedView(this.template);
      }
    } else {
      if (this.hasPermissionElse) {
        this.viewContainer.createEmbeddedView(this.hasPermissionElse);
      }
    }
  }
}
