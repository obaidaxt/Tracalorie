import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { AccountApi } from '@account/models/api/account.api';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  constructor(private http: HttpClient) {}

  loadAccount(): Observable<AccountApi> {
    return this.http.get<AccountApi>('api/Data/Account');
  }
}
