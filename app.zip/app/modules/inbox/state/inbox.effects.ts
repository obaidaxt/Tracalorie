import { MailTaskEffects } from '@inbox/state/mail-task/mail-task.effects';

export const inboxEffects = [MailTaskEffects];
