import { createSelector } from '@ngrx/store';
import * as fromOrg from '@organization/state';
import * as fromRoot from '@root';
import * as fromInbox from '../inbox.reducers';
import { getMailtaskView } from './get-mailtask-view';
import * as fromMailtask from './mail-task.reducer';

export const selectMailtaskState = createSelector(
  fromInbox.selectInboxState,
  state => state.mailtasks
);

export const selectAllMailtasks = createSelector(
  selectMailtaskState,
  fromMailtask.selectAll
);

export const selectMailtaskEntities = createSelector(
  selectMailtaskState,
  fromMailtask.selectEntities
);

export const selectMailtaskLoadingStatus = createSelector(
  selectMailtaskState,
  fromMailtask.selectLoadingStatus
);

export const selectMailtaskLoadingError = createSelector(
  selectMailtaskState,
  fromMailtask.selectLoadingError
);

export const selectMailtaskView = createSelector(
  selectAllMailtasks,
  fromOrg.selectUserEntities,
  getMailtaskView
);

export const selectCurrentMailtask = createSelector(
  selectMailtaskEntities,
  fromRoot.selectMailtaskId,
  (mailtasks, id) => mailtasks[id]
);
