import { Injectable } from '@angular/core';
import { MatDialog, MatSnackBar } from '@angular/material';
import { MailtaskService } from '@inbox/services/mailtask.service';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Go } from '@root';
import { ConfirmDialogComponent } from '@shared/components/confirm-dialog/confirm-dialog.component';
import { Observable, of } from 'rxjs';
import {
  catchError,
  map,
  mergeMap,
  switchMap,
  takeUntil
} from 'rxjs/operators';
import { DataChangeType } from '../../../../common/models/data-change-type';
import {
  DeleteMailtask,
  DeleteMailtaskCanceled,
  DeleteMailtaskFailed,
  DeleteMailtaskSuccess,
  LoadMailTasksFailed,
  LoadMailTasksSuccess,
  MailTaskActionTypes,
  MailTaskAdded,
  MailTaskModified,
  MailTaskRemoved
} from './mail-task.actions';

@Injectable()
export class MailTaskEffects {
  constructor(
    private actions$: Actions,
    private mailtaskService: MailtaskService,
    private dialog: MatDialog,
    private snackbar: MatSnackBar
  ) {}

  @Effect()
  load$: Observable<Action> = this.actions$.pipe(
    ofType(MailTaskActionTypes.Load),
    switchMap(() =>
      this.mailtaskService.getMailtasks().pipe(
        takeUntil(this.actions$.pipe(ofType(MailTaskActionTypes.CancelLoad))),
        map(mailtasks => new LoadMailTasksSuccess(mailtasks)),
        catchError(err => of(new LoadMailTasksFailed(err)))
      )
    )
  );

  @Effect()
  delete$: Observable<Action> = this.actions$.pipe(
    ofType(MailTaskActionTypes.Delete),
    switchMap(({ payload }: DeleteMailtask) =>
      this.dialog
        .open(ConfirmDialogComponent, {
          data: `Bist du sicher, dass du die Aufgabe unwiderruflich löschen möchtest?`
        })
        .afterClosed()
        .pipe(
          switchMap<boolean, Action>(
            confirmed =>
              confirmed
                ? this.mailtaskService.deleteMailtask(payload.id).pipe(
                    mergeMap(() => [
                      new DeleteMailtaskSuccess(payload.id),
                      new Go({
                        path: [],
                        query: { mailtaskId: undefined },
                        extras: {
                          queryParamsHandling: 'merge'
                        }
                      })
                    ]),
                    catchError(err => of(new DeleteMailtaskFailed(err)))
                  )
                : of(new DeleteMailtaskCanceled())
          )
        )
    )
  );

  @Effect()
  changes$: Observable<Action> = this.actions$.pipe(
    ofType(MailTaskActionTypes.Load),
    switchMap(() =>
      this.mailtaskService.getMailtaskChanges().pipe(
        map(change => {
          switch (change.type) {
            case DataChangeType.Added: {
              return new MailTaskAdded(change.data);
            }
            case DataChangeType.Modified: {
              return new MailTaskModified({
                id: change.id,
                changes: change.data
              });
            }
            case DataChangeType.Removed: {
              return new MailTaskRemoved(change.id);
            }
          }
        })
      )
    )
  );
}
