import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { MailTaskEffects } from './mail-task.effects';

describe('MailTaskService', () => {
  let actions$: Observable<any>;
  let effects: MailTaskEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MailTaskEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(MailTaskEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
