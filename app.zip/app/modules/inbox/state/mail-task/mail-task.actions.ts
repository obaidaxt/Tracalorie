import { MailTaskApi } from '@inbox/models/api/mail-task.api';
import { MailTaskStored } from '@inbox/models/stored/mail-task.stored';
import { Action } from '@ngrx/store';

export enum MailTaskActionTypes {
  Load = '[Mailtask] Load',
  CancelLoad = '[Mailtask] Cancel Load',
  LoadSuccess = '[API] Load Mailtasks Success',
  LoadFailed = '[API] Load Mailtasks Failed',
  Added = '[SignalR] Mailtask Added',
  Modified = '[SignalR] Mailtask Modified',
  Removed = '[SignalR] Mailtask Removed',
  Delete = '[Mailtask] Delete',
  DeleteCanceled = '[Confirm Dialog] Delete Mailtask Canceled',
  DeleteSuccess = '[API] Delete Mailtask Success',
  DeleteFailed = '[API] Delete Mailtask Failed'
}

export class LoadMailTasks implements Action {
  readonly type = MailTaskActionTypes.Load;
  constructor() {}
}

export class CancelLoadMailTasks implements Action {
  readonly type = MailTaskActionTypes.CancelLoad;
  constructor() {}
}

export class LoadMailTasksSuccess implements Action {
  readonly type = MailTaskActionTypes.LoadSuccess;
  constructor(public payload: MailTaskApi[]) {}
}

export class LoadMailTasksFailed implements Action {
  readonly type = MailTaskActionTypes.LoadFailed;
  constructor(public payload: string) {}
}

export class MailTaskAdded implements Action {
  readonly type = MailTaskActionTypes.Added;
  constructor(public payload: MailTaskApi) {}
}

export class MailTaskModified implements Action {
  readonly type = MailTaskActionTypes.Modified;
  constructor(public payload: { id: number; changes: MailTaskApi }) {}
}

export class MailTaskRemoved implements Action {
  readonly type = MailTaskActionTypes.Removed;
  constructor(public payload: number) {}
}

export class DeleteMailtask implements Action {
  readonly type = MailTaskActionTypes.Delete;
  constructor(public payload: MailTaskStored) {}
}

export class DeleteMailtaskCanceled implements Action {
  readonly type = MailTaskActionTypes.DeleteCanceled;
  constructor() {}
}

export class DeleteMailtaskFailed implements Action {
  readonly type = MailTaskActionTypes.DeleteFailed;
  constructor(public payload: string) {}
}

export class DeleteMailtaskSuccess implements Action {
  readonly type = MailTaskActionTypes.DeleteSuccess;
  constructor(public payload: number) {}
}

export type MailTaskActions =
  | LoadMailTasks
  | CancelLoadMailTasks
  | LoadMailTasksSuccess
  | LoadMailTasksFailed
  | MailTaskAdded
  | MailTaskModified
  | MailTaskRemoved
  | DeleteMailtask
  | DeleteMailtaskSuccess
  | DeleteMailtaskFailed
  | DeleteMailtaskCanceled;
