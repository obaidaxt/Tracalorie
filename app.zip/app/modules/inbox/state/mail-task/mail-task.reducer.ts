import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import { MailTaskActions, MailTaskActionTypes } from './mail-task.actions';
import { MailTaskApi } from '@inbox/models/api/mail-task.api';
import { LoadingStatus } from '../../../../common/models/loading-status';
import { MailTaskStored } from '@inbox/models/stored/mail-task.stored';
import { mailtaskApiToStored } from '@inbox/models/mapper/mailtask-api-to-stored';

export interface State extends EntityState<MailTaskStored> {
  loadingStatus: LoadingStatus;
  loadingError: string;
}

export const adapter = createEntityAdapter<MailTaskStored>({
  selectId: mailtask => mailtask.id
});

export const initialState: State = adapter.getInitialState({
  loadingStatus: LoadingStatus.Waiting,
  loadingError: null
});

export function reducer(state = initialState, action: MailTaskActions): State {
  switch (action.type) {
    case MailTaskActionTypes.Load: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Loading
      };
    }

    case MailTaskActionTypes.CancelLoad: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Waiting
      };
    }

    case MailTaskActionTypes.LoadSuccess: {
      return adapter.addAll(action.payload.map(mailtaskApiToStored), {
        ...state,
        loadingStatus: LoadingStatus.Completed
      });
    }

    case MailTaskActionTypes.LoadFailed: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Failed,
        loadingError: action.payload
      };
    }

    case MailTaskActionTypes.Added: {
      return adapter.addOne(mailtaskApiToStored(action.payload), state);
    }

    case MailTaskActionTypes.Modified: {
      return adapter.updateOne(
        {
          id: action.payload.id,
          changes: mailtaskApiToStored(action.payload.changes)
        },
        state
      );
    }

    case MailTaskActionTypes.Removed: {
      return adapter.removeOne(action.payload, state);
    }

    case MailTaskActionTypes.DeleteSuccess: {
      return adapter.removeOne(action.payload, state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
export const selectLoadingStatus = (state: State) => state.loadingStatus;
export const selectLoadingError = (state: State) => state.loadingError;
