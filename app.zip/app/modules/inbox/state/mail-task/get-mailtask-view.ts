import { MailTaskApi } from '@inbox/models/api/mail-task.api';
import { MailTaskStored } from '@inbox/models/stored/mail-task.stored';
import { MailtaskView } from '@inbox/models/view/mailtask-view';
import { Dictionary } from '@ngrx/entity';
import { UserStored } from '@organization/models/stored/user.stored';
import { mailtaskStoredToView } from '@inbox/models/mapper/mailtask-stored-to-view';

export const getMailtaskView = (
  mailtasks: MailTaskStored[],
  users: Dictionary<UserStored>
): MailtaskView[] =>
  mailtasks
    .sort(sortMailtasks)
    .map<MailtaskView>(task => mailtaskStoredToView(task, users));

export const sortMailtasks = (taskA: MailTaskStored, taskB: MailTaskStored) => {
  if (!taskB.date) {
    return -1;
  } else if (!taskA.date) {
    return 1;
  } else {
    return taskB.date.valueOf() - taskA.date.valueOf();
  }
};
