import * as fromMailtasks from './mail-task/mail-task.reducer';
import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';

export interface InboxState {
  mailtasks: fromMailtasks.State;
}

export interface State {
  inbox: InboxState;
}

export const reducers: ActionReducerMap<InboxState> = {
  mailtasks: fromMailtasks.reducer
};

export const selectInboxState = createFeatureSelector<InboxState>('inbox');
