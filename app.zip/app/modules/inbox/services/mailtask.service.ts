import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SignalRService } from '@core/services/signal-r.service';
import { MailTaskApi } from '@inbox/models/api/mail-task.api';

@Injectable({
  providedIn: 'root'
})
export class MailtaskService {
  constructor(private http: HttpClient, private signalR: SignalRService) {}

  getMailtasks() {
    return this.http.get<MailTaskApi[]>('api/ProjectManager');
  }

  deleteMailtask(id: number) {
    return this.http.delete<void>(`api/ProjectManager/${id}`);
  }

  getMailtaskChanges() {
    return this.signalR.getChanges<MailTaskApi, number>('GetMailtaskChanges');
  }
}
