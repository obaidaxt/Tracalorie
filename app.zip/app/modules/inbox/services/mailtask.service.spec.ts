import { TestBed } from '@angular/core/testing';

import { MailtaskService } from './mailtask.service';

describe('MailtaskService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MailtaskService = TestBed.get(MailtaskService);
    expect(service).toBeTruthy();
  });
});
