import { FileApi } from '@file/models/api/file.api';

export interface MailTaskApi {
  id: number;
  title: string;
  description: string;
  senderEmail: string;
  senderUserId: string | null;
  files: FileApi[];
  organizationId: number;
  date: string;
}
