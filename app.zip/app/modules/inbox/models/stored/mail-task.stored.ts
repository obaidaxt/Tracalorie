import { FileStored } from '@file/models/stored/file.stored';

export interface MailTaskStored {
  id: number;
  title: string;
  description: string;
  senderEmail: string;
  senderUserId: string | null;
  files: FileStored[];
  organizationId: number;
  date: Date;
}
