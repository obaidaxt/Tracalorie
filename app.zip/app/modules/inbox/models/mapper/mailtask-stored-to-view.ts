import { MailTaskStored } from '@inbox/models/stored/mail-task.stored';
import { Dictionary } from '@ngrx/entity';
import { UserStored } from '@organization/models/stored/user.stored';
import { MailtaskView } from '@inbox/models/view/mailtask-view';

export const mailtaskStoredToView = (
  mailtask: MailTaskStored,
  users: Dictionary<UserStored>
): MailtaskView => ({
  ...mailtask,
  senderUser: mailtask.senderUserId ? users[mailtask.senderUserId] : null
});
