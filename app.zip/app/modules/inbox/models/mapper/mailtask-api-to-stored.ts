import { MailTaskApi } from '@inbox/models/api/mail-task.api';
import { MailTaskStored } from '@inbox/models/stored/mail-task.stored';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';

export const mailtaskApiToStored = (mailtask: MailTaskApi): MailTaskStored => ({
  ...mailtask,
  date: new Date(mailtask.date),
  files: mailtask.files.map(fileApiToStored)
});
