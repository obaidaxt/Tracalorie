import { MailTaskStored } from '@inbox/models/stored/mail-task.stored';
import { UserStored } from '@organization/models/stored/user.stored';

export interface MailtaskView extends MailTaskStored {
  senderUser: UserStored | null;
}
