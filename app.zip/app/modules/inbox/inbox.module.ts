import { NgModule } from '@angular/core';
import { OrganizationModule } from '@organization/organization.module';
import { SharedModule } from '@shared/shared.module';

@NgModule({
  imports: [SharedModule, OrganizationModule],
  declarations: []
})
export class InboxModule {}
