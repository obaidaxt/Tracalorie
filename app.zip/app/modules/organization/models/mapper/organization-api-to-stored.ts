import { OrganizationApi } from '@organization/models/api/organization.api';
import { OrganizationStored } from '@organization/models/stored/organization.stored';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';

export const organizationApiToStored = (
  organization: OrganizationApi
): OrganizationStored => ({
  ...organization,
  logo: organization.logo ? fileApiToStored(organization.logo) : null
});
