import { UserApi } from '@organization/models/api/user.api';
import { UserStored } from '@organization/models/stored/user.stored';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';
import { getInitials } from '@common/functions/get-initials';

export const userApiToStored = (user: UserApi): UserStored => ({
  ...user,
  image: user.image ? fileApiToStored(user.image) : null,
  initials: getInitials(user.name)
});
