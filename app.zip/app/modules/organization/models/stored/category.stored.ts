export interface CategoryStored {
  id: number;
  name: string;
  organizationId: number | null;
}
