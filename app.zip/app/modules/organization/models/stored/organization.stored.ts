import { FileStored } from '@file/models/stored/file.stored';
import { OrganizationRelationType } from '@organization/models/api/organization-relation-type.enum';
import { PartnerInvitationStatus } from '@organization/models/api/parnter-invitation-status.enum';

export interface OrganizationStored {
  id: number;
  name: string;
  shortName: string;
  logo: FileStored | null;
  relation: OrganizationRelationType;
  status: PartnerInvitationStatus | null;
}
