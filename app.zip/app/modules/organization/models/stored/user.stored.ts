import { FileStored } from '@file/models/stored/file.stored';

export interface UserStored {
  id: string;
  name: string;
  initials: string;
  email: string;
  image: FileStored | null;
  phone: string;
  organizationId: number | null;
}
