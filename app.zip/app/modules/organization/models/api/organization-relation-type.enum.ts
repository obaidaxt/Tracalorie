export enum OrganizationRelationType {
  Own,
  Customer,
  ServiceProvider,
  Other
}
