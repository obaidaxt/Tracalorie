export interface CategoryApi {
  id: number;
  name: string;
  organizationId: number | null;
}
