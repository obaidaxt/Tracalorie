import { FileApi } from "@file/models/api/file.api";
import { OrganizationRelationType } from "./organization-relation-type.enum";
import { PartnerInvitationStatus } from "@organization/models/api/parnter-invitation-status.enum";

export interface OrganizationApi {
  id: number;
  name: string;
  shortName: string;
  logo: FileApi | null;
  relation: OrganizationRelationType;
  status: PartnerInvitationStatus | null;
}
