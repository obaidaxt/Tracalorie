export interface OrganizationUpdatePost {
  name: string;
  shortName: string;
  logoId: number | null;
}
