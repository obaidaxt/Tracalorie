import { FileApi } from '@file/models/api/file.api';

export interface UserApi {
  id: string;
  name: string;
  email: string;
  image: FileApi | null;
  phone: string;
  organizationId: number | null;
}
