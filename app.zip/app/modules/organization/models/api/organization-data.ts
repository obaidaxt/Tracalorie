import { OrganizationApi } from './organization.api';
import { CategoryApi } from './category.api';
import { UserApi } from './user.api';

export interface OrganizatonData {
  organizations: OrganizationApi[];
  categories: CategoryApi[];
  users: UserApi[];
}
