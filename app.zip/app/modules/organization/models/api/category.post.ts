export interface CategoryPost {
  name: string;
}
