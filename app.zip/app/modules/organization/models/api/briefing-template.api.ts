import { BriefingAttributeType } from 'app/modules/organization-admin/models/api/briefing-attribute-type.enum';
import { TextAttributeType } from 'app/modules/organization-admin/models/api/text-attribute-type.enum';

export interface BriefingTemplateApi {
  id: number;
  customerId: number;
  groups: BriefingTemplateGroupApi[];
}

export interface BriefingTemplateGroupApi {
  name: string;
  order: number;
  attributes: BriefingTemplateAttributeApi[];
}

export interface BriefingTemplateAttributeApi {
  id: number;
  type: BriefingAttributeType;
  name: string;
  required: boolean;
  order: number;
  textType: TextAttributeType;
  multiple: boolean;
  restrict: string[];
  options: BriefingSelectAttributeOptionApi[];
}

export interface BriefingSelectAttributeOptionApi {
  id: number | null;
  name: string;
  order: number;
}
