import { PartnerRelationType } from "@organization/models/api/partner-relation-type.enum";

export interface PartnerRequestPost {
  email: string;
  name: string;
  relationType: PartnerRelationType;
}
