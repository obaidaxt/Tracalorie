export enum PartnerInvitationStatus {
  Send,
  Received,
  Rejected,
  RejectionReceived,
  Confirmed
}
