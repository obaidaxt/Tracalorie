export enum PartnerRelationType {
  ServiceCustomer,
  Customer
}
