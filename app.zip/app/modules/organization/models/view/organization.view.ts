import { OrganizationStored } from '@organization/models/stored/organization.stored';

export interface OrganizationView extends OrganizationStored {}
