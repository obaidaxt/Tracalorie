import { UserStored } from '@organization/models/stored/user.stored';

export interface UserView extends UserStored {}
