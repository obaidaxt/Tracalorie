import { CategoryStored } from '@organization/models/stored/category.stored';

export interface CategoryView extends CategoryStored {}
