import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { CategoryService } from '@organization/services/category.service';
import { Observable, of } from 'rxjs';
import { Action } from '@ngrx/store';
import {
  CategoriesActionTypes,
  CreateCategory,
  CreateCategorySuccess,
  CreateCategoryFailed,
  UpdateCategory,
  UpdateCategorySuccess,
  UpdateCategoryFailed,
  DeleteCategory,
  DeleteCategorySuccess,
  DeleteCategoryFailed
} from '@organization/state/categories/categories.actions';
import { switchMap, map, catchError } from 'rxjs/operators';

@Injectable()
export class CategoriesEffects {
  constructor(
    private actions$: Actions,
    private categoryService: CategoryService
  ) {}

  @Effect()
  create$: Observable<Action> = this.actions$.pipe(
    ofType(CategoriesActionTypes.Create),
    switchMap(({ payload }: CreateCategory) =>
      this.categoryService.createCategory(payload).pipe(
        map(category => new CreateCategorySuccess(category)),
        catchError(err => of(new CreateCategoryFailed(err)))
      )
    )
  );

  @Effect()
  update$: Observable<Action> = this.actions$.pipe(
    ofType(CategoriesActionTypes.Update),
    switchMap(({ payload, categoryId }: UpdateCategory) =>
      this.categoryService.updateCategory(categoryId, payload).pipe(
        map(
          changes =>
            new UpdateCategorySuccess({
              id: categoryId,
              changes
            })
        ),
        catchError(err => of(new UpdateCategoryFailed(err)))
      )
    )
  );

  @Effect()
  delete$: Observable<Action> = this.actions$.pipe(
    ofType(CategoriesActionTypes.Delete),
    switchMap(({ categoryId }: DeleteCategory) =>
      this.categoryService.deleteCategory(categoryId).pipe(
        map(() => new DeleteCategorySuccess(categoryId)),
        catchError(err => of(new DeleteCategoryFailed(err)))
      )
    )
  );
}
