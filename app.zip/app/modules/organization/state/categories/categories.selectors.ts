import * as fromOrganization from '../organization.reducers';
import * as fromCategories from './categories.reducer';
import { createSelector } from '@ngrx/store';
import { selectOrganizationId } from '@account/state';

export const selectCategoryState = createSelector(
  fromOrganization.selectOrganizationState,
  state => state.categories
);

export const selectAllCategories = createSelector(
  selectCategoryState,
  fromCategories.selectAll
);

export const selectCategoryFormStatus = createSelector(
  selectCategoryState,
  fromCategories.selectFormStatus
);

export const selectCategoryFormError = createSelector(
  selectCategoryState,
  fromCategories.selectFormError
);

export const selectOwnCategories = createSelector(
  selectAllCategories,
  selectOrganizationId,
  (categories, orgId) => categories.filter(c => c.organizationId === orgId)
);
