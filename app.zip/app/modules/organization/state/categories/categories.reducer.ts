import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { CategoryStored } from '@organization/models/stored/category.stored';
import {
  CategoriesActions,
  CategoriesActionTypes,
  CategoryAdded
} from './categories.actions';
import {
  LoadOrganizationDataSuccess,
  OrganizationsActionTypes
} from '../organizations/organizations.actions';
import { LoadingStatus } from '@common/models/loading-status';

export interface State extends EntityState<CategoryStored> {
  formStatus: LoadingStatus;
  formError: string;
}

export const adapter: EntityAdapter<CategoryStored> = createEntityAdapter<
  CategoryStored
>({
  selectId: category => category.id
});

export const initialState: State = adapter.getInitialState({
  formStatus: LoadingStatus.Waiting,
  formError: null
});

export function reducer(
  state = initialState,
  action: CategoriesActions | LoadOrganizationDataSuccess
): State {
  switch (action.type) {
    case OrganizationsActionTypes.LoadOrganizationDataSuccess: {
      return adapter.addAll(action.payload.categories, state);
    }

    case CategoriesActionTypes.Added: {
      return adapter.addOne(action.category, state);
    }

    case CategoriesActionTypes.Modified: {
      return adapter.updateOne(action.payload, state);
    }

    case CategoriesActionTypes.Removed: {
      return adapter.removeOne(action.categoryId, state);
    }

    case CategoriesActionTypes.ResetForm: {
      return {
        ...state,
        formStatus: LoadingStatus.Waiting,
        formError: null
      };
    }

    case CategoriesActionTypes.Update:
    case CategoriesActionTypes.Create: {
      return {
        ...state,
        formStatus: LoadingStatus.Loading
      };
    }

    case CategoriesActionTypes.UpdateSuccess: {
      return adapter.updateOne(action.update, {
        ...state,
        formStatus: LoadingStatus.Completed
      });
    }

    case CategoriesActionTypes.CreateSuccess: {
      return adapter.addOne(action.category, {
        ...state,
        formStatus: LoadingStatus.Completed
      });
    }

    case CategoriesActionTypes.UpdateFailed:
    case CategoriesActionTypes.CreateFailed: {
      return {
        ...state,
        formStatus: LoadingStatus.Failed,
        formError: action.error
      };
    }

    case CategoriesActionTypes.DeleteSuccess: {
      return adapter.removeOne(action.categoryId, state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
export const selectFormStatus = (state: State) => state.formStatus;
export const selectFormError = (state: State) => state.formError;
