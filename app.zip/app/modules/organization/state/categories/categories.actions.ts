import { Update } from '@ngrx/entity';
import { Action } from '@ngrx/store';
import { CategoryPost } from '@organization/models/api/category.post';
import { CategoryStored } from '@organization/models/stored/category.stored';

export enum CategoriesActionTypes {
  Added = '[Websocket] Category Added',
  Modified = '[Websocket] Category Modified',
  Removed = '[Websocket] Category Removed',
  ResetForm = '[Category Dialog] Reset Form',
  Create = '[Category Dialog] Create Category',
  CreateSuccess = '[API] Create Category Success',
  CreateFailed = '[API] Create Category Failed',
  Update = '[Category Diaog] Update Category',
  UpdateSuccess = '[API] Update Category Success',
  UpdateFailed = '[API] Update Category Failed',
  Delete = '[Category Admin] Delete Category',
  DeleteSuccess = '[API] Delete Category Success',
  DeleteFailed = '[API] Delete Category Failed'
}

export class CategoryAdded implements Action {
  readonly type = CategoriesActionTypes.Added;
  constructor(public category: CategoryStored) {}
}

export class CategoryModified implements Action {
  readonly type = CategoriesActionTypes.Modified;
  constructor(public payload: Update<CategoryStored>) {}
}

export class CategoryRemoved implements Action {
  readonly type = CategoriesActionTypes.Removed;
  constructor(public categoryId: number) {}
}

export class ResetCategoryForm implements Action {
  readonly type = CategoriesActionTypes.ResetForm;
}

export class CreateCategory implements Action {
  readonly type = CategoriesActionTypes.Create;
  constructor(public payload: CategoryPost) {}
}

export class CreateCategorySuccess implements Action {
  readonly type = CategoriesActionTypes.CreateSuccess;
  constructor(public category: CategoryStored) {}
}

export class CreateCategoryFailed implements Action {
  readonly type = CategoriesActionTypes.CreateFailed;
  constructor(public error: string) {}
}

export class UpdateCategory implements Action {
  readonly type = CategoriesActionTypes.Update;
  constructor(public categoryId: number, public payload: CategoryPost) {}
}

export class UpdateCategorySuccess implements Action {
  readonly type = CategoriesActionTypes.UpdateSuccess;
  constructor(public update: Update<CategoryStored>) {}
}

export class UpdateCategoryFailed implements Action {
  readonly type = CategoriesActionTypes.UpdateFailed;
  constructor(public error: string) {}
}

export class DeleteCategory implements Action {
  readonly type = CategoriesActionTypes.Delete;
  constructor(public categoryId: number) {}
}

export class DeleteCategorySuccess implements Action {
  readonly type = CategoriesActionTypes.DeleteSuccess;
  constructor(public categoryId: number) {}
}

export class DeleteCategoryFailed implements Action {
  readonly type = CategoriesActionTypes.DeleteFailed;
  constructor(public error: string) {}
}

export type CategoriesActions =
  | CategoryAdded
  | CategoryModified
  | CategoryRemoved
  | ResetCategoryForm
  | CreateCategory
  | CreateCategorySuccess
  | CreateCategoryFailed
  | UpdateCategory
  | UpdateCategorySuccess
  | UpdateCategoryFailed
  | DeleteCategory
  | DeleteCategorySuccess
  | DeleteCategoryFailed;
