import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';
import * as fromOrganizations from './organizations/organizations.reducer';
import * as fromCategories from './categories/categories.reducer';
import * as fromUsers from './users/users.reducer';
import {
  BriefingTemplateState,
  briefingTemplateReducer
} from './briefing-template/briefing-template.reducer';

export interface OrganizationState {
  organizations: fromOrganizations.State;
  categories: fromCategories.State;
  users: fromUsers.State;
  briefingTemplates: BriefingTemplateState;
}

export interface State {
  organization: OrganizationState;
}

export const reducers: ActionReducerMap<OrganizationState> = {
  organizations: fromOrganizations.reducer,
  categories: fromCategories.reducer,
  users: fromUsers.reducer,
  briefingTemplates: briefingTemplateReducer
};

export const selectOrganizationState = createFeatureSelector<OrganizationState>(
  'organization'
);
