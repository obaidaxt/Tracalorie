import { CategoriesEffects } from '@organization/state/categories/categories.effects';
import { OrganizationsEffects } from '@organization/state/organizations/organizations.effects';
import { UsersEffects } from '@organization/state/users/users.effects';
import { BriefingTemplateEffects } from './briefing-template/briefing-template.effects';

export const organizationEffects = [
  OrganizationsEffects,
  CategoriesEffects,
  UsersEffects,
  BriefingTemplateEffects
];
