import { Action } from '@ngrx/store';
import { OrganizatonData } from '@organization/models/api/organization-data';
import { OrganizationApi } from '@organization/models/api/organization.api';
import { PartnerRequestPost } from '@organization/models/api/partner-request.post';
import { OrganizationStored } from '@organization/models/stored/organization.stored';
import { OrganizationUpdatePost } from '@organization/models/api/organization-update.post';
import { Update } from '@ngrx/entity';

export enum OrganizationsActionTypes {
  LoadOrganizationData = '[Protected Module] Load Organization Data',
  LoadOrganizationDataSuccess = '[API] Load Organization Data Success',
  LoadOrganizationDataFailed = '[API] Load Organization Data Failed',
  Added = '[Websocket] Organization Added',
  Modified = '[Websocket] Organization Modified',
  Removed = '[Websocket] Organization Removed',
  ResetForm = '[Partner Dialog] Reset Partner Form',
  SendRequest = '[Partner Dialog] Send Partner Request',
  SendRequestSuccess = '[API] Send Partner Request Success',
  SendRequestFailed = '[API] Send Partner Request Failed',
  AcceptRequest = '[Partner Overview] Accept Partner Request',
  AcceptRequestSuccess = '[API] Accept Partner Request Success',
  AcceptRequestFailed = '[API] Accept Partner Request Failed',
  RejectRequest = '[Partner Overview] Reject Partner Request',
  RejectRequestSuccess = '[API] Reject Partner Request Success',
  RejectRequestFailed = '[API] Reject Partner Request Failed',
  RemovePartner = '[Partner Overview] Remove Partner',
  RemovePartnerSuccess = '[API] Remove Partner Success',
  RemovePartnerFailed = '[API] Remove Partner Failed',
  Update = '[Org Form] Update Organization',
  UpdateSuccess = '[API] Update Organization Success',
  UpdateFailed = '[API] Update Organization Failed'
}

export class LoadOrganizationData implements Action {
  readonly type = OrganizationsActionTypes.LoadOrganizationData;
  constructor() {}
}

export class LoadOrganizationDataSuccess implements Action {
  readonly type = OrganizationsActionTypes.LoadOrganizationDataSuccess;
  constructor(public payload: OrganizatonData) {}
}

export class LoadOrganizationDataFailed implements Action {
  readonly type = OrganizationsActionTypes.LoadOrganizationDataFailed;
  constructor(public error: string) {}
}

export class OrganizationAdded implements Action {
  readonly type = OrganizationsActionTypes.Added;
  constructor(public organization: OrganizationApi) {}
}

export class OrganizationModified implements Action {
  readonly type = OrganizationsActionTypes.Modified;
  constructor(public organization: OrganizationApi) {}
}

export class OrganizationRemoved implements Action {
  readonly type = OrganizationsActionTypes.Removed;
  constructor(public organizationId: number) {}
}

export class ResetOrganizationForm implements Action {
  readonly type = OrganizationsActionTypes.ResetForm;
}

export class SendPartnerRequest implements Action {
  readonly type = OrganizationsActionTypes.SendRequest;
  constructor(public payload: PartnerRequestPost) {}
}

export class SendPartnerRequestSuccess implements Action {
  readonly type = OrganizationsActionTypes.SendRequestSuccess;
  constructor(public organization: OrganizationStored) {}
}

export class SendPartnerRequestFailed implements Action {
  readonly type = OrganizationsActionTypes.SendRequestFailed;
  constructor(public error: string) {}
}

export class AcceptPartnerRequest implements Action {
  readonly type = OrganizationsActionTypes.AcceptRequest;
  constructor(public id: number) {}
}

export class AcceptPartnerRequestSuccess implements Action {
  readonly type = OrganizationsActionTypes.AcceptRequestSuccess;
  constructor(public id: number) {}
}

export class AcceptPartnerRequestFailed implements Action {
  readonly type = OrganizationsActionTypes.AcceptRequestFailed;
  constructor(public error: string) {}
}

export class RejectPartnerRequest implements Action {
  readonly type = OrganizationsActionTypes.RejectRequest;
  constructor(public id: number) {}
}

export class RejectPartnerRequestSuccess implements Action {
  readonly type = OrganizationsActionTypes.RejectRequestSuccess;
  constructor(public id: number) {}
}

export class RejectPartnerRequestFailed implements Action {
  readonly type = OrganizationsActionTypes.RejectRequestFailed;
  constructor(public error: string) {}
}

export class RemovePartner implements Action {
  readonly type = OrganizationsActionTypes.RemovePartner;
  constructor(public id: number) {}
}

export class RemovePartnerSuccess implements Action {
  readonly type = OrganizationsActionTypes.RemovePartnerSuccess;
  constructor(public id: number) {}
}

export class RemovePartnerFailed implements Action {
  readonly type = OrganizationsActionTypes.RemovePartnerFailed;
  constructor(public error: string) {}
}

export class UpdateOrganization implements Action {
  readonly type = OrganizationsActionTypes.Update;
  constructor(public payload: OrganizationUpdatePost) {}
}

export class UpdateOrganizationSuccess implements Action {
  readonly type = OrganizationsActionTypes.UpdateSuccess;
  constructor(public payload: Update<OrganizationStored>) {}
}

export class UpdateOrganizationFailed implements Action {
  readonly type = OrganizationsActionTypes.UpdateFailed;
  constructor(public error: string) {}
}

export type OrganizationsActions =
  | LoadOrganizationData
  | LoadOrganizationDataSuccess
  | LoadOrganizationDataFailed
  | OrganizationAdded
  | OrganizationModified
  | OrganizationRemoved
  | ResetOrganizationForm
  | SendPartnerRequest
  | SendPartnerRequestSuccess
  | SendPartnerRequestFailed
  | AcceptPartnerRequest
  | AcceptPartnerRequestSuccess
  | AcceptPartnerRequestFailed
  | RejectPartnerRequest
  | RejectPartnerRequestSuccess
  | RejectPartnerRequestFailed
  | RemovePartner
  | RemovePartnerSuccess
  | RemovePartnerFailed
  | UpdateOrganization
  | UpdateOrganizationSuccess
  | UpdateOrganizationFailed;
