import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { BriefingTemplateEffects } from './briefing-template.effects';

describe('BriefingTemplateEffects', () => {
  let actions$: Observable<any>;
  let effects: BriefingTemplateEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        BriefingTemplateEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(BriefingTemplateEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
