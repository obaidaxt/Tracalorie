import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import {
  BriefingTemplateActions,
  BriefingTemplateActionTypes
} from './briefing-template.actions';
import { BriefingTemplateApi } from '@organization/models/api/briefing-template.api';

export interface BriefingTemplateState extends EntityState<BriefingTemplateApi> {}

export const adapter = createEntityAdapter<BriefingTemplateApi>();

export const initialState: BriefingTemplateState = adapter.getInitialState({});

export function briefingTemplateReducer(
  state = initialState,
  action: BriefingTemplateActions
): BriefingTemplateState {
  switch (action.type) {
    case BriefingTemplateActionTypes.LoadSuccess: {
      return adapter.addAll(action.templates, state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
