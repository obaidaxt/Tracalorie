import { createSelector } from '@ngrx/store';
import { selectOrganizationState } from '../organization.reducers';
import * as fromTemplates from './briefing-template.reducer';

export const selectBriefingTemplateState = createSelector(
  selectOrganizationState,
  state => state.briefingTemplates
);

export const selectAllBriefingTemplates = createSelector(
  selectBriefingTemplateState,
  fromTemplates.selectAll
);

export const selectBriefingTemplateEntities = createSelector(
  selectBriefingTemplateState,
  fromTemplates.selectEntities
);
