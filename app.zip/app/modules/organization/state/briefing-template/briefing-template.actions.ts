import { Action } from '@ngrx/store';
import { Update } from '@ngrx/entity';
import { BriefingTemplateApi } from '@organization/models/api/briefing-template.api';

export enum BriefingTemplateActionTypes {
  Load = '[Overview] Load Briefing Templates',
  StopLoad = '[Overview] Stop Load Briefing Templates',
  LoadSuccess = '[API] Load Briefing Templates Success',
  LoadFailed = '[API] Load Briefing Templates Failed',
  Added = '[Websocket] Briefing Template Added',
  Modified = '[Websocket] Briefing Template Modified',
  Removed = '[Websocket] Briefing Template Removed'
}

export class LoadBriefingTemplates implements Action {
  readonly type = BriefingTemplateActionTypes.Load;
}

export class StopLoadBriefingTemplates implements Action {
  readonly type = BriefingTemplateActionTypes.StopLoad;
}

export class LoadBriefingTemplatesSuccess implements Action {
  readonly type = BriefingTemplateActionTypes.LoadSuccess;
  constructor(public templates: BriefingTemplateApi[]) {}
}

export class LoadBriefingTemplatesFailed implements Action {
  readonly type = BriefingTemplateActionTypes.LoadFailed;
  constructor(public error: string) {}
}

export class BriefingTemplateAdded implements Action {
  readonly type = BriefingTemplateActionTypes.Added;
  constructor(public template: BriefingTemplateApi) {}
}

export class BriefingTemplateModified implements Action {
  readonly type = BriefingTemplateActionTypes.Modified;
  constructor(public payload: Update<BriefingTemplateApi>) {}
}

export class BriefingTemplateRemoved implements Action {
  readonly type = BriefingTemplateActionTypes.Removed;
  constructor(public id: number) {}
}

export type BriefingTemplateActions =
  | LoadBriefingTemplates
  | LoadBriefingTemplatesSuccess
  | LoadBriefingTemplatesFailed
  | BriefingTemplateAdded
  | BriefingTemplateModified
  | BriefingTemplateRemoved;
