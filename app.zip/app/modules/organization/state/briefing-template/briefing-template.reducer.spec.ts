import { briefingTemplateReducer, initialState } from './briefing-template.reducer';

describe('BriefingTemplate Reducer', () => {
  describe('unknown action', () => {
    it('should return the initial state', () => {
      const action = {} as any;

      const result = briefingTemplateReducer(initialState, action);

      expect(result).toBe(initialState);
    });
  });
});
