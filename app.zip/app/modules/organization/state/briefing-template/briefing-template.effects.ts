import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { Action } from '@ngrx/store';
import {
  BriefingTemplateActionTypes,
  LoadBriefingTemplatesSuccess,
  LoadBriefingTemplatesFailed
} from './briefing-template.actions';
import { switchMap, map, catchError } from 'rxjs/operators';
import { BriefingTemplateService } from '@organization/services/briefing-template.service';

@Injectable()
export class BriefingTemplateEffects {
  constructor(
    private actions$: Actions,
    private templateService: BriefingTemplateService
  ) {}

  @Effect()
  load$: Observable<Action> = this.actions$.pipe(
    ofType(BriefingTemplateActionTypes.Load),
    switchMap(() =>
      this.templateService.loadTemplates().pipe(
        map(templates => new LoadBriefingTemplatesSuccess(templates)),
        catchError(err => of(new LoadBriefingTemplatesFailed(err)))
      )
    )
  );
}
