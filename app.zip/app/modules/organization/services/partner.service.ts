import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PartnerRequestPost } from '@organization/models/api/partner-request.post';
import { OrganizationApi } from '@organization/models/api/organization.api';

@Injectable({
  providedIn: 'root'
})
export class PartnerService {
  constructor(private http: HttpClient) {}

  sendRequest(payload: PartnerRequestPost) {
    return this.http.post<OrganizationApi>('api/Partner/SendRequest', payload);
  }

  acceptRequest(id: number) {
    return this.http.get<void>(`api/Partner/AcceptRequest/${id}`);
  }

  rejectRequest(id: number) {
    return this.http.get<void>(`api/Partner/RejectRequest/${id}`);
  }

  removeParnter(id: number) {
    return this.http.delete<void>(`api/Partner/Remove/${id}`);
  }
}
