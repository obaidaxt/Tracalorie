import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BriefingTemplateApi } from '@organization/models/api/briefing-template.api';

@Injectable({
  providedIn: 'root'
})
export class BriefingTemplateService {
  constructor(private http: HttpClient) {}

  loadTemplates() {
    return this.http.get<BriefingTemplateApi[]>('api/Data/BriefingTemplates');
  }
}
