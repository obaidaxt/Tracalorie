import { TestBed } from '@angular/core/testing';

import { BriefingTemplateService } from './briefing-template.service';

describe('BriefingTemplateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BriefingTemplateService = TestBed.get(BriefingTemplateService);
    expect(service).toBeTruthy();
  });
});
