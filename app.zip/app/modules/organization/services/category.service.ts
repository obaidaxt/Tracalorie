import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CategoryPost } from '@organization/models/api/category.post';
import { CategoryApi } from '@organization/models/api/category.api';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  constructor(private http: HttpClient) {}

  createCategory(payload: CategoryPost) {
    return this.http.post<CategoryApi>('api/Category/Create', payload);
  }

  updateCategory(id: number, payload: CategoryPost) {
    return this.http.put<CategoryApi>(`api/Category/Update/${id}`, payload);
  }

  deleteCategory(id: number) {
    return this.http.delete<void>(`api/Category/Delete/${id}`);
  }
}
