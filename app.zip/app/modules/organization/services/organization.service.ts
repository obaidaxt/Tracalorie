import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SignalRService } from '@core/services/signal-r.service';
import { Observable } from 'rxjs';
import { OrganizatonData } from '@organization/models/api/organization-data';
import { OrganizationUpdatePost } from '@organization/models/api/organization-update.post';
import { OrganizationApi } from '@organization/models/api/organization.api';

@Injectable({
  providedIn: 'root'
})
export class OrganizationService {
  constructor(private http: HttpClient, private signalR: SignalRService) {}

  getOrganizationData(): Observable<OrganizatonData> {
    return this.http.get<OrganizatonData>('api/Data/Organization');
  }

  updateOrganization(payload: OrganizationUpdatePost) {
    return this.http.post<OrganizationApi>('api/Organization/Update', payload);
  }
}
