import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { organizationEffects } from '@organization/state/organization.effects';
import { reducers } from '@organization/state/organization.reducers';
import { SharedModule } from '@shared/shared.module';
import { AccountModule } from '@account/account.module';
import { OrganizationLogoComponent } from './components/organization-logo/organization-logo.component';

@NgModule({
  imports: [
    SharedModule,
    StoreModule.forFeature('organization', reducers),
    EffectsModule.forFeature(organizationEffects),
    AccountModule
  ],
  declarations: [OrganizationLogoComponent],
  exports: [OrganizationLogoComponent]
})
export class OrganizationModule {}
