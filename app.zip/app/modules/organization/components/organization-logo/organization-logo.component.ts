import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { OrganizationStored } from '@organization/models/stored/organization.stored';

@Component({
  selector: 'app-organization-logo',
  templateUrl: './organization-logo.component.html',
  styleUrls: ['./organization-logo.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OrganizationLogoComponent implements OnInit {
  @Input() organization: OrganizationStored;

  constructor() { }

  ngOnInit() {
  }

}
