import { NgModule } from '@angular/core';
import { UploadIconComponent } from '@file/components/upload-icon/upload-icon.component';
import { SharedModule } from '@shared/shared.module';
import { UploadComponent } from './components/upload/upload.component';
import { FileOverviewComponent } from './components/file-overview/file-overview.component';

@NgModule({
  imports: [SharedModule],
  declarations: [UploadComponent, UploadIconComponent, FileOverviewComponent],
  exports: [UploadComponent, UploadIconComponent, FileOverviewComponent]
})
export class FileModule {}
