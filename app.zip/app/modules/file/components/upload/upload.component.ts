import {
  ChangeDetectionStrategy,
  Component,
  forwardRef,
  OnInit,
  Input,
  OnDestroy,
  ViewChild,
  ElementRef,
  HostListener
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { FileService } from '@file/services/file.service';
import { FileStored } from '@file/models/stored/file.stored';
import { Subject, BehaviorSubject, Observable, combineLatest } from 'rxjs';
import { UploadingFile } from '@file/models/view/uploading-file';
import { takeUntil, filter, map } from 'rxjs/operators';
import { HttpEventType } from '@angular/common/http';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';
import { UploadingFileStatus } from '@file/models/view/uploading-file-status.enum';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => UploadComponent),
      multi: true
    }
  ]
})
export class UploadComponent
  implements OnInit, OnDestroy, ControlValueAccessor {
  @Input()
  disabled = false;
  @Input()
  multiple = true;
  @Input()
  label = 'Dateien';
  @Input()
  initialUploads: FileList;

  files$ = new BehaviorSubject<FileStored[]>([]);
  uploads$ = new BehaviorSubject<UploadingFile[]>([]);
  destroy$ = new Subject<void>();
  cancel$ = new Subject<File>();
  windowDrag$ = new BehaviorSubject<boolean>(false);
  dragOver$ = new BehaviorSubject<boolean>(false);
  containerClass$: Observable<string>;

  onChange = (value: FileStored[] | FileStored) => {};
  onTouched = () => {};

  @ViewChild('uploadInput')
  uploadElementRef: ElementRef;

  get uploadInput() {
    return this.uploadElementRef.nativeElement as HTMLInputElement;
  }

  constructor(private fileService: FileService) {}

  ngOnInit() {
    this.getContainerClass();
    this.initalUpload();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private getContainerClass() {
    this.containerClass$ = combineLatest(this.windowDrag$, this.dragOver$).pipe(
      map(([windowDrag, dragOver]) => {
        if (dragOver) {
          return 'drag-over';
        } else if (windowDrag) {
          return 'window-drag';
        } else {
          return null;
        }
      })
    );
  }

  private initalUpload() {
    if (this.initialUploads) {
      for (let i = 0; i < this.initialUploads.length; i++) {
        this.uploadFile(this.initialUploads.item(i));
      }
    }
  }

  writeValue(value: FileStored[] | FileStored): void {
    if (value instanceof Array) {
      this.files$.next(value);
      this.onChange(value);
    } else {
      const files = value ? [value] : [];
      this.files$.next(files);
      this.onChange(value);
    }
  }

  registerOnChange(fn: (value: FileStored[] | FileStored) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  handleDragEnter(event: DragEvent) {
    this.dragOver$.next(true);
  }

  handleDragLeave(event: DragEvent) {
    this.dragOver$.next(false);
  }

  handleDrop(e: DragEvent) {
    e.preventDefault();
    const files = e.dataTransfer.files;
    this.uploadFiles(files);
    this.uploadInput.value = '';
    // TODO: file transfer text -> url -> datei download
    const downloadUrl = e.dataTransfer.getData('TEXT');
  }

  handleInputChange(e: Event) {
    const files = this.uploadInput.files;
    this.uploadFiles(files);
    this.uploadInput.value = '';
  }

  uploadFiles(files: FileList) {
    if (files.length === 0) {
      return;
    }
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      this.uploadFile(file);
    }
  }

  cancelUpload(file: File) {
    this.cancel$.next(file);
    this.uploads$.next(
      this.uploads$.value.map<UploadingFile>(
        f =>
          f.file === file
            ? {
                ...f,
                status: UploadingFileStatus.Cancelled
              }
            : f
      )
    );
  }

  uploadFile(file: File) {
    this.uploads$.next([
      ...this.uploads$.value.filter(f => f.file !== file),
      {
        error: null,
        file,
        progress: null,
        status: UploadingFileStatus.Pending
      }
    ]);
    const sub = this.fileService
      .uploadFile(file)
      .pipe(
        takeUntil(this.destroy$),
        takeUntil(this.cancel$.pipe(filter(f => f === file)))
      )
      .subscribe(
        event => {
          switch (event.type) {
            case HttpEventType.UploadProgress: {
              const progress = (event.loaded / event.total) * 100;
              this.uploads$.next(
                this.uploads$.value.map<UploadingFile>(
                  f =>
                    f.file === file
                      ? {
                          ...f,
                          progress,
                          status: UploadingFileStatus.Uploading
                        }
                      : f
                )
              );
              break;
            }
            case HttpEventType.Response: {
              this.uploads$.next(
                this.uploads$.value.filter(f => f.file !== file)
              );
              const uploadedFile = fileApiToStored(event.body[0]);
              if (this.multiple) {
                this.files$.next([...this.files$.value, uploadedFile]);
                this.onChange(this.files$.value);
              } else {
                this.files$.next([uploadedFile]);
                this.onChange(uploadedFile);
              }
              break;
            }
          }
        },
        error => {
          this.uploads$.next(
            this.uploads$.value.map<UploadingFile>(
              f =>
                f.file === file
                  ? {
                      ...f,
                      status: UploadingFileStatus.Failed,
                      error
                    }
                  : f
            )
          );
        }
      );
  }

  removeFile(file: FileStored) {
    this.files$.next(this.files$.value.filter(f => f !== file));
    if (this.multiple) {
      this.onChange(this.files$.value);
    } else {
      if (this.files$.value.length === 0) {
        this.onChange(null);
      } else {
        this.onChange(this.files$.value[0]);
      }
    }
  }

  uploadTrackByFn(index: number, upload: UploadingFile) {
    return index;
  }

  @HostListener('window:dragover', ['$event'])
  windowDragEnter(event: DragEvent) {
    this.windowDrag$.next(true);
  }

  @HostListener('window:dragleave', ['$event'])
  windowDragLeave(event: DragEvent) {
    this.windowDrag$.next(false);
  }
}
