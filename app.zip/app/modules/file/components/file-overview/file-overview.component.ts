import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { FileStored } from '@file/models/stored/file.stored';

@Component({
  selector: 'app-file-overview',
  templateUrl: './file-overview.component.html',
  styleUrls: ['./file-overview.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FileOverviewComponent implements OnInit {
  @Input()
  files: FileStored[];

  @Output()
  remove = new EventEmitter<FileStored>();

  constructor() {}

  ngOnInit() {}
}
