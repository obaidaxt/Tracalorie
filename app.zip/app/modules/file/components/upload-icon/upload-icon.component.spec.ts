import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadIconComponent } from './upload-icon.component';

describe('UploadIconComponent', () => {
  let component: UploadIconComponent;
  let fixture: ComponentFixture<UploadIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
