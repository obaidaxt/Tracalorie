import { HttpEventType } from '@angular/common/http';
import {
  Component,
  ElementRef,
  EventEmitter,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import { LoadingStatus } from '@common/models/loading-status';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';
import { FileStored } from '@file/models/stored/file.stored';
import { FileService } from '@file/services/file.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-upload-icon',
  templateUrl: './upload-icon.component.html',
  styleUrls: ['./upload-icon.component.scss']
})
export class UploadIconComponent implements OnInit {
  @Output()
  uploadResponse = new EventEmitter<FileStored[]>();

  @ViewChild('uploadInput')
  uploadInput: ElementRef;

  status$ = new BehaviorSubject<LoadingStatus>(LoadingStatus.Waiting);
  progress$ = new BehaviorSubject<number>(0);

  constructor(private fileService: FileService) {}

  ngOnInit() {}

  handleInputChange(e) {
    const fileList: FileList = e.dataTransfer
      ? e.dataTransfer.files
      : e.target.files;
    if (fileList.length > 0) {
      const files: File[] = [];
      for (let i = 0; i < fileList.length; i++) {
        files.push(fileList[i]);
      }
      this.status$.next(LoadingStatus.Loading);
      this.fileService.uploadFiles(files).subscribe(
        response => {
          switch (response.type) {
            case HttpEventType.UploadProgress: {
              this.progress$.next((response.loaded * 100) / response.total);
              break;
            }
            case HttpEventType.Response: {
              this.progress$.next(100);
              this.status$.next(LoadingStatus.Completed);
              this.uploadInput.nativeElement.value = '';
              const uploadedFiles = response.body.map(fileApiToStored);
              this.uploadResponse.emit(uploadedFiles);
            }
          }
        },
        err => {
          this.status$.next(LoadingStatus.Failed);
        }
      );
    }
  }
}
