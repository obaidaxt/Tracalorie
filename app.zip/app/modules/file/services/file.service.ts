import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';
import { FileApi } from '@file/models/api/file.api';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FileService {
  constructor(private http: HttpClient) {}

  uploadFile(file: File) {
    const headers = new HttpHeaders({ enctype: 'multipart/form-data' });
    const formData = new FormData();
    formData.append('files', file);
    const req = new HttpRequest('POST', 'api/File', formData, {
      headers: headers,
      reportProgress: true
    });
    return this.http.request<FileApi[]>(req);
  }

  uploadFiles(files: File[]) {
    const headers = new HttpHeaders({ enctype: 'multipart/form-data' });
    const formData = new FormData();
    for (const file of files) {
      formData.append('files', file);
    }
    const req = new HttpRequest('POST', 'api/File', formData, {
      headers: headers,
      reportProgress: true
    });
    return this.http.request<FileApi[]>(req);
  }
}
