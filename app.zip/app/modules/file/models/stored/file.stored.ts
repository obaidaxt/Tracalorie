export interface FileStored {
  id: number;
  fileName: string;
  fileType: string;
  fileSize: number;
  date: Date;
  url: string;
}
