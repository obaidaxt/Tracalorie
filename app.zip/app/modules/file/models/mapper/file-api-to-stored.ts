import { FileApi } from '@file/models/api/file.api';
import { FileStored } from '@file/models/stored/file.stored';

export const fileApiToStored = (file: FileApi): FileStored => ({
  ...file,
  date: new Date(file.date)
});
