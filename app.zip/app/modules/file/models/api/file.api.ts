export interface FileApi {
  id: number;
  fileName: string;
  fileType: string;
  fileSize: number;
  date: string;
  url: string;
}
