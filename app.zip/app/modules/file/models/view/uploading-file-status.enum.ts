export enum UploadingFileStatus {
  Pending = 'pending',
  Uploading = 'uploading',
  Failed = 'failed',
  Cancelled = 'cancelled'
}
