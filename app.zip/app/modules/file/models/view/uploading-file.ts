import { UploadingFileStatus } from './uploading-file-status.enum';

export interface UploadingFile {
  status: UploadingFileStatus;
  progress: number;
  error: string | null;
  file: File;
}
