import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { StoreModule } from '@ngrx/store';
import { reducers } from '@notification/state';
import { EffectsModule } from '@ngrx/effects';
import { notificationEffects } from '@notification/state/notification.effects';
import { NotificationListComponent } from '@notification/components/notification-list/notification-list.component';
import { OldNotificationsComponent } from '@notification/components/old-notifications/old-notifications.component';
import { NotificationComponent } from '@notification/containers/notification/notification.component';

@NgModule({
  imports: [
    SharedModule,
    StoreModule.forFeature('notification', reducers),
    EffectsModule.forFeature(notificationEffects)
  ],
  declarations: [
    NotificationListComponent,
    OldNotificationsComponent,
    NotificationComponent
  ],
  exports: [NotificationComponent]
})
export class NotificationModule {}
