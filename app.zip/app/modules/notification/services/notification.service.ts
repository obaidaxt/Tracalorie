import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NotificationToggleManyPost } from '@notification/models/api/notification-toggle-many.post';
import { NotificationTogglePost } from '@notification/models/api/notification-toggle.post';
import { NotificationApi } from '@notification/models/api/notification.api';
import { SignalRService } from 'app/core/services/signal-r.service';
import { Observable } from 'rxjs/Observable';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  constructor(
    private http: HttpClient,
    private signalrService: SignalRService
  ) {}

  loadNotifications(): Observable<NotificationApi[]> {
    return this.http.get<NotificationApi[]>('api/Notification');
  }

  toggleRead(body: NotificationTogglePost): Observable<void> {
    return this.http.post<void>('api/Notification/ToggleRead', body);
  }

  toggleMany(body: NotificationToggleManyPost): Observable<number[]> {
    return this.http.post<number[]>('api/Notification/ToggleMany/', body);
  }

  getNewNotifications(): Observable<NotificationApi> {
    return this.signalrService.getData<NotificationApi>('GetNotifications');
  }

  loadOldNotification(
    skip: number,
    take: number
  ): Observable<NotificationApi[]> {
    return this.http.get<NotificationApi[]>(
      `api/Notification/GetOld/${skip}/${take}`
    );
  }
}
