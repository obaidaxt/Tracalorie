import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SignalRService } from '@core/services/signal-r.service';
import { Observable } from 'rxjs';
import { ActivityApi } from '@notification/models/api/activity.api';

@Injectable({
  providedIn: 'root'
})
export class ActivityService {
  constructor(private http: HttpClient, private signalR: SignalRService) {}

  loadProjectActivities(projectId: number): Observable<ActivityApi[]> {
    return this.http.get<ActivityApi[]>(`api/Activity/Project/${projectId}`);
  }

  getNewProjectActivities(projectId: number): Observable<ActivityApi> {
    return this.signalR.getData<ActivityApi>('ProjectActivities', projectId);
  }
}
