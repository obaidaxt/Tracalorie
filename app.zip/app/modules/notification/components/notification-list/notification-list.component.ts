import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NotificationView } from '@notification/models/view/notification.view';
import { NotificationTogglePost } from '@notification/models/api/notification-toggle.post';

@Component({
  selector: 'app-notification-list',
  templateUrl: './notification-list.component.html',
  styleUrls: ['./notification-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NotificationListComponent implements OnInit {
  @Input() notifications: NotificationView[];

  @Output() toggle = new EventEmitter<NotificationTogglePost>();
  @Output() close = new EventEmitter<void>();

  constructor() {}

  ngOnInit() {}

  toggleNotification(event: Event, notificaton: NotificationView) {
    event.preventDefault();
    event.stopPropagation();
    this.toggle.emit({
      id: notificaton.id,
      read: !notificaton.isRead
    });
  }
}
