import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OldNotificationsComponent } from './old-notifications.component';

describe('OldNotificationsComponent', () => {
  let component: OldNotificationsComponent;
  let fixture: ComponentFixture<OldNotificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OldNotificationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OldNotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
