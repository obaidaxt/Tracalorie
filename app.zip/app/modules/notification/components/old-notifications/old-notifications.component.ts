import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { NotificationTogglePost } from '@notification/models/api/notification-toggle.post';
import { NotificationView } from '@notification/models/view/notification.view';
import { LoadingStatus } from '../../../../common/models/loading-status';

@Component({
  selector: 'app-old-notifications',
  templateUrl: './old-notifications.component.html',
  styleUrls: ['./old-notifications.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OldNotificationsComponent implements OnInit {
  @Input()
  status: LoadingStatus;
  @Input()
  error: string;
  @Input()
  notifications: NotificationView[];

  @Output()
  toggle = new EventEmitter<NotificationTogglePost>();
  @Output()
  close = new EventEmitter<void>();
  @Output()
  load = new EventEmitter<{ skip: number; take: number }>();

  constructor() {}

  ngOnInit() {
    this.load.emit({ skip: 0, take: 100 });
  }

  toggleNotification(event: Event, notificaton: NotificationView) {
    event.preventDefault();
    event.stopPropagation();
    this.toggle.emit({
      id: notificaton.id,
      read: !notificaton.isRead
    });
  }
}
