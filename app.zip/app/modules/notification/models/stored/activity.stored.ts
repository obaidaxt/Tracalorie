import { FileStored } from "@file/models/stored/file.stored";
import { ActivityType } from "../api/activity-type.enum";

export interface ActivityStored {
  id: number;
  title: string;
  description: string;
  refId: number;
  image: FileStored | null;
  date: Date;
  actorId: string;
  type: ActivityType;
}
