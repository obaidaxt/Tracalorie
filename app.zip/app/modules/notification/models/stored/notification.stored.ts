import { ActivityStored } from './activity.stored';

export interface NotificationStored extends ActivityStored {
  isRead: boolean;
}
