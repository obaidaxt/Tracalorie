import { ActivityType } from '../api/activity-type.enum';
import { NotificationStored } from '../stored/notification.stored';
import { NotificationView } from '../view/notification.view';

export const notificationStoredToView = (
  notification: NotificationStored
): NotificationView => {
  let routerLink: string | any[];
  let params: { [key: string]: any };
  let icon: string;
  let fragment: string;
  switch (notification.type) {
    case ActivityType.CorrectionCreate: {
      routerLink = '/overview/projects';
      params = {
        projectId: notification.refId,
        taskId: undefined,
        mailtaskId: undefined
      };
      icon = 'compare';
      fragment = 'korrekturen';
      break;
    }
    case ActivityType.OfferCreate:
    case ActivityType.OfferDelete:
    case ActivityType.OfferEdit:
    case ActivityType.RzCreate:
    case ActivityType.RzEdit:
    case ActivityType.RzDelete:
    case ActivityType.LayoutVersionDelete:
    case ActivityType.LayoutVersionCreate:
    case ActivityType.LayoutVersionEdit: {
      routerLink = '/overview/projects';
      params = {
        projectId: notification.refId,
        taskId: undefined,
        mailtaskId: undefined
      };
      icon = 'photo';
      break;
    }
    case ActivityType.OfferApprove:
    case ActivityType.RzApprove:
    case ActivityType.LayoutVersionApprove: {
      routerLink = '/overview/projects';
      params = {
        projectId: notification.refId,
        taskId: undefined,
        mailtaskId: undefined
      };
      icon = 'done_outline';
      fragment = 'freigabe';
      break;
    }
    case ActivityType.LayoutVersionProjectChat: {
      routerLink = '/overview/projects';
      params = {
        projectId: notification.refId,
        taskId: undefined,
        mailtaskId: undefined
      };
      icon = 'chat';
      fragment = 'chat';
      break;
    }
    case ActivityType.ProjectChat: {
      routerLink = '/overview/projects';
      params = {
        projectId: notification.refId,
        taskId: undefined,
        mailtaskId: undefined
      };
      icon = 'chat';
      fragment = 'chat';
      break;
    }
    case ActivityType.TaskChat: {
      routerLink = '/overview/tasks';
      params = {
        projectId: undefined,
        taskId: notification.refId,
        mailtaskId: undefined
      };
      icon = 'chat';
      fragment = 'chat';
      break;
    }
    case ActivityType.Mail2Task: {
      routerLink = '/overview/mail2task';
      params = {
        mailtaskId: notification.refId,
        projectId: undefined,
        taskId: undefined
      };
      icon = 'mail_outline';
      break;
    }
    case ActivityType.ProjectCreatePlanned:
    case ActivityType.ProjectBriefingCreate:
    case ActivityType.ProjectBriefingEdit:
    case ActivityType.ProjectBriefingSet: {
      routerLink = '/overview/projects';
      params = {
        projectId: notification.refId,
        taskId: undefined,
        mailtaskId: undefined
      };
      icon = 'description';
      break;
    }
    case ActivityType.ProjectCreate:
    case ActivityType.ProjectUpdated:
    case ActivityType.ProjectStatusUpdated: {
      routerLink = '/overview/projects';
      params = {
        projectId: notification.refId,
        taskId: undefined,
        mailtaskId: undefined
      };
      icon = 'event_note';
      break;
    }
    case ActivityType.TaskCompleted:
    case ActivityType.TaskCreated:
    case ActivityType.TaskUncompleted:
    case ActivityType.TaskUpdated: {
      routerLink = '/overview/tasks';
      params = {
        taskId: notification.refId,
        projectId: undefined,
        mailtaskId: undefined
      };
      icon = 'check_box';
      break;
    }
    default: {
      return null;
    }
  }
  return {
    ...notification,
    routerLink,
    params,
    icon,
    fragment
  };
};
