import { NotificationApi } from '@notification/models/api/notification.api';
import { NotificationStored } from '@notification/models/stored/notification.stored';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';

export const notificationApiToStored = (
  notification: NotificationApi
): NotificationStored => ({
  ...notification,
  date: new Date(notification.date),
  image: notification.image ? fileApiToStored(notification.image) : null
});
