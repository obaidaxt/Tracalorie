import { ActivityApi } from '../api/activity.api';
import { ActivityStored } from '../stored/activity.stored';
import { fileApiToStored } from '@file/models/mapper/file-api-to-stored';

export const activityApiToStored = (activity: ActivityApi): ActivityStored => ({
  ...activity,
  date: new Date(activity.date),
  image: activity.image ? fileApiToStored(activity.image) : null
});
