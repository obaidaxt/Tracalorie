import { NotificationStored } from '@notification/models/stored/notification.stored';

export interface NotificationView extends NotificationStored {
  routerLink: string | any[];
  params: { [key: string]: any };
  icon: string;
  fragment: string;
}
