import { ActivityStored } from "@notification/models/stored/activity.stored";

export interface ActivityView extends ActivityStored {}
