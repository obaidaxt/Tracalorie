import { ActivityApi } from './activity.api';

export interface NotificationApi extends ActivityApi {
  isRead: boolean;
}
