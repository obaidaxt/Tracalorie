export interface NotificationTogglePost {
  id: number;
  read: boolean;
}
