import { NotificationToggleType } from '@notification/models/api/notification-toggle-type.enum';

export interface NotificationToggleManyPost {
  refId?: number;
  type: NotificationToggleType;
}
