import { ActivityType } from './activity-type.enum';
import { FileApi } from '@file/models/api/file.api';

export interface ActivityApi {
  id: number;
  title: string;
  description: string;
  refId: number;
  image: FileApi | null;
  date: string;
  actorId: string;
  type: ActivityType;
}
