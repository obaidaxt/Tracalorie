export enum NotificationToggleType {
  All,
  Project,
  ProjectInfo,
  ProjectChat,
  ProjectCorrections,
  ProjectApproval,
  Task,
  Mailtask,
  Briefing
}
