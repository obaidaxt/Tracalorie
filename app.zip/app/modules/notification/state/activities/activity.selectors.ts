import * as fromNotification from '../notification.reducers';
import * as fromActivites from './activity.reducer';
import { createSelector } from '@ngrx/store';

export const selectActivityState = createSelector(
  fromNotification.selectNotificationState,
  state => state.activities
);

export const selectAllActivities = createSelector(
  selectActivityState,
  fromActivites.selectAll
);

export const selectOrderedActivities = createSelector(
  selectAllActivities,
  activities => activities.sort((a, b) => b.date.valueOf() - a.date.valueOf())
);
