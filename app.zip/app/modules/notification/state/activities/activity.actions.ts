import { Action } from '@ngrx/store';
import { ActivityApi } from '@notification/models/api/activity.api';

export enum ActivityActionTypes {
  LoadProject = '[Project Info] Load Project Activities',
  LoadProjectSuccess = '[API] Load Project Activities Success',
  LoadProjectFailed = '[API] Load Project Activities Failed',
  Added = '[SignalR] Project Activity Added'
}

export class LoadProjectActivities implements Action {
  readonly type = ActivityActionTypes.LoadProject;
  constructor(public projectId: number) {}
}

export class LoadProjectActivitiesSuccess implements Action {
  readonly type = ActivityActionTypes.LoadProjectSuccess;
  constructor(public activities: ActivityApi[]) {}
}

export class LoadProjectActivitiesFailed implements Action {
  readonly type = ActivityActionTypes.LoadProjectFailed;
  constructor(public error: string) {}
}

export class ActivityAdded implements Action {
  readonly type = ActivityActionTypes.Added;
  constructor(public payload: ActivityApi) {}
}

export type ActivityActions =
  | LoadProjectActivities
  | LoadProjectActivitiesSuccess
  | LoadProjectActivitiesFailed
  | ActivityAdded;
