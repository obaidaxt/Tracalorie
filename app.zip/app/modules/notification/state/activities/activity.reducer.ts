import { createEntityAdapter, EntityState } from '@ngrx/entity';
import { activityApiToStored } from '@notification/models/mapper/activity-api-to-stored';
import { ActivityStored } from '@notification/models/stored/activity.stored';
import { ActivityActions, ActivityActionTypes } from './activity.actions';

export interface State extends EntityState<ActivityStored> {}

export const adapter = createEntityAdapter<ActivityStored>({
  selectId: activity => activity.id
});

export const initialState: State = adapter.getInitialState({});

export function reducer(state = initialState, action: ActivityActions): State {
  switch (action.type) {
    case ActivityActionTypes.LoadProjectSuccess: {
      return adapter.addAll(action.activities.map(activityApiToStored), state);
    }

    case ActivityActionTypes.Added: {
      return adapter.addOne(activityApiToStored(action.payload), state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
