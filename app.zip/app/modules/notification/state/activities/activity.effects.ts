import { UserActionTypes } from '@account/state';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { ActivityService } from '@notification/services/activity.service';
import { Observable, of } from 'rxjs';
import { catchError, map, switchMap, takeUntil } from 'rxjs/operators';
import {
  ActivityActionTypes,
  ActivityAdded,
  LoadProjectActivities,
  LoadProjectActivitiesFailed,
  LoadProjectActivitiesSuccess
} from './activity.actions';

@Injectable()
export class ActivityEffects {
  constructor(
    private actions$: Actions,
    private activityService: ActivityService
  ) {}

  @Effect({ dispatch: false })
  stop$ = this.actions$.pipe(ofType(UserActionTypes.Logout));

  @Effect()
  loadProject$: Observable<Action> = this.actions$.pipe(
    ofType(ActivityActionTypes.LoadProject),
    switchMap(({ projectId }: LoadProjectActivities) =>
      this.activityService.loadProjectActivities(projectId).pipe(
        takeUntil(this.stop$),
        map(activities => new LoadProjectActivitiesSuccess(activities)),
        catchError(err => of(new LoadProjectActivitiesFailed(err)))
      )
    )
  );

  @Effect()
  getNewProjectActivities$: Observable<Action> = this.actions$.pipe(
    ofType(ActivityActionTypes.LoadProject),
    switchMap(({ projectId }: LoadProjectActivities) =>
      this.activityService.getNewProjectActivities(projectId).pipe(
        takeUntil(this.stop$),
        map(activity => new ActivityAdded(activity))
      )
    )
  );
}
