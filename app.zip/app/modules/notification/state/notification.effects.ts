import { NotificationEffects } from '@notification/state/notification/notification.effects';

export const notificationEffects = [NotificationEffects];
