import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';
import * as fromNotifications from './notification/notification.reducer';
import * as fromActivities from './activities/activity.reducer';

export interface NotificationState {
  notifications: fromNotifications.State;
  activities: fromActivities.State;
}

export interface State {
  notification: NotificationState;
}

export const reducers: ActionReducerMap<NotificationState> = {
  notifications: fromNotifications.reducer,
  activities: fromActivities.reducer
};

export const selectNotificationState = createFeatureSelector<NotificationState>(
  'notification'
);
