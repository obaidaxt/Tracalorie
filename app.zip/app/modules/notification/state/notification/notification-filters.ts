import { NotificationStored } from '@notification/models/stored/notification.stored';
import { ActivityType } from '@notification/models/api/activity-type.enum';

export const filterNewNotifications = (
  notification: NotificationStored
): boolean => {
  if (!notification.isRead) {
    return true;
  }
  const dateDiff = notification.date.valueOf() - new Date().valueOf();
  return dateDiff >= -604_800_000;
};

export const filterOldNotifications = (
  notification: NotificationStored
): boolean => {
  if (!notification.isRead) {
    return false;
  }
  const dateDiff = notification.date.valueOf() - new Date().valueOf();
  return dateDiff < -604_800_000;
};

export const activityTypeList: ActivityType[] = [
  ActivityType.CorrectionComment,
  ActivityType.CorrectionCreate,
  ActivityType.LayoutVersionApprove,
  ActivityType.LayoutVersionCreate,
  ActivityType.LayoutVersionDelete,
  ActivityType.LayoutVersionEdit,
  ActivityType.LayoutVersionProjectChat,
  ActivityType.Mail2Task,
  ActivityType.OfferApprove,
  ActivityType.OfferCreate,
  ActivityType.OfferDelete,
  ActivityType.OfferEdit,
  ActivityType.ProjectActivity,
  ActivityType.ProjectActivityComment,
  ActivityType.ProjectBriefingCreate,
  ActivityType.ProjectBriefingEdit,
  ActivityType.ProjectBriefingSet,
  ActivityType.ProjectChat,
  ActivityType.ProjectCreate,
  ActivityType.ProjectCreatePlanned,
  ActivityType.ProjectRebriefingCreate,
  ActivityType.ProjectStatusUpdated,
  ActivityType.ProjectUpdated,
  ActivityType.RzApprove,
  ActivityType.RzCreate,
  ActivityType.RzDelete,
  ActivityType.RzEdit,
  ActivityType.TaskChat,
  ActivityType.TaskCompleted,
  ActivityType.TaskCreated,
  ActivityType.TaskUncompleted,
  ActivityType.TaskUpdated
];

export const filterValidNotifications = (
  notification: NotificationStored
): boolean => activityTypeList.includes(notification.type);
