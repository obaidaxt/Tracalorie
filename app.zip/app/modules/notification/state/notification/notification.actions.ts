import { Action } from '@ngrx/store';
import { NotificationApi } from '@notification/models/api/notification.api';
import { NotificationTogglePost } from '@notification/models/api/notification-toggle.post';
import { NotificationToggleManyPost } from '@notification/models/api/notification-toggle-many.post';

export enum NotificationActionTypes {
  Load = '[Notifications] Load',
  LoadSuccess = '[API] Load Notifications Success',
  LoadFailed = '[API] Load Notifications Failed',
  Added = '[SignalR] Notification Added',
  Toggle = '[Notification] Toggle',
  ToggleSuccess = '[API] Toggle Notificaton Success',
  ToggleFailed = '[API] Toggle Notification Failed',
  ToggleMany = '[Notification] Toggle Many',
  ToggleManySuccess = '[API] Toggle Many Notifications Success',
  ToggleManyFailed = '[API] Toggle Many Notifications Failed',
  LoadOldNotifications = '[Notification] Load Old Notifications',
  LoadOldNotificationsSuccess = '[API] Load Old Notifications Success',
  LoadOldNotificationsFailed = '[API] Load Old Notifications Failed'
}

export class LoadNotifications implements Action {
  readonly type = NotificationActionTypes.Load;
}

export class LoadNotificationsSuccess implements Action {
  readonly type = NotificationActionTypes.LoadSuccess;
  constructor(public payload: NotificationApi[]) {}
}

export class LoadNotificationsFailed implements Action {
  readonly type = NotificationActionTypes.LoadFailed;
  constructor(public payload: string) {}
}

export class NotificationAdded implements Action {
  readonly type = NotificationActionTypes.Added;
  constructor(public payload: NotificationApi) {}
}

export class ToggleNotification implements Action {
  readonly type = NotificationActionTypes.Toggle;
  constructor(public payload: NotificationTogglePost) {}
}

export class ToggleNotificationSuccess implements Action {
  readonly type = NotificationActionTypes.ToggleSuccess;
  constructor() {}
}

export class ToggleNotificationFailed implements Action {
  readonly type = NotificationActionTypes.ToggleFailed;
  constructor(public payload: string) {}
}

export class ToggleManyNotifications implements Action {
  readonly type = NotificationActionTypes.ToggleMany;
  constructor(public payload: NotificationToggleManyPost) {}
}

export class ToggleManyNotificationsSuccess implements Action {
  readonly type = NotificationActionTypes.ToggleManySuccess;
  constructor(public payload: number[]) {}
}

export class ToggleManyNotificationsFailed implements Action {
  readonly type = NotificationActionTypes.ToggleManyFailed;
  constructor(public payload: string) {}
}

export class LoadOldNotifications implements Action {
  readonly type = NotificationActionTypes.LoadOldNotifications;
  constructor(public skip: number, public take: number) {}
}

export class LoadOldNotificationsSuccess implements Action {
  readonly type = NotificationActionTypes.LoadOldNotificationsSuccess;
  constructor(public notifications: NotificationApi[]) {}
}

export class LoadOldNotificationsFailed implements Action {
  readonly type = NotificationActionTypes.LoadOldNotificationsFailed;
  constructor(public error: string) {}
}

export type NotificationActions =
  | LoadNotifications
  | LoadNotificationsSuccess
  | LoadNotificationsFailed
  | NotificationAdded
  | ToggleNotification
  | ToggleNotificationSuccess
  | ToggleNotificationFailed
  | ToggleManyNotifications
  | ToggleManyNotificationsSuccess
  | ToggleManyNotificationsFailed
  | LoadOldNotifications
  | LoadOldNotificationsSuccess
  | LoadOldNotificationsFailed;
