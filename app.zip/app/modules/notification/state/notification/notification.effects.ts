import { UserActionTypes } from '@account/state';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { NotificationService } from '@notification/services/notification.service';
import { Observable, of } from 'rxjs';
import {
  catchError,
  map,
  mergeMap,
  switchMap,
  takeUntil
} from 'rxjs/operators';
import {
  LoadNotificationsFailed,
  LoadNotificationsSuccess,
  LoadOldNotifications,
  LoadOldNotificationsFailed,
  LoadOldNotificationsSuccess,
  NotificationActionTypes,
  NotificationAdded,
  ToggleManyNotifications,
  ToggleManyNotificationsFailed,
  ToggleManyNotificationsSuccess,
  ToggleNotification,
  ToggleNotificationFailed,
  ToggleNotificationSuccess
} from './notification.actions';

@Injectable()
export class NotificationEffects {
  constructor(
    private actions$: Actions,
    private notificationService: NotificationService
  ) {}

  @Effect({ dispatch: false })
  stop$ = this.actions$.pipe(ofType(UserActionTypes.Logout));

  @Effect()
  load$: Observable<Action> = this.actions$.pipe(
    ofType(NotificationActionTypes.Load),
    switchMap(() =>
      this.notificationService.loadNotifications().pipe(
        takeUntil(this.stop$),
        map(notifications => new LoadNotificationsSuccess(notifications)),
        catchError(err => of(new LoadNotificationsFailed(err)))
      )
    )
  );

  @Effect()
  getNew$: Observable<Action> = this.actions$.pipe(
    ofType(NotificationActionTypes.Load),
    switchMap(() =>
      this.notificationService.getNewNotifications().pipe(
        takeUntil(this.stop$),
        map(notification => new NotificationAdded(notification))
      )
    )
  );

  @Effect()
  toggle$: Observable<Action> = this.actions$.pipe(
    ofType(NotificationActionTypes.Toggle),
    mergeMap(({ payload }: ToggleNotification) =>
      this.notificationService.toggleRead(payload).pipe(
        map(() => new ToggleNotificationSuccess()),
        catchError(err => of(new ToggleNotificationFailed(err)))
      )
    )
  );

  @Effect()
  toggleMany$: Observable<Action> = this.actions$.pipe(
    ofType(NotificationActionTypes.ToggleMany),
    mergeMap(({ payload }: ToggleManyNotifications) =>
      this.notificationService.toggleMany(payload).pipe(
        map(ids => new ToggleManyNotificationsSuccess(ids)),
        catchError(err => of(new ToggleManyNotificationsFailed(err)))
      )
    )
  );

  @Effect()
  loadOld$: Observable<Action> = this.actions$.pipe(
    ofType(NotificationActionTypes.LoadOldNotifications),
    switchMap(({ skip, take }: LoadOldNotifications) =>
      this.notificationService.loadOldNotification(skip, take).pipe(
        takeUntil(this.stop$),
        map(notifications => new LoadOldNotificationsSuccess(notifications)),
        catchError(err => of(new LoadOldNotificationsFailed(err)))
      )
    )
  );
}
