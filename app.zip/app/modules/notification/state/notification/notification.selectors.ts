import * as fromNotification from '../notification.reducers';
import * as fromNotifications from './notification.reducer';
import { createSelector } from '@ngrx/store';
import {
  filterNewNotifications,
  filterOldNotifications,
  filterValidNotifications
} from '@notification/state/notification/notification-filters';
import { notificationStoredToView } from '@notification/models/mapper/notification-stored-to-view';

export const selectNotificationsState = createSelector(
  fromNotification.selectNotificationState,
  state => state.notifications
);

export const selectAllNotifications = createSelector(
  selectNotificationsState,
  fromNotifications.selectAll
);

export const selectNotificationLoadingStatus = createSelector(
  selectNotificationsState,
  fromNotifications.selectLoadingStatus
);

export const selectNotificationLoadingError = createSelector(
  selectNotificationsState,
  fromNotifications.selectLoadingError
);

export const selectOldNotificationLoadingStatus = createSelector(
  selectNotificationsState,
  fromNotifications.selectOldLoadingStatus
);

export const selectOldNotificationLoadingError = createSelector(
  selectNotificationsState,
  fromNotifications.selectOldLoadingError
);

export const selectUnreadNotifications = createSelector(
  selectAllNotifications,
  notifications => notifications.filter(m => !m.isRead)
);

export const selectUnreadNotificationCount = createSelector(
  selectUnreadNotifications,
  notificatons => notificatons.length
);

export const selectValidNotifications = createSelector(
  selectAllNotifications,
  notifications => notifications.filter(filterValidNotifications)
);

export const selectNewNotifications = createSelector(
  selectValidNotifications,
  notifications => notifications.filter(filterNewNotifications)
);

export const selectOldNotifications = createSelector(
  selectValidNotifications,
  notifications => notifications.filter(filterOldNotifications)
);

export const selectNewNotificationsView = createSelector(
  selectNewNotifications,
  notifications => notifications.map(notificationStoredToView)
);

export const selectOldNotificationsView = createSelector(
  selectOldNotifications,
  notifications => notifications.map(notificationStoredToView)
);
