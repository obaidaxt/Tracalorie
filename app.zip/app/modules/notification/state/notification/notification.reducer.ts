import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import {
  NotificationActions,
  NotificationActionTypes
} from './notification.actions';
import { LoadingStatus } from '../../../../common/models/loading-status';
import { NotificationStored } from '@notification/models/stored/notification.stored';
import { activityApiToStored } from '@notification/models/mapper/activity-api-to-stored';
import { notificationApiToStored } from '@notification/models/mapper/notification-api-to-stored';

export interface State extends EntityState<NotificationStored> {
  loadingStatus: LoadingStatus;
  loadingError: string;
  oldLoadingStatus: LoadingStatus;
  oldLoadingError: string;
}

export const adapter = createEntityAdapter<NotificationStored>({
  selectId: notification => notification.id
});

export const initialState: State = adapter.getInitialState({
  loadingStatus: LoadingStatus.Waiting,
  loadingError: null,
  oldLoadingStatus: LoadingStatus.Waiting,
  oldLoadingError: null
});

export function reducer(
  state = initialState,
  action: NotificationActions
): State {
  switch (action.type) {
    case NotificationActionTypes.Load: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Loading
      };
    }

    case NotificationActionTypes.LoadSuccess: {
      return adapter.addAll(action.payload.map(notificationApiToStored), {
        ...state,
        loadingStatus: LoadingStatus.Completed
      });
    }

    case NotificationActionTypes.LoadFailed: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Failed,
        loadingError: action.payload
      };
    }

    case NotificationActionTypes.Added: {
      return adapter.addOne(notificationApiToStored(action.payload), state);
    }

    case NotificationActionTypes.Toggle: {
      return adapter.updateOne(
        { id: action.payload.id, changes: { isRead: action.payload.read } },
        state
      );
    }

    case NotificationActionTypes.ToggleManySuccess: {
      return adapter.updateMany(
        action.payload.map(id => ({ id: id, changes: { isRead: true } })),
        state
      );
    }

    case NotificationActionTypes.LoadOldNotifications: {
      return {
        ...state,
        oldLoadingStatus: LoadingStatus.Loading
      };
    }

    case NotificationActionTypes.LoadOldNotificationsSuccess: {
      return adapter.addMany(
        action.notifications.map(notificationApiToStored),
        {
          ...state,
          oldLoadingStatus: LoadingStatus.Completed
        }
      );
    }

    case NotificationActionTypes.LoadOldNotificationsFailed: {
      return {
        ...state,
        oldLoadingStatus: LoadingStatus.Failed,
        oldLoadingError: action.error
      };
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
export const selectLoadingStatus = (state: State) => state.loadingStatus;
export const selectLoadingError = (state: State) => state.loadingError;
export const selectOldLoadingStatus = (state: State) => state.oldLoadingStatus;
export const selectOldLoadingError = (state: State) => state.oldLoadingError;
