import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ResponsiveService } from '@core/services/responsive.service';
import { Store } from '@ngrx/store';
import { NotificationToggleType } from '@notification/models/api/notification-toggle-type.enum';
import { NotificationTogglePost } from '@notification/models/api/notification-toggle.post';
import { NotificationView } from '@notification/models/view/notification.view';
import * as fromNotification from '@notification/state';
import { Observable } from 'rxjs';
import { filter, take } from 'rxjs/operators';
import { LoadingStatus } from '../../../../common/models/loading-status';
import { overlayAnimations } from './overlay-animations';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [overlayAnimations.transformMenu]
})
export class NotificationComponent implements OnInit {
  open = false;
  status$: Observable<LoadingStatus>;
  error$: Observable<string>;
  notifications$: Observable<NotificationView[]>;
  oldStatus$: Observable<LoadingStatus>;
  oldError$: Observable<string>;
  oldNotifications$: Observable<NotificationView[]>;
  unreadCount$: Observable<number>;
  isMobile$: Observable<boolean>;
  showOld = false;

  constructor(
    private store: Store<fromNotification.State>,
    private responsive: ResponsiveService
  ) {}

  ngOnInit() {
    this.status$ = this.store.select(
      fromNotification.selectNotificationLoadingStatus
    );
    this.error$ = this.store.select(
      fromNotification.selectNotificationLoadingError
    );
    this.notifications$ = this.store.select(
      fromNotification.selectNewNotificationsView
    );
    this.oldStatus$ = this.store.select(
      fromNotification.selectOldNotificationLoadingStatus
    );
    this.oldError$ = this.store.select(
      fromNotification.selectOldNotificationLoadingError
    );
    this.oldNotifications$ = this.store.select(
      fromNotification.selectOldNotificationsView
    );
    this.unreadCount$ = this.store.select(
      fromNotification.selectUnreadNotificationCount
    );
    this.isMobile$ = this.responsive.isMobile;

    this.status$
      .pipe(
        take(1),
        filter(status => status === LoadingStatus.Waiting)
      )
      .subscribe(() => {
        this.loadNotification();
      });
  }

  loadNotification() {
    this.store.dispatch(new fromNotification.LoadNotifications());
  }

  toggleNotification(payload: NotificationTogglePost) {
    this.store.dispatch(new fromNotification.ToggleNotification(payload));
  }

  toggleAll() {
    this.store.dispatch(
      new fromNotification.ToggleManyNotifications({
        type: NotificationToggleType.All
      })
    );
  }

  loadOldNotification({ skip, take: takeN }: { skip: number; take: number }) {
    this.store.dispatch(new fromNotification.LoadOldNotifications(skip, takeN));
  }
}
