import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Chatmessage } from '@chat/models/api/chatmessage';
import { ChatmessageCreate } from '@chat/models/api/chatmessage-create';
import { ChatmessageCreateExtern } from '@chat/models/api/chatmessage-create-extern';
import { ChatmessageUpdate } from '@chat/models/api/chatmessage-update';
import { SignalRService } from '@core/services/signal-r.service';
import { Observable, throwError } from 'rxjs';
import { map } from 'rxjs/operators';
import { DataChangeAction } from '../../../common/models/data-change-action';

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  constructor(private http: HttpClient, private signalR: SignalRService) {}

  getMessages(roomId: number): Observable<Chatmessage[]> {
    if (typeof roomId !== 'number') {
      return throwError('Der Chat ist nicht verfügbar.');
    }
    return this.http
      .get<Chatmessage[]>(`api/Chat/Room/${roomId}`)
      .pipe(map(messages => messages.map(this.formatMessage)));
  }

  joinRoom(id: number): Observable<DataChangeAction<Chatmessage, number>> {
    return this.signalR
      .getChanges<Chatmessage, number>('JoinChatRoom', id)
      .pipe(
        map(action => {
          action.data = this.formatMessage(action.data);
          return action;
        })
      );
  }

  createChatmessage(payload: ChatmessageCreate): Observable<Chatmessage> {
    return this.http
      .post<Chatmessage>('api/Chat/Create', payload)
      .pipe(map(this.formatMessage));
  }

  createExternChatmessage(
    payload: ChatmessageCreateExtern
  ): Observable<Chatmessage> {
    return this.http
      .post<Chatmessage>('api/Chat/CreateExtern', payload)
      .pipe(map(this.formatMessage));
  }

  updateChatmessage(
    id: number,
    update: ChatmessageUpdate
  ): Observable<Chatmessage> {
    return this.http
      .put<Chatmessage>(`api/Chat/Update/${id}`, update)
      .pipe(map(this.formatMessage));
  }

  deleteChatmessage(id: number): Observable<void> {
    return this.http.delete<void>(`api/Chat/${id}`);
  }

  // TODO: in reducer auslagern
  private formatMessage(chatmessage: Chatmessage): Chatmessage {
    chatmessage.date = new Date(chatmessage.date);
    chatmessage.files = chatmessage.files.map(file => {
      // file.date = new Date(file.date);
      return file;
    });
    return chatmessage;
  }
}
