import { AbstractControl, FormGroup } from "ngx-strongly-typed-forms";
import { ValidationErrors } from "@angular/forms";
import { ChatFormValue } from "@chat/components/chat-form/chat-form-value";

export const externEmailValidator = (
  control: AbstractControl<ChatFormValue>
): ValidationErrors | null => {
  const extern = control.get("extern").value;
  const email = control.get("email").value;
  if (extern && (!email || email.length === 0)) {
    control.get("email").setErrors({
      required: true
    });
    return { externEmailRequired: true };
  }
  control.get("email").setErrors(null);
  return null;
};
