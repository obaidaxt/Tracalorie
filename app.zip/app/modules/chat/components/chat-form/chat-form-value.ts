export interface ChatFormValue {
  chatroomId: number;
  text: string;
  files: number[];
  extern: boolean;
  email: string;
}
