import { AbstractControl, FormGroup } from 'ngx-strongly-typed-forms';
import { ValidationErrors } from '@angular/forms';
import { ChatFormValue } from '@chat/components/chat-form/chat-form-value';

export const textValidator = (
  control: AbstractControl<ChatFormValue>
): ValidationErrors | null => {
  const files = control.get('files').value;
  const textControl = control.get('text');
  const text = textControl.value;
  if (files.length === 0 && (!text || text.length === 0)) {
    textControl.setErrors({ required: true });
    return { textRequired: true };
  }
  textControl.setErrors(null);
  return null;
};
