import { ProfileStored } from '@account/models/stored/profile.stored';
import { selectProfile } from '@account/state';
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import { Validators } from '@angular/forms';
import { ChatFormValue } from '@chat/components/chat-form/chat-form-value';
import { externEmailValidator } from '@chat/components/chat-form/extern-email-validators';
import { textValidator } from '@chat/components/chat-form/text-validators';
import { ChatRoom } from '@chat/state';
import { FileStored } from '@file/models/stored/file.stored';
import { Store } from '@ngrx/store';
import * as fromRoot from '@root';
import { FormBuilder, FormGroup } from 'ngx-strongly-typed-forms';
import { Observable } from 'rxjs/Observable';

enum KeyCode {
  UP = 38,
  DOWN = 40,
  LEFT = 37,
  RIGHT = 39,
  AT = 81,
  BACKSPACE = 8
}

@Component({
  selector: 'app-chat-form',
  templateUrl: './chat-form.component.html',
  styleUrls: ['./chat-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatFormComponent implements OnInit {
  @Input()
  chatroom: ChatRoom;
  @Input()
  extern = false;

  @Output()
  onSubmit = new EventEmitter<ChatFormValue>();

  @ViewChild('extern')
  @ViewChild('chatTextArea')
  chatTextArea: ElementRef;

  private scrollContainer: ElementRef;

  chatForm: FormGroup<ChatFormValue>;
  currentUser: Observable<ProfileStored>;
  caretPos: number;
  actualCaretPos: number;

  constructor(private fb: FormBuilder, private store: Store<fromRoot.RootState>) {}

  ngOnInit() {
    this.createForm();
    this.currentUser = this.store.select(selectProfile);

    this.caretPos = this.chatTextArea.nativeElement.selectionStart;
    this.chatForm.valueChanges.subscribe(t => {
      this.actualCaretPos = this.chatTextArea.nativeElement.selectionStart;
    });
  }

  createForm() {
    this.chatForm = this.fb.group<ChatFormValue>(
      {
        chatroomId: [this.chatroom.id, Validators.required],
        text: null,
        files: [[]],
        extern: [false, Validators.required],
        email: null
      },
      {
        validator: [textValidator, externEmailValidator]
      }
    );
  }

  handleUploadResponse(files: FileStored[]) {
    const control = this.chatForm.get('files');
    control.setValue([...control.value, ...files.map(file => file.id)]);
  }

  handleKeyDown(event: KeyboardEvent) {
    if (event.shiftKey && event.key === 'Enter') {
      event.preventDefault();
      this.submitHandler();
    }
  }

  submitHandler() {
    if (this.chatForm.invalid) {
      return;
    }
    this.onSubmit.emit(this.chatForm.value);
    this.chatForm.reset({
      chatroomId: this.chatroom.id,
      email: null,
      extern: false,
      files: [],
      text: null
    });
  }

  onKeydown(event: KeyboardEvent, textArea) {
    // switch (event.keyCode) {
    //   case KeyCode.AT:
    //     {
    //       this.chatNameOverlay.setKeyboardEvent(event);
    //       this.showNameOverlay();
    //     }
    //     break;
    //   case KeyCode.BACKSPACE:
    //     {
    //       if (this.chatTextArea.nativeElement.selectionStart) {
    //         this.chatNameOverlay.setActualCaretPos(
    //           this.chatTextArea.nativeElement.selectionStart
    //         );
    //       }
    //     }
    //     break;
    //   case KeyCode.RIGHT:
    //   case KeyCode.LEFT:
    //     {
    //       if (this.overlayRef.isOpen()) {
    //         event.preventDefault();
    //       }
    //     }
    //     break;
    //   default: {
    //     this.chatNameOverlay.setKeyboardEvent(event);
    //   }
    // }
  }

  showNameOverlay() {
    // this.caretPos = this.chatTextArea.nativeElement.selectionStart;
    this.caretPos = this.actualCaretPos;
    // if (!this.overlayRef || !this.overlayRef.isOpen()) {
    //   this.overlayRef = this.chatNameOverlay.open({
    //     textArea: this.chatTextArea,
    //     filterText: this.chatForm.get('text').valueChanges,
    //     chatForm: this.chatForm,
    //     panelClass: 'chat-suggestion-field'
    //   });
    // }
  }
}
