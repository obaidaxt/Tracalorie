import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  ElementRef,
  ViewChild
} from '@angular/core';

@Component({
  selector: 'app-chat-input',
  templateUrl: './chat-input.component.html',
  styleUrls: ['./chat-input.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatInputComponent implements OnInit {
  @ViewChild('chatInput') chatInput: ElementRef;

  constructor() {}

  ngOnInit() {}

  handleInput(event) {
    if (event.data === '@') {
      event.preventDefault();
      const userNode = document.createElement('div');
      userNode.classList.add('user-selection');
      userNode.textContent = '@';
      (this.chatInput.nativeElement as HTMLElement).appendChild(userNode);
      const selection = document.getSelection();
      if (selection.baseNode.textContent.endsWith('@')) {
        selection.baseNode.textContent = selection.baseNode.textContent.slice(
          0,
          -1
        );
      }
      const range = document.createRange();
      range.setStart(userNode, 1);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);
    }
    if (event.data === ' ') {
      const selection = document.getSelection();
      const parent = selection.baseNode.parentElement;
      if (parent.classList.contains('user-selection')) {
        parent.textContent = parent.textContent.slice(0, -1);
        const range = document.createRange();
        range.setStart(parent.parentElement, 1);
        range.collapse(true);
        selection.removeAllRanges();
        selection.addRange(range);
      }
    }
    console.log(event);
    console.log(this.chatInput);
    console.log(window.getSelection());
  }
}
