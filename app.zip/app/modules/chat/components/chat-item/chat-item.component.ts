import { ChangeDetectionStrategy, Component, HostBinding, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ChatMessageEntity } from '@chat/state/chat-rooms/chat-message.entity';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-chat-item',
  templateUrl: './chat-item.component.html',
  styleUrls: ['./chat-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatItemComponent implements OnInit, OnChanges {
  @Input() message: ChatMessageEntity;
  @Input() own: boolean;
  @Input() usernames: string[];

  @HostBinding('class.own') isOwn = false;


  constructor() {}

  ngOnInit() {
    console.log(this.usernames);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['own']) {
      this.isOwn = this.own;
    }
  }

  // highlight(text: string, own: boolean) {
  //   let replacementText = text;
  //   this.usernames.forEach(un => {
  //     replacementText = replacementText.replace(new RegExp(un, "gi"), match => {
  //       if (!own) {
  //       return '<div class="highlight-text">' + match + "</div>";
  //       } else {
  //         return '<div class="highlight-chat-own">' + match + "</div>";
  //       }
  //     });
  //   });

  //   return replacementText;
  // }
}
