import {
  animate,
  sequence,
  style,
  transition,
  trigger
} from '@angular/animations';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { ChatmessageGrouping } from '@chat/models/view/chatmessage-grouping';
import { ChatMessageEntity } from '@chat/state/chat-rooms/chat-message.entity';
import { Store } from '@ngrx/store';
import { selectAllUsers } from '@organization/state';
import * as fromRoot from '@root';
import { PerfectScrollbarComponent } from 'ngx-perfect-scrollbar';
import { timer } from 'rxjs';

@Component({
  selector: 'app-chat-list',
  templateUrl: './chat-list.component.html',
  styleUrls: ['./chat-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('newMessage', [
      transition('void => *', [
        style({
          transform: 'scale(0.3)',
          opacity: '0'
        }),
        sequence([
          animate(
            '100ms linear',
            style({
              transform: 'scale(0.3)',
              opacity: '0'
            })
          ),
          animate(
            '133ms ease-out',
            style({
              transform: 'scale(1)',
              opacity: '1'
            })
          )
        ])
      ])
    ])
  ]
})
export class ChatListComponent implements OnInit, OnChanges, AfterViewInit {
  @Input()
  messages: ChatmessageGrouping[];
  @Input()
  total: number;

  @ViewChild('scrollbar')
  scrollbar: PerfectScrollbarComponent;

  usernames: string[];

  animationDisabled = true;

  constructor(private store: Store<fromRoot.RootState>) {}

  ngOnInit() {
    this.usernames = new Array();
    this.store.select(selectAllUsers).subscribe(u => {
      u.forEach(user => {
        this.usernames.push('@' + user.name);
      });
    });
  }

  ngAfterViewInit() {
    timer(0).subscribe(() => {
      this.scrollbar.directiveRef.scrollToBottom();
    });
    this.animationDisabled = false;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!this.scrollbar.directiveRef) {
      return;
    }
    const totalChanges = changes['total'];
    if (
      totalChanges &&
      (totalChanges.previousValue ||
        totalChanges.previousValue < totalChanges.currentValue)
    ) {
      timer(0).subscribe(() => {
        this.scrollbar.directiveRef.scrollToBottom();
      });
    }
  }

  groupingTrackByFn(i: number, grouping: ChatmessageGrouping) {
    return i;
  }

  messageTrackByFn(i: number, message: ChatMessageEntity) {
    return message.id;
  }
}
