import { ChatRoomEffects } from './chat-rooms/chat-room.effects';

export const ChatEffects = [ChatRoomEffects];
