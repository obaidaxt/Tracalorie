import { ChatmessageType } from '@chat/models/api/chatmessage';
import { ChatmessageGrouping } from '@chat/models/view/chatmessage-grouping';
import { ChatMessageEntity } from '@chat/state/chat-rooms/chat-message.entity';
import { UserStored } from '@organization/models/stored/user.stored';

export const getChatmessagesView = (
  messages: ChatMessageEntity[],
  users: UserStored[],
  userId: string
): ChatmessageGrouping[] => {
  messages = messages.sort(
    (messageA, messageB) => messageA.date.valueOf() - messageB.date.valueOf()
  );

  const groupings: ChatmessageGrouping[] = [];

  let latestGrouping: ChatmessageGrouping;
  for (const message of messages) {
    if (
      typeof latestGrouping === 'undefined' ||
      message.type !== latestGrouping.type ||
      (message.type === ChatmessageType.Default
        ? !latestGrouping.user || latestGrouping.user.id !== message.userId
        : latestGrouping.externEmail !== message.externEmail)
    ) {
      latestGrouping = {
        externEmail: message.externEmail,
        messages: [message],
        own: message.userId === userId,
        type: message.type,
        user: users.find(u => u.id === message.userId),
        date: message.date
      };
      groupings.push(latestGrouping);
    } else {
      latestGrouping.messages.push(message);
    }
  }

  return groupings;
};
