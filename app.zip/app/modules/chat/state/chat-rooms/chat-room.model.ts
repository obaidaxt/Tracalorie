import { LoadingStatus } from '../../../../common/models/loading-status';
import { State } from './chat-message.reducer';

export interface ChatRoom {
  id: number;
  loadingStatus: LoadingStatus;
  loadingError: string;
  formStatus: LoadingStatus;
  formError: string;
  messages: State;
}
