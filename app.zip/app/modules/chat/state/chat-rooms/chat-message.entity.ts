import { Chatmessage } from '@chat/models/api/chatmessage';
import { LoadingStatus } from '../../../../common/models/loading-status';

export interface ChatMessageEntity extends Chatmessage {
  formStatus: LoadingStatus;
  formError: string;
}
