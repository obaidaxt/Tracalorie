import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import {
  catchError,
  filter,
  map,
  mergeMap,
  switchMap,
  takeUntil
} from 'rxjs/operators';
import { DataChangeType } from '../../../../common/models/data-change-type';
import { ChatService } from '../../services/chat.service';
import {
  ChatmessageAdded,
  ChatmessageModified,
  ChatmessageRemoved,
  ChatRoomActionTypes,
  CreateChatmessage,
  CreateChatmessageFailed,
  CreateChatmessageSuccess,
  CreateExternChatmessage,
  CreateExternChatmessageFailed,
  CreateExternChatmessageSuccess,
  DeleteChatmessage,
  DeleteChatmessageFailed,
  DeleteChatmessageSuccess,
  JoinChatroom,
  JoinChatroomFailed,
  JoinChatroomSuccess,
  LeaveChatroom,
  LoadChatmessages,
  LoadChatmessagesFailed,
  LoadChatmessageSuccess,
  UpdateChatmessage,
  UpdateChatmessageFailed,
  UpdateChatmessageSuccess
} from './chat-room.actions';

@Injectable()
export class ChatRoomEffects {
  constructor(private actions$: Actions, private chatService: ChatService) {}

  leaveRoom$: Observable<number> = this.actions$.pipe(
    ofType(ChatRoomActionTypes.LeaveRoom),
    map(({ roomId }: LeaveChatroom) => roomId)
  );

  @Effect()
  loadMessages$: Observable<Action> = this.actions$.pipe(
    ofType(ChatRoomActionTypes.JoinRoom),
    switchMap(({ roomId }: JoinChatroom) =>
      this.chatService.getMessages(roomId).pipe(
        takeUntil(this.leaveRoom$.pipe(filter(id => id === roomId))),
        map(messages => new JoinChatroomSuccess({ roomId, messages })),
        catchError(err => of(new JoinChatroomFailed(roomId, err)))
      )
    )
  );

  @Effect()
  joinRoom$: Observable<Action> = this.actions$.pipe(
    ofType(ChatRoomActionTypes.JoinRoomSuccess),
    switchMap(({ payload: { roomId } }: JoinChatroomSuccess) =>
      this.chatService.joinRoom(roomId).pipe(
        takeUntil(this.leaveRoom$.pipe(filter(id => id === roomId))),
        map(action => {
          switch (action.type) {
            case DataChangeType.Added: {
              return new ChatmessageAdded(action.data);
            }
            case DataChangeType.Modified: {
              return new ChatmessageModified(action.data);
            }
            case DataChangeType.Removed: {
              return new ChatmessageRemoved(action.data);
            }
          }
        })
      )
    )
  );

  @Effect()
  reload$: Observable<
    LoadChatmessageSuccess | LoadChatmessagesFailed
  > = this.actions$.pipe(
    ofType(ChatRoomActionTypes.LoadChatmessages),
    switchMap(({ roomId }: LoadChatmessages) =>
      this.chatService.getMessages(roomId).pipe(
        takeUntil(this.leaveRoom$.pipe(filter(id => id === roomId))),
        map(messages => new LoadChatmessageSuccess(roomId, messages)),
        catchError(err => of(new LoadChatmessagesFailed(roomId, err)))
      )
    )
  );

  @Effect()
  create$: Observable<Action> = this.actions$.pipe(
    ofType(ChatRoomActionTypes.Create),
    mergeMap(({ payload }: CreateChatmessage) =>
      this.chatService.createChatmessage(payload).pipe(
        map(message => new CreateChatmessageSuccess(message)),
        catchError(err =>
          of(new CreateChatmessageFailed(err, payload.chatroomId))
        )
      )
    )
  );

  @Effect()
  createExtern$: Observable<Action> = this.actions$.pipe(
    ofType(ChatRoomActionTypes.CreateExtern),
    mergeMap(({ payload }: CreateExternChatmessage) =>
      this.chatService.createExternChatmessage(payload).pipe(
        map(message => new CreateExternChatmessageSuccess(message)),
        catchError(err =>
          of(new CreateExternChatmessageFailed(err, payload.chatroomId))
        )
      )
    )
  );

  @Effect()
  update$: Observable<Action> = this.actions$.pipe(
    ofType(ChatRoomActionTypes.Update),
    mergeMap(({ messageId, payload, roomId }: UpdateChatmessage) =>
      this.chatService.updateChatmessage(messageId, payload).pipe(
        map(message => new UpdateChatmessageSuccess(message)),
        catchError(err =>
          of(new UpdateChatmessageFailed(err, roomId, messageId))
        )
      )
    )
  );

  @Effect()
  delete$: Observable<Action> = this.actions$.pipe(
    ofType(ChatRoomActionTypes.Delete),
    mergeMap(({ message }: DeleteChatmessage) =>
      this.chatService.deleteChatmessage(message.id).pipe(
        map(() => new DeleteChatmessageSuccess(message)),
        catchError(err =>
          of(new DeleteChatmessageFailed(err, message.id, message.roomId))
        )
      )
    )
  );
}
