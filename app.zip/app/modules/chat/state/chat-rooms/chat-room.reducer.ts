import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import { ChatRoom } from './chat-room.model';
import { ChatRoomActions, ChatRoomActionTypes } from './chat-room.actions';
import { Chatmessage } from '@chat/models/api/chatmessage';
import {
  chatmessagesReducer,
  messagesInitialState
} from './chat-message.reducer';
import { LoadingStatus } from '../../../../common/models/loading-status';

export interface State extends EntityState<ChatRoom> {}

export const adapter = createEntityAdapter<ChatRoom>();

export const initialState: State = adapter.getInitialState({});

export const roomInitialState: ChatRoom = {
  formError: null,
  formStatus: LoadingStatus.Waiting,
  id: null,
  loadingError: null,
  loadingStatus: LoadingStatus.Waiting,
  messages: messagesInitialState
};

export function reducer(state = initialState, action: ChatRoomActions): State {
  switch (action.type) {
    case ChatRoomActionTypes.JoinRoom: {
      if (state.entities[action.roomId]) {
        return adapter.updateOne(
          {
            id: action.roomId,
            changes: {
              loadingStatus: LoadingStatus.Loading
            }
          },
          state
        );
      } else {
        return adapter.addOne(
          {
            ...roomInitialState,
            id: action.roomId,
            loadingStatus: LoadingStatus.Loading
          },
          state
        );
      }
    }

    case ChatRoomActionTypes.JoinRoomSuccess: {
      const room = state.entities[action.payload.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: action.payload.roomId,
          changes: {
            loadingStatus: LoadingStatus.Completed,
            messages: chatmessagesReducer(room.messages, action)
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.JoinRoomFailed: {
      return adapter.updateOne(
        {
          id: action.roomId,
          changes: {
            loadingStatus: LoadingStatus.Failed,
            loadingError: action.error
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.LoadChatmessages: {
      return adapter.updateOne(
        {
          id: action.roomId,
          changes: {
            loadingStatus: LoadingStatus.Loading
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.LoadChatmessagesSuccess: {
      const room = state.entities[action.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: action.roomId,
          changes: {
            loadingStatus: LoadingStatus.Completed,
            messages: chatmessagesReducer(room.messages, action)
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.LoadChatmessagesFailed: {
      return adapter.updateOne(
        {
          id: action.roomId,
          changes: {
            loadingStatus: LoadingStatus.Failed,
            loadingError: action.error
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.LeaveRoom: {
      return adapter.updateOne(
        {
          id: action.roomId,
          changes: {
            formStatus: LoadingStatus.Waiting
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.ChatmessageAdded: {
      const room = state.entities[action.message.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: room.id,
          changes: {
            messages: chatmessagesReducer(room.messages, action)
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.ChatmessageModified: {
      const room = state.entities[action.message.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: room.id,
          changes: {
            messages: chatmessagesReducer(room.messages, action)
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.ChatmessageRemoved: {
      const room = state.entities[action.message.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: room.id,
          changes: {
            messages: chatmessagesReducer(room.messages, action)
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.ResetChatForm: {
      return adapter.updateOne(
        {
          id: action.roomId,
          changes: {
            formStatus: LoadingStatus.Waiting,
            formError: null
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.CreateExtern:
    case ChatRoomActionTypes.Create: {
      return adapter.updateOne(
        {
          id: action.payload.chatroomId,
          changes: { formStatus: LoadingStatus.Loading }
        },
        state
      );
    }

    case ChatRoomActionTypes.CreateExternSuccess:
    case ChatRoomActionTypes.CreateSuccess: {
      const room = state.entities[action.message.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: action.message.roomId,
          changes: {
            messages: chatmessagesReducer(room.messages, action),
            formStatus: LoadingStatus.Completed
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.CreateExternFailed:
    case ChatRoomActionTypes.CreateFailed: {
      return adapter.updateOne(
        {
          id: action.roomId,
          changes: {
            formStatus: LoadingStatus.Failed,
            formError: action.error
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.Update: {
      const room = state.entities[action.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: room.id,
          changes: {
            messages: chatmessagesReducer(room.messages, action)
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.UpdateSuccess: {
      const room = state.entities[action.message.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: room.id,
          changes: {
            messages: chatmessagesReducer(room.messages, action)
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.UpdateFailed: {
      const room = state.entities[action.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: room.id,
          changes: {
            messages: chatmessagesReducer(room.messages, action)
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.DeleteSuccess: {
      const room = state.entities[action.message.roomId];
      if (!room) {
        return state;
      }
      return adapter.updateOne(
        {
          id: room.id,
          changes: {
            messages: chatmessagesReducer(room.messages, action)
          }
        },
        state
      );
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
