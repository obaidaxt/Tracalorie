import { Action } from '@ngrx/store';
import { Update } from '@ngrx/entity';
import { ChatRoom } from './chat-room.model';
import { Chatmessage } from '@chat/models/api/chatmessage';
import { ChatmessageCreate } from '@chat/models/api/chatmessage-create';
import { ChatmessageUpdate } from '@chat/models/api/chatmessage-update';
import { ChatmessageCreateExtern } from '@chat/models/api/chatmessage-create-extern';

export enum ChatRoomActionTypes {
  JoinRoom = '[Chat] Join Room',
  JoinRoomSuccess = '[API] Join Room Success',
  JoinRoomFailed = '[API] Join Room Failed',
  LoadChatmessages = '[Chat] Load Chatmessages',
  LoadChatmessagesSuccess = '[API] Load Chatmessages Success',
  LoadChatmessagesFailed = '[API] Load Chatmessages Failed',
  LeaveRoom = '[Chat] Leave Room',
  ChatmessageAdded = '[SignalR] Chatmessage Added',
  ChatmessageModified = '[SignalR] Chatmessage Modified',
  ChatmessageRemoved = '[SignalR] Chatmessage Removed',
  ResetChatForm = '[Chat Form] Reset',
  Create = '[Chat Form] Create Chatmessage',
  CreateSuccess = '[API] Create Chatmessage Success',
  CreateFailed = '[API] Create Chatmessage Failed',
  Update = '[Chatmessage] Update Chatmessage',
  UpdateSuccess = '[API] Update Chatmesage Success',
  UpdateFailed = '[API] Update Chatmessage Failed',
  Delete = '[Chatmessage] Delete Chatmessage',
  DeleteSuccess = '[API] Delete Chatmessage Success',
  DeleteFailed = '[API] Delete Chatmessage Failed',
  CreateExtern = '[Chat Form] Create Extern Chatmessage',
  CreateExternSuccess = '[API] Create Extern Chatmessage Success',
  CreateExternFailed = '[API] Create Extern Chatmessage Failed'
}

export class JoinChatroom implements Action {
  readonly type = ChatRoomActionTypes.JoinRoom;
  constructor(public roomId: number) {}
}

export class JoinChatroomSuccess implements Action {
  readonly type = ChatRoomActionTypes.JoinRoomSuccess;
  constructor(public payload: { roomId: number; messages: Chatmessage[] }) {}
}

export class JoinChatroomFailed implements Action {
  readonly type = ChatRoomActionTypes.JoinRoomFailed;
  constructor(public roomId: number, public error: string) {}
}

export class LoadChatmessages implements Action {
  readonly type = ChatRoomActionTypes.LoadChatmessages;
  constructor(public roomId: number) {}
}

export class LoadChatmessageSuccess implements Action {
  readonly type = ChatRoomActionTypes.LoadChatmessagesSuccess;
  constructor(public roomId: number, public message: Chatmessage[]) {}
}

export class LoadChatmessagesFailed implements Action {
  readonly type = ChatRoomActionTypes.LoadChatmessagesFailed;
  constructor(public roomId: number, public error: string) {}
}

export class LeaveChatroom implements Action {
  readonly type = ChatRoomActionTypes.LeaveRoom;
  constructor(public roomId: number) {}
}

export class ChatmessageAdded implements Action {
  readonly type = ChatRoomActionTypes.ChatmessageAdded;
  constructor(public message: Chatmessage) {}
}

export class ChatmessageModified implements Action {
  readonly type = ChatRoomActionTypes.ChatmessageModified;
  constructor(public message: Chatmessage) {}
}

export class ChatmessageRemoved implements Action {
  readonly type = ChatRoomActionTypes.ChatmessageRemoved;
  constructor(public message: Chatmessage) {}
}

export class ResetChatForm implements Action {
  readonly type = ChatRoomActionTypes.ResetChatForm;
  constructor(public roomId: number) {}
}

export class CreateChatmessage implements Action {
  readonly type = ChatRoomActionTypes.Create;
  constructor(public payload: ChatmessageCreate) {}
}

export class CreateChatmessageSuccess implements Action {
  readonly type = ChatRoomActionTypes.CreateSuccess;
  constructor(public message: Chatmessage) {}
}

export class CreateChatmessageFailed implements Action {
  readonly type = ChatRoomActionTypes.CreateFailed;
  constructor(public error: string, public roomId: number) {}
}

export class UpdateChatmessage implements Action {
  readonly type = ChatRoomActionTypes.Update;
  constructor(
    public payload: ChatmessageUpdate,
    public messageId: number,
    public roomId: number
  ) {}
}

export class UpdateChatmessageSuccess implements Action {
  readonly type = ChatRoomActionTypes.UpdateSuccess;
  constructor(public message: Chatmessage) {}
}

export class UpdateChatmessageFailed implements Action {
  readonly type = ChatRoomActionTypes.UpdateFailed;
  constructor(
    public error: string,
    public roomId: number,
    public messageId: number
  ) {}
}

export class DeleteChatmessage implements Action {
  readonly type = ChatRoomActionTypes.Delete;
  constructor(public message: Chatmessage) {}
}

export class DeleteChatmessageSuccess implements Action {
  readonly type = ChatRoomActionTypes.DeleteSuccess;
  constructor(public message: Chatmessage) {}
}

export class DeleteChatmessageFailed implements Action {
  readonly type = ChatRoomActionTypes.DeleteFailed;
  constructor(
    public error: string,
    public messageId: number,
    public roomId: number
  ) {}
}

export class CreateExternChatmessage implements Action {
  readonly type = ChatRoomActionTypes.CreateExtern;
  constructor(public payload: ChatmessageCreateExtern) {}
}

export class CreateExternChatmessageSuccess implements Action {
  readonly type = ChatRoomActionTypes.CreateExternSuccess;
  constructor(public message: Chatmessage) {}
}

export class CreateExternChatmessageFailed implements Action {
  readonly type = ChatRoomActionTypes.CreateExternFailed;
  constructor(public error: string, public roomId: number) {}
}

export type ChatRoomActions =
  | JoinChatroom
  | JoinChatroomSuccess
  | JoinChatroomFailed
  | LoadChatmessages
  | LoadChatmessageSuccess
  | LoadChatmessagesFailed
  | LeaveChatroom
  | ChatmessageAdded
  | ChatmessageModified
  | ChatmessageRemoved
  | ResetChatForm
  | CreateChatmessage
  | CreateChatmessageSuccess
  | CreateChatmessageFailed
  | UpdateChatmessage
  | UpdateChatmessageSuccess
  | UpdateChatmessageFailed
  | DeleteChatmessage
  | DeleteChatmessageSuccess
  | DeleteChatmessageFailed
  | CreateExternChatmessage
  | CreateExternChatmessageSuccess
  | CreateExternChatmessageFailed;
