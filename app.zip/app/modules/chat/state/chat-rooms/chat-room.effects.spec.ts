import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { ChatRoomEffects } from './chat-room.effects';

describe('ChatRoomService', () => {
  let actions$: Observable<any>;
  let effects: ChatRoomEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ChatRoomEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(ChatRoomEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
