import { ChatMessageEntity } from '@chat/state/chat-rooms/chat-message.entity';
import { createEntityAdapter, EntityState } from '@ngrx/entity';
import { LoadingStatus } from '../../../../common/models/loading-status';
import { ChatRoomActions, ChatRoomActionTypes } from './chat-room.actions';

export interface State extends EntityState<ChatMessageEntity> {}

export const adapter = createEntityAdapter<ChatMessageEntity>({
  selectId: message => message.id
});

export const messagesInitialState: State = adapter.getInitialState({});

export function chatmessagesReducer(
  state = messagesInitialState,
  action: ChatRoomActions
): State {
  switch (action.type) {
    case ChatRoomActionTypes.JoinRoomSuccess: {
      return adapter.addAll(
        action.payload.messages.map<ChatMessageEntity>(message => ({
          ...message,
          formError: null,
          formStatus: LoadingStatus.Waiting
        })),
        state
      );
    }

    case ChatRoomActionTypes.LoadChatmessagesSuccess: {
      return adapter.addAll(
        action.message.map<ChatMessageEntity>(message => ({
          ...message,
          formError: null,
          formStatus: LoadingStatus.Waiting
        })),
        state
      );
    }

    case ChatRoomActionTypes.ChatmessageAdded: {
      return adapter.addOne(
        {
          ...action.message,
          formError: null,
          formStatus: LoadingStatus.Waiting
        },
        state
      );
    }

    case ChatRoomActionTypes.ChatmessageModified: {
      return adapter.updateOne(
        { id: action.message.id, changes: action.message },
        state
      );
    }

    case ChatRoomActionTypes.ChatmessageRemoved: {
      return adapter.removeOne(action.message.id, state);
    }

    case ChatRoomActionTypes.CreateExternSuccess:
    case ChatRoomActionTypes.CreateSuccess: {
      return adapter.addOne(
        {
          ...action.message,
          formStatus: LoadingStatus.Waiting,
          formError: null
        },
        state
      );
    }

    case ChatRoomActionTypes.Update: {
      return adapter.updateOne(
        {
          id: action.messageId,
          changes: {
            formStatus: LoadingStatus.Loading
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.UpdateSuccess: {
      return adapter.updateOne(
        {
          id: action.message.id,
          changes: {
            ...action.message,
            formStatus: LoadingStatus.Completed
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.UpdateFailed: {
      return adapter.updateOne(
        {
          id: action.messageId,
          changes: {
            formStatus: LoadingStatus.Failed,
            formError: action.error
          }
        },
        state
      );
    }

    case ChatRoomActionTypes.DeleteSuccess: {
      return adapter.removeOne(action.message.id, state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectAll,
  selectEntities,
  selectIds,
  selectTotal
} = adapter.getSelectors();
