import { selectUserId } from '@account/state';
import { getChatmessagesView } from '@chat/state/chat-rooms/get-chatmessage-view';
import { createSelector } from '@ngrx/store';
import { selectAllUsers } from '@organization/state';
import * as chat from '../chat.reducer';
import * as chatmessages from './chat-message.reducer';
import * as chatroom from './chat-room.reducer';

export const selectChatroomState = createSelector(
  chat.selectChatState,
  state => state.chatrooms
);

export const selectChatroomEntities = createSelector(
  selectChatroomState,
  chatroom.selectEntities
);

export const selectChatroom = (id: number) =>
  createSelector(selectChatroomEntities, chatrooms => chatrooms[id]);

export const selectChatmessagesState = (id: number) =>
  createSelector(selectChatroom(id), room => room.messages);

export const selectChatmessages = (id: number) =>
  createSelector(selectChatmessagesState(id), chatmessages.selectAll);

export const selectChatmessageTotal = (id: number) =>
  createSelector(selectChatmessages(id), messages => messages.length);

export const selectChatmessageView = (id: number) =>
  createSelector(
    selectChatmessages(id),
    selectAllUsers,
    selectUserId,
    getChatmessagesView
  );
