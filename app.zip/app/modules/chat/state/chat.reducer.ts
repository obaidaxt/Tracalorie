import * as chatrooms from './chat-rooms/chat-room.reducer';
import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';

export interface ChatState {
  chatrooms: chatrooms.State;
}

export interface State {
  chat: ChatState;
}

export const reducers: ActionReducerMap<ChatState> = {
  chatrooms: chatrooms.reducer
};

export const selectChatState = createFeatureSelector<ChatState>('chat');
