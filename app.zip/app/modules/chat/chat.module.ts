import { NgModule } from '@angular/core';
import { FileModule } from '@file/file.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SharedModule } from '../../shared/shared.module';
import { ChatFormComponent } from './components/chat-form/chat-form.component';
import { ChatInputComponent } from './components/chat-input/chat-input.component';
import { ChatItemComponent } from './components/chat-item/chat-item.component';
import { ChatListComponent } from './components/chat-list/chat-list.component';
import { ChatRoomComponent } from './containers/chat-room/chat-room.component';
import { ChatTextPipe } from './pipes/chat-text.pipe';
import { reducers } from './state';
import { ChatEffects } from './state/chat.effects';

@NgModule({
  imports: [
    SharedModule,
    StoreModule.forFeature('chat', reducers),
    EffectsModule.forFeature(ChatEffects),
    FileModule
  ],
  declarations: [
    ChatListComponent,
    ChatItemComponent,
    ChatFormComponent,
    ChatRoomComponent,
    ChatTextPipe,
    ChatInputComponent
  ],
  exports: [ChatRoomComponent]
})
export class ChatModule {}
