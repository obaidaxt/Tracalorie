import { ChatTextPipe } from './chat-text.pipe';

describe('ChatTextPipe', () => {
  it('create an instance', () => {
    const pipe = new ChatTextPipe();
    expect(pipe).toBeTruthy();
  });
});
