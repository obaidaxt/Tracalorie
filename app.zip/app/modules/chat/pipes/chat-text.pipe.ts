import { Pipe, PipeTransform, Sanitizer } from '@angular/core';

@Pipe({
  name: 'chatText'
})
export class ChatTextPipe implements PipeTransform {
  constructor(private sanitizer: Sanitizer) {}

  transform(rawText: string): string {
    console.log(rawText);
    const text = rawText.replace(/\</, '&lt;').replace(/\>/, '&gt;');
    return text;
  }

}
