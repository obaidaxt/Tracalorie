export interface ChatmessageUpdate {
  text: string;
  files: number[];
}
