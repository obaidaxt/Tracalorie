import { FileApi } from '@file/models/api/file.api';

export interface ProjectChatMessage {
  id: number;
  userId: string;
  email: string;
  projectId: number;
  text: string;
  date: Date;
  files: FileApi[];
  type: 'standard' | 'fromExtern' | 'toExtern';
}
