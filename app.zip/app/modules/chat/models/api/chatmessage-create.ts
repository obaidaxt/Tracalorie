export interface ChatmessageCreate {
  chatroomId: number;
  text: string;
  files: number[];
}
