import { FileApi } from '@file/models/api/file.api';

export interface Chatmessage {
  id: number;
  roomId: number;
  userId: string;
  externEmail: string;
  text: string;
  date: Date;
  files: FileApi[];
  type: ChatmessageType;
}

export enum ChatmessageType {
  Default,
  ToExtern,
  FromExtern
}
