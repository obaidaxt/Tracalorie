import { ProjectChatMessageCreate } from './project-chat-message-create';

export interface ProjectChatMessageExternCreate extends ProjectChatMessageCreate {
  email: string;
  lvs: number[];
}
