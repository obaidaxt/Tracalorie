import { ChatmessageCreate } from './chatmessage-create';

export interface ChatmessageCreateExtern extends ChatmessageCreate {
  email: string;
}
