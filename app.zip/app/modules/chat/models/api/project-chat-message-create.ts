export interface ProjectChatMessageCreate {
  projectId: number;
  text: string;
  files: number[];
}
