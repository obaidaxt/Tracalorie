import { ChatmessageType } from '@chat/models/api/chatmessage';
import { ChatMessageEntity } from '@chat/state/chat-rooms/chat-message.entity';
import { UserStored } from '@organization/models/stored/user.stored';

export interface ChatmessageGrouping {
  user: UserStored;
  externEmail: string;
  type: ChatmessageType;
  own: boolean;
  messages: ChatMessageEntity[];
  date: Date;
}
