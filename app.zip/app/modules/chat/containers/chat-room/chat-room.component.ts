import { ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Chatmessage } from '@chat/models/api/chatmessage';
import { ChatmessageUpdate } from '@chat/models/api/chatmessage-update';
import { ChatFormValue } from '@chat/components/chat-form/chat-form-value';
import { ChatmessageGrouping } from '@chat/models/view/chatmessage-grouping';
import * as chat from '@chat/state';
import { ChatRoom } from '@chat/state/chat-rooms/chat-room.model';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-chat-room',
  templateUrl: './chat-room.component.html',
  styleUrls: ['./chat-room.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatRoomComponent implements OnInit, OnDestroy {
  @Input() roomId: number;
  @Input() extern = false;

  room$: Observable<ChatRoom>;
  messages$: Observable<ChatmessageGrouping[]>;
  total$: Observable<number>;

  constructor(private store: Store<chat.State>, private dialog: MatDialog) {}

  ngOnInit() {
    this.room$ = this.store.select(chat.selectChatroom(this.roomId));
    this.messages$ = this.store.select(chat.selectChatmessageView(this.roomId));
    this.total$ = this.store.select(chat.selectChatmessageTotal(this.roomId));

    this.store.dispatch(new chat.JoinChatroom(this.roomId));
  }

  ngOnDestroy() {
    this.store.dispatch(new chat.LeaveChatroom(this.roomId));
  }

  create({ chatroomId, email, extern, files, text }: ChatFormValue) {
    if (extern) {
      this.store.dispatch(
        new chat.CreateExternChatmessage({
          chatroomId,
          text,
          email,
          files
        })
      );
    } else {
      this.store.dispatch(
        new chat.CreateChatmessage({
          chatroomId,
          text,
          files
        })
      );
    }
  }

  udpate({
    roomId,
    messageId,
    changes
  }: {
    roomId: number;
    messageId: number;
    changes: ChatmessageUpdate;
  }) {
    this.store.dispatch(new chat.UpdateChatmessage(changes, messageId, roomId));
  }

  delete(message: Chatmessage) {
    this.store.dispatch(new chat.DeleteChatmessage(message));
  }

  reloadChat() {
    this.store.dispatch(new chat.LoadChatmessages(this.roomId));
  }
}
