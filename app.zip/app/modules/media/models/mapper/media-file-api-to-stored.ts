import { MediaFileApi } from '../api/media-file.api';
import { MediaFileStored } from '../stored/media-file.stored';

export const mediaFileApiToStored = (file: MediaFileApi): MediaFileStored => ({
  ...file,
  date: new Date(file.date)
});
