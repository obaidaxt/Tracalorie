export enum WorkspaceType {
  User,
  Organization
}
