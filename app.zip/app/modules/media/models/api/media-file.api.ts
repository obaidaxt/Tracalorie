import { FileApi } from '@file/models/api/file.api';

export interface MediaFileApi extends FileApi {
  folderId: number | null;
  workspaceId: number | null;
  uploaderId: string;
  height: number;
  width: number;
}
