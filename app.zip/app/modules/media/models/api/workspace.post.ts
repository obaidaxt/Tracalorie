import { WorkspaceType } from './workspace-type.enum';

export interface WorkspacePost {
  type: WorkspaceType;
  name: string;
  users: string[];
  groups: number[];
}
