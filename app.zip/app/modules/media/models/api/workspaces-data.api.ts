import { FolderApi } from './folder.api';
import { WorkspaceApi } from './workspace.api';

export interface WorkspacesDataApi {
  workspaces: WorkspaceApi[];
  folders: FolderApi[];
  loadedFolders: number[];
}
