export interface TagPost {
  title: string;
}
