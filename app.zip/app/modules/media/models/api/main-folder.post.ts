export interface MainFolderPost {
  workspaceId: number;
  name: string;
}
