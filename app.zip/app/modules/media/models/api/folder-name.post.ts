export interface FolderNamePost {
  folderId: number;
  name: string;
}
