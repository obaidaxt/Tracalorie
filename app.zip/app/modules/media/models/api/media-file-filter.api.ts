export interface MediaFileFilterApi {
  skip: number;
  take: number;
  workspaceId: number;
  folderId?: number;
}
