export interface TagApi {
  id: number;
  title: string;
}
