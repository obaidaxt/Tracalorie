export interface FolderApi {
  id: number;
  name: string;
  mainFolderId: number | null;
  workspaceId: number | null;
}
