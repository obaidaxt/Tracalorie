import { WorkspaceType } from './workspace-type.enum';

export interface WorkspaceApi {
  id: number;
  name: string;
  type: WorkspaceType;
}
