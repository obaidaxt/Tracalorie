export interface SubFolderPost {
  mainFolderId: number;
  name: string;
}
