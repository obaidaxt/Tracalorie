export interface MediaFilePost {
  workspaceId?: number;
  folderId?: number;
}
