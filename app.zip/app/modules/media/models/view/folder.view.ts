import { FolderStored } from '../stored/folder.stored';

export interface FolderView extends FolderStored {
  subFolders: FolderView[];
}
