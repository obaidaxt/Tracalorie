import { WorkspaceStored } from '../stored/workspace.stored';
import { FolderView } from './folder.view';

export interface WorkspaceView extends WorkspaceStored {
  folders: FolderView[];
}
