import { WorkspaceType } from '../api/workspace-type.enum';

export const workspaceTypes: { type: WorkspaceType; name: string }[] = [
  {
    type: WorkspaceType.User,
    name: 'Persönlicher Bereich'
  },
  {
    type: WorkspaceType.Organization,
    name: 'Gruppen-Bereich'
  }
];
