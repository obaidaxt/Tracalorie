import { FileStored } from '@file/models/stored/file.stored';

export interface MediaFileStored extends FileStored {
  folderId: number | null;
  workspaceId: number | null;
  uploaderId: string;
  height: number;
  width: number;
}
