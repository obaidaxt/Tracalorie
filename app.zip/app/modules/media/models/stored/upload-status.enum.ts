export enum UploadStatus {
  Pending = 'pending',
  Uploading = 'uploading',
  Failed = 'failed',
  Cancelled = 'cancelled',
  Completed = 'completed'
}
