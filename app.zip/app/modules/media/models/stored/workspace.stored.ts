import { WorkspaceApi } from '../api/workspace.api';
import { LoadingStatus } from '@common/models/loading-status';

export interface WorkspaceStored extends WorkspaceApi {
  loadingStatus: LoadingStatus;
  loadingError: string;
}
