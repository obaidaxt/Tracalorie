import { FolderApi } from '../api/folder.api';
import { LoadingStatus } from '@common/models/loading-status';

export interface FolderStored extends FolderApi {
  loadingStatus: LoadingStatus;
  loadingError: string;
}
