import { UploadStatus } from './upload-status.enum';
import { MediaFileStored } from './media-file.stored';

export interface FileUploadStored {
  id: string;
  file?: File;
  url?: string;
  progress: number;
  error: string | null;
  status: UploadStatus;
  mediaId: number | null;
  type: 'upload' | 'download';
  fileName: string;
  workspaceId: number;
  folderId: number | null;
}
