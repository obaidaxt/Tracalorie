import {
  ChangeDetectionStrategy,
  Component,
  HostListener,
  OnDestroy,
  OnInit
} from '@angular/core';
import { MatDialog } from '@angular/material';
import { LayoutService } from '@core/services/layout.service';
import { ResponsiveService } from '@core/services/responsive.service';
import { Store } from '@ngrx/store';
import {
  RootState,
  selectCurrentFolderId,
  selectCurrentWorkspaceId,
  selectCurrentGalleryId,
  Go
} from '@root';
import { BehaviorSubject, combineLatest, Observable, Subject } from 'rxjs';
import { first, map, takeUntil, filter } from 'rxjs/operators';
import { UploadDialogComponent } from './containers/upload-dialog/upload-dialog.component';
import {
  DownloadFile,
  UploadFile
} from './state/file-upload/file-upload.actions';
import { MediaGalleryComponent } from './containers/media-gallery/media-gallery.component';

@Component({
  selector: 'app-media',
  templateUrl: './media.component.html',
  styleUrls: ['./media.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaComponent implements OnInit, OnDestroy {
  isMobile$: Observable<boolean>;
  sidenavOpen$: Observable<boolean>;
  sidenavToggled$ = new BehaviorSubject(false);
  destroy$ = new Subject<void>();
  hideDropOverlay$ = new BehaviorSubject(true);
  workspaceId$: Observable<number>;
  folderId$: Observable<number>;
  galleryId$: Observable<number>;

  constructor(
    private responsive: ResponsiveService,
    private layout: LayoutService,
    private store: Store<RootState>,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.workspaceId$ = this.store.select(selectCurrentWorkspaceId);
    this.folderId$ = this.store.select(selectCurrentFolderId);
    this.galleryId$ = this.store.select(selectCurrentGalleryId);
    this.isMobile$ = this.responsive.isMobile;
    this.sidenavOpen$ = combineLatest(
      this.isMobile$,
      this.sidenavToggled$
    ).pipe(map(([mobile, toggled]) => !mobile || toggled));
    this.layout
      .getSidenavOpened()
      .pipe(takeUntil(this.destroy$))
      .subscribe(opened => {
        this.sidenavToggled$.next(opened);
      });
    this.openGallery();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  toggleSidenav(opened: boolean) {
    this.sidenavToggled$.next(opened);
  }

  handleDragEnter(event: DragEvent) {
    this.hideDropOverlay$.next(false);
  }

  handleDragLeave(event: DragEvent) {
    this.hideDropOverlay$.next(true);
  }

  handleDrop(event: DragEvent) {
    event.preventDefault();
    this.hideDropOverlay$.next(true);
    const files = event.dataTransfer.files;
    if (files && files.length > 0) {
      this.uploadFiles(files);
    } else {
      const text = event.dataTransfer.getData('TEXT');
      this.downloadFile(text);
    }
  }

  openUploadDialog() {
    this.dialog.open<UploadDialogComponent, void, void>(UploadDialogComponent, {
      autoFocus: false,
      backdropClass: 'form-dialog-backdrop',
      disableClose: true,
      maxWidth: '97vw',
      width: '900px'
    });
  }

  openGallery() {
    this.galleryId$
      .pipe(
        takeUntil(this.destroy$),
        filter(id => typeof id === 'number')
      )
      .subscribe(() => {
        if (
          !this.dialog.openDialogs.some(
            d => d.componentInstance instanceof MediaGalleryComponent
          )
        ) {
          const dialogRef = this.dialog.open(MediaGalleryComponent, {
            panelClass: 'gallery-dialog',
            backdropClass: 'gallery-backdrop',
            width: '100vw',
            maxWidth: '100vw',
            height: '100vh',
            maxHeight: '100vh'
          });
          dialogRef.afterClosed().subscribe(() => {
            this.store.dispatch(
              new Go({
                path: [],
                query: { gallery: undefined },
                extras: {
                  queryParamsHandling: 'merge'
                }
              })
            );
          });
        }
      });
  }

  @HostListener('paste', ['$event'])
  handlePaste(event: ClipboardEvent) {
    const data = event.clipboardData.getData('text/plain').trim();
    this.downloadFile(data);
  }

  private uploadFiles(files: FileList) {
    if (!files || files.length === 0) {
      return;
    }
    combineLatest(this.workspaceId$, this.folderId$)
      .pipe(first())
      .subscribe(([workspaceId, folderId]) => {
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          this.store.dispatch(new UploadFile(file, workspaceId, folderId));
        }
      });
    this.openUploadDialog();
  }

  private downloadFile(url: string) {
    if (!url || !url.startsWith('http')) {
      return;
    }
    combineLatest(this.workspaceId$, this.folderId$)
      .pipe(first())
      .subscribe(([workspaceId, folderId]) => {
        if (typeof workspaceId !== 'number') {
          return;
        }
        this.store.dispatch(new DownloadFile(url, workspaceId, folderId));
        this.openUploadDialog();
      });
  }
}
