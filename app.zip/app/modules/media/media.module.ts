import { NgModule } from '@angular/core';
import { FileModule } from '@file/file.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { OrganizationModule } from '@organization/organization.module';
import { SharedModule } from '@shared/shared.module';
import { MediaFormComponent } from './components/media-form/media-form.component';
import { MediaGridComponent } from './components/media-grid/media-grid.component';
import { UploadListComponent } from './components/upload-list/upload-list.component';
import { MediaDetailsComponent } from './containers/media-details/media-details.component';
import { MediaOverviewComponent } from './containers/media-overview/media-overview.component';
import { MediaSidenavComponent } from './containers/media-sidenav/media-sidenav.component';
import { UploadDialogComponent } from './containers/upload-dialog/upload-dialog.component';
import { MediaRoutingModule } from './media-routing.module';
import { MediaComponent } from './media.component';
import { mediaEffects } from './state/media.effects';
import { mediaReducers } from './state/media.reducers';
import { FolderOverviewComponent } from './containers/folder-overview/folder-overview.component';
import { FolderComponent } from './containers/folder/folder.component';
import { WorkspaceOverviewComponent } from './containers/workspace-overview/workspace-overview.component';
import { WorkspaceDialogComponent } from './containers/workspace-dialog/workspace-dialog.component';
import { WorkspaceFormComponent } from './components/workspace-form/workspace-form.component';
import { WorkspaceComponent } from './components/workspace/workspace.component';
import { FolderBreadcrumbComponent } from './components/folder-breadcrumb/folder-breadcrumb.component';
import { ChatModule } from '@chat/chat.module';
import { MediaSummaryComponent } from './components/media-summary/media-summary.component';
import { MediaInfosComponent } from './components/media-infos/media-infos.component';
import { MediaTagsComponent } from './components/media-tags/media-tags.component';
import { MediaVersionsComponent } from './components/media-versions/media-versions.component';
import { MediaShareComponent } from './components/media-share/media-share.component';
import { MediaGalleryComponent } from './containers/media-gallery/media-gallery.component';

@NgModule({
  imports: [
    SharedModule,
    MediaRoutingModule,
    FileModule,
    StoreModule.forFeature('media', mediaReducers),
    EffectsModule.forFeature(mediaEffects),
    OrganizationModule,
    ChatModule
  ],
  declarations: [
    MediaComponent,
    MediaSidenavComponent,
    MediaOverviewComponent,
    UploadDialogComponent,
    MediaFormComponent,
    MediaGridComponent,
    MediaDetailsComponent,
    UploadListComponent,
    FolderOverviewComponent,
    FolderComponent,
    WorkspaceOverviewComponent,
    WorkspaceDialogComponent,
    WorkspaceFormComponent,
    WorkspaceComponent,
    FolderBreadcrumbComponent,
    MediaSummaryComponent,
    MediaInfosComponent,
    MediaTagsComponent,
    MediaVersionsComponent,
    MediaShareComponent,
    MediaGalleryComponent
  ],
  entryComponents: [
    UploadDialogComponent,
    WorkspaceDialogComponent,
    MediaGalleryComponent
  ]
})
export class MediaModule {}
