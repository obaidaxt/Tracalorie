import { TagApi } from "./../../models/api/tag.api";
import { BehaviorSubject } from "rxjs";
import { TagsService } from "./../../services/tags.service";
import { Component, OnInit, ChangeDetectionStrategy } from "@angular/core";
import { FormGroup, FormBuilder } from "ngx-strongly-typed-forms";
import { TagPost } from "../../models/api/tag.post";
import { Validators } from "@angular/forms";

@Component({
  selector: "app-media-tags",
  templateUrl: "./media-tags.component.html",
  styleUrls: ["./media-tags.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaTagsComponent implements OnInit {
  tags$ = new BehaviorSubject<TagApi[]>([]);
  tagForm: FormGroup<TagPost>;

  constructor(
    private tagsService: TagsService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.tagsService.getTags().subscribe(tags => {
      this.tags$.next(tags);
    });

    this.createForm();
  }

  createForm() {
    this.tagForm = this.formBuilder.group<TagPost>({
      title: [null, Validators.required]
    });
  }

  handleSubmit() {
    if (this.tagForm.invalid) {
      return;
    }
    this.tagsService.createTag(this.tagForm.value).subscribe(tag => {
      this.tags$.next([...this.tags$.value, tag]);
    });
  }
}
