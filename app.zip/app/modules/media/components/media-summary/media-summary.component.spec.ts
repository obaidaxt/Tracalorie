import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MediaSummaryComponent } from './media-summary.component';

describe('MediaSummaryComponent', () => {
  let component: MediaSummaryComponent;
  let fixture: ComponentFixture<MediaSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MediaSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MediaSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
