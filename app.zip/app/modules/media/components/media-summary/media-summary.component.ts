import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';
import { MediaFileStored } from '../../models/stored/media-file.stored';

@Component({
  selector: 'app-media-summary',
  templateUrl: './media-summary.component.html',
  styleUrls: ['./media-summary.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaSummaryComponent implements OnInit {
  @Input() details: MediaFileStored;
  @Input() activeTab = 'infos';

  constructor() { }

  ngOnInit() {
  }

}
