import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  Input,
  EventEmitter,
  Output
} from '@angular/core';
import { FileUploadStored } from '../../models/stored/file-upload.stored';

@Component({
  selector: 'app-upload-list',
  templateUrl: './upload-list.component.html',
  styleUrls: ['./upload-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadListComponent implements OnInit {
  @Input()
  uploads: FileUploadStored[];

  @Output() cancel = new EventEmitter<string>();
  @Output() remove = new EventEmitter<string>();
  @Output() retry = new EventEmitter<FileUploadStored>();
  @Output() select = new EventEmitter<string>();

  constructor() {}

  ngOnInit() {}

  uploadTrackByFn(index: number, upload: FileUploadStored) {
    return upload.id;
  }
}
