import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MediaShareComponent } from './media-share.component';

describe('MediaShareComponent', () => {
  let component: MediaShareComponent;
  let fixture: ComponentFixture<MediaShareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MediaShareComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MediaShareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
