import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-media-share',
  templateUrl: './media-share.component.html',
  styleUrls: ['./media-share.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaShareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
