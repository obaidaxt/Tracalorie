import {
  ChangeDetectionStrategy,
  Component,
  DoCheck,
  ElementRef,
  Input,
  OnInit
} from '@angular/core';
import { BehaviorSubject, combineLatest, Observable } from 'rxjs';
import { filter, map, pairwise } from 'rxjs/operators';
import { MediaFileStored } from '../../models/stored/media-file.stored';
import { MediaGridItem, MediaGridRow } from './media-grid-item';

@Component({
  selector: 'app-media-grid',
  templateUrl: './media-grid.component.html',
  styleUrls: ['./media-grid.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaGridComponent implements OnInit, DoCheck {
  @Input()
  set files(value: MediaFileStored[]) {
    if (value) {
      this.files$.next(value);
    }
  }
  @Input()
  minHeight = 150;
  @Input() previewMargin = 4;

  files$ = new BehaviorSubject<MediaFileStored[]>([]);
  rows$: Observable<MediaGridRow[]>;
  elementWidth$ = new BehaviorSubject<number>(null);

  constructor(private elementRef: ElementRef<HTMLElement>) {}

  ngOnInit() {
    this.rows$ = combineLatest(
      this.files$,
      this.elementWidth$.pipe(
        pairwise(),
        filter(([prev, curr]) => prev !== curr),
        map(([_, curr]) => curr - this.previewMargin)
      )
    ).pipe(
      map(([files, gridWidth]) => {
        if (files.length === 0) {
          return [];
        }
        let row: MediaGridRow = {
          height: this.minHeight,
          items: []
        };
        const rows: MediaGridRow[] = [row];
        let filledWidth = 0;
        for (const file of files) {
          // Mindestweite über Seitenverhältnis und Mindesthöhe definieren
          const minWidth = this.minHeight * (file.width / file.height);
          const item: MediaGridItem = {
            ...file,
            calcWidth: minWidth
          };
          const calcMinWidth = minWidth + this.previewMargin;
          if (filledWidth + calcMinWidth >= gridWidth) {
            // Reihe ist voll
            const multiplier = gridWidth / filledWidth;
            for (const rowItem of row.items) {
              rowItem.calcWidth *= multiplier;
            }
            const firstItem = row.items[0];
            const rowHeight =
              (firstItem.calcWidth * firstItem.height) / firstItem.width;
            row = {
              height: rowHeight,
              items: [item]
            };
            rows.push(row);
            filledWidth = calcMinWidth;
          } else {
            // Item in die Reihe hinzufügen, wenn noch Platz ist
            filledWidth += calcMinWidth;
            row.items.push(item);
          }
        }
        if (rows.length > 0) {
          const lastRow = rows[rows.length - 1];
          const firstItem = lastRow.items[0];
          const rowHeight =
            (firstItem.calcWidth * firstItem.height) / firstItem.width;
          lastRow.height = rowHeight;
        }
        return rows;
      })
    );
  }

  ngDoCheck() {
    this.elementWidth$.next(this.elementRef.nativeElement.clientWidth);
  }

  rowTrackByFn(index: number, row: MediaGridRow) {
    return index;
  }

  mediaTrackByFn(index: number, item: MediaGridItem) {
    return item.id;
  }
}
