import { MediaFileStored } from '../../models/stored/media-file.stored';

export interface MediaGridRow {
  height: number;
  items: MediaGridItem[];
}

export interface MediaGridItem extends MediaFileStored {
  calcWidth: number;
}
