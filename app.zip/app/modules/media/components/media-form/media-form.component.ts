import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-media-form',
  templateUrl: './media-form.component.html',
  styleUrls: ['./media-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
