import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-media-versions',
  templateUrl: './media-versions.component.html',
  styleUrls: ['./media-versions.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaVersionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
