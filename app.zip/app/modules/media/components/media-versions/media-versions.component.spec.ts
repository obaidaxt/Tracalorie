import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MediaVersionsComponent } from './media-versions.component';

describe('MediaVersionsComponent', () => {
  let component: MediaVersionsComponent;
  let fixture: ComponentFixture<MediaVersionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MediaVersionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MediaVersionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
