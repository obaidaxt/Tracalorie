import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FolderBreadcrumbComponent } from './folder-breadcrumb.component';

describe('FolderBreadcrumbComponent', () => {
  let component: FolderBreadcrumbComponent;
  let fixture: ComponentFixture<FolderBreadcrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FolderBreadcrumbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FolderBreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
