import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  Input
} from '@angular/core';
import { WorkspaceStored } from '../../models/stored/workspace.stored';
import { FolderPath } from '../../models/view/folder-path';

@Component({
  selector: 'app-folder-breadcrumb',
  templateUrl: './folder-breadcrumb.component.html',
  styleUrls: ['./folder-breadcrumb.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FolderBreadcrumbComponent implements OnInit {
  @Input()
  activeWorkspace: WorkspaceStored;
  @Input()
  workspaces: WorkspaceStored[];
  @Input()
  folderPaths: FolderPath[];

  constructor() {}

  ngOnInit() {}
}
