import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { WorkspaceView } from '../../models/view/workspace.view';
import { UserStored } from '@organization/models/stored/user.stored';
import { WorkspacePost } from '../../models/api/workspace.post';
import { FormGroup, FormBuilder } from 'ngx-strongly-typed-forms';
import { Validators } from '@angular/forms';
import { LoadingStatus } from '@common/models/loading-status';
import { workspaceTypes } from '../../models/view/workspace-types';

@Component({
  selector: 'app-workspace-form',
  templateUrl: './workspace-form.component.html',
  styleUrls: ['./workspace-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WorkspaceFormComponent implements OnInit {
  @Input()
  workspace: WorkspaceView;
  @Input()
  users: UserStored[];
  @Input()
  groups: any = [];
  @Input()
  status: LoadingStatus;
  @Input()
  error: string;

  @Output()
  onSubmit = new EventEmitter<WorkspacePost>();

  workspaceTypes = workspaceTypes;
  workspaceForm: FormGroup<WorkspacePost>;

  get workspaceType() {
    return this.workspaceForm.get('type');
  }

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.workspaceForm = this.fb.group<WorkspacePost>({
      name: [null, Validators.required],
      type: [null, Validators.required],
      users: [[]],
      groups: [[]]
    });
    if (this.workspace) {
      this.workspaceForm.patchValue(this.workspace);
    }
  }

  handleSubmit() {
    if (this.workspaceForm.invalid) {
      return;
    }
    this.onSubmit.emit(this.workspaceForm.value);
  }
}
