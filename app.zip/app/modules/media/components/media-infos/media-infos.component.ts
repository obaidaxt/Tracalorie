import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-media-infos',
  templateUrl: './media-infos.component.html',
  styleUrls: ['./media-infos.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaInfosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
