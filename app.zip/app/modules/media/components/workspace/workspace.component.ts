import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { LoadingStatus } from '@common/models/loading-status';
import {
  AbstractControl,
  FormControl,
  ValidatorFn
} from 'ngx-strongly-typed-forms';
import { BehaviorSubject, timer } from 'rxjs';
import { MainFolderPost } from '../../models/api/main-folder.post';
import { WorkspaceView } from '../../models/view/workspace.view';
import { FolderView } from '../../models/view/folder.view';

@Component({
  selector: 'app-workspace',
  templateUrl: './workspace.component.html',
  styleUrls: ['./workspace.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WorkspaceComponent implements OnInit, OnChanges {
  @Input()
  workspace: WorkspaceView;
  @Input()
  formStatus: LoadingStatus;
  @Input()
  formError: string;

  @Output()
  edit = new EventEmitter<void>();
  @Output()
  loadFolders = new EventEmitter<number>();
  @Output()
  stopLoadFolders = new EventEmitter<number>();
  @Output()
  createFolder = new EventEmitter<MainFolderPost>();
  @Output()
  resetForm = new EventEmitter<void>();
  @Output()
  delete = new EventEmitter<WorkspaceView>();

  showCreateCtrl$ = new BehaviorSubject(false);
  createFolderCtrl = new FormControl<string>(null, this.validateFolderName());

  @ViewChild('createInput')
  createInput: ElementRef<HTMLElement>;

  constructor() {}

  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges) {
    if (
      changes['formStatus'] &&
      this.formStatus === LoadingStatus.Completed &&
      this.showCreateCtrl$.value
    ) {
      this.createInput.nativeElement.blur();
    }
  }

  showCreateControl() {
    this.showCreateCtrl$.next(true);
    if (this.workspace.loadingStatus !== LoadingStatus.Completed) {
      this.loadFolders.emit(this.workspace.id);
    }
    timer(0).subscribe(() => {
      this.createInput.nativeElement.focus();
    });
  }

  hideCreateControl() {
    this.createFolderCtrl.setValue(null, { emitEvent: false });
    this.resetForm.emit();
    this.showCreateCtrl$.next(false);
  }

  handleKeydown(event: KeyboardEvent) {
    switch (event.key) {
      case 'Enter': {
        event.preventDefault();
        if (this.createFolderCtrl.invalid) {
          return;
        }
        const name =
          this.createFolderCtrl.value && this.createFolderCtrl.value.trim();
        if (!name || name.length === 0) {
          return;
        }
        this.createFolder.emit({
          name,
          workspaceId: this.workspace.id
        });
        break;
      }
      case 'Escape': {
        event.preventDefault();
        this.createInput.nativeElement.blur();
      }
    }
  }

  folderTrackByFn(index: number, folder: FolderView) {
    return folder.id;
  }

  private validateFolderName(): ValidatorFn<string> {
    return (control: AbstractControl<string>) => {
      if (
        this.workspace &&
        control.value &&
        this.workspace.folders.some(
          f => f.name.toLocaleLowerCase() === control.value.toLocaleLowerCase()
        )
      ) {
        return {
          nameInUse: true
        };
      }
      return null;
    };
  }
}
