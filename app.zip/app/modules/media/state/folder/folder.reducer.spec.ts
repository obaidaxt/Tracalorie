import { folderReducer, initialState } from './folder.reducer';

describe('Folder Reducer', () => {
  describe('unknown action', () => {
    it('should return the initial state', () => {
      const action = {} as any;

      const result = folderReducer(initialState, action);

      expect(result).toBe(initialState);
    });
  });
});
