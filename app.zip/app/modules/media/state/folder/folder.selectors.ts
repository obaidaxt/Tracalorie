import { createSelector } from '@ngrx/store';
import { selectMediaState } from '../media.reducers';
import * as fromFolder from './folder.reducer';
import { getFolderView } from './get-folder-view';
import { selectCurrentFolderId } from '@root';
import { getFolderPath } from './get-folder-path';

export const selectFolderState = createSelector(
  selectMediaState,
  state => state.folders
);

export const selectAllFolders = createSelector(
  selectFolderState,
  fromFolder.selectAll
);

export const selectFolderEntities = createSelector(
  selectFolderState,
  fromFolder.selectEntities
);

export const selectCurrentFolder = createSelector(
  selectFolderEntities,
  selectCurrentFolderId,
  (folders, id) => folders[id]
);

export const selectFolderPath = createSelector(
  selectCurrentFolderId,
  selectAllFolders,
  selectFolderEntities,
  getFolderPath
);

export const selectFolderFormStatus = createSelector(
  selectFolderState,
  fromFolder.selectFormStatus
);

export const selectFolderFormError = createSelector(
  selectFolderState,
  fromFolder.selectFormError
);

export const selectFolderLoadingStatus = createSelector(
  selectFolderState,
  fromFolder.selectLoadingStatus
);

export const selectLoadingError = createSelector(
  selectFolderState,
  fromFolder.selectLoadingError
);
