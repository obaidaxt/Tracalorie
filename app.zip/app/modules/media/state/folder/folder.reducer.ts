import { LoadingStatus } from '@common/models/loading-status';
import { createEntityAdapter, EntityState, Update } from '@ngrx/entity';
import { FolderStored } from '../../models/stored/folder.stored';
import {
  LoadWorkspaceFoldersSuccess,
  LoadWorkspacesSuccess,
  WorkspaceActionTypes
} from '../workspace/workspace.actions';
import { FolderActions, FolderActionTypes } from './folder.actions';

export interface FolderState extends EntityState<FolderStored> {
  loadingStatus: LoadingStatus;
  loadingError: string;
  formStatus: LoadingStatus;
  formError: string;
}

export const adapter = createEntityAdapter<FolderStored>({
  selectId: folder => folder.id
});

export const initialState: FolderState = adapter.getInitialState({
  loadingStatus: LoadingStatus.Waiting,
  loadingError: null,
  formStatus: LoadingStatus.Waiting,
  formError: null
});

export function folderReducer(
  state = initialState,
  action: FolderActions | LoadWorkspaceFoldersSuccess | LoadWorkspacesSuccess
): FolderState {
  switch (action.type) {
    case WorkspaceActionTypes.LoadSuccess: {
      return adapter.addMany(action.folders, state);
    }

    case WorkspaceActionTypes.LoadFoldersSuccess: {
      return adapter.addMany(action.folders, state);
    }

    case FolderActionTypes.LoadSubFolders: {
      return adapter.updateOne(
        {
          id: action.parentFolderId,
          changes: {
            loadingStatus: LoadingStatus.Loading
          }
        },
        state
      );
    }

    case FolderActionTypes.StopLoadSubFolders: {
      return adapter.updateOne(
        {
          id: action.parentFolderId,
          changes: {
            loadingStatus: LoadingStatus.Waiting
          }
        },
        state
      );
    }

    case FolderActionTypes.LoadSubFoldersSuccess: {
      return adapter.addMany(
        action.folders,
        adapter.updateOne(
          {
            id: action.parentFolderId,
            changes: {
              loadingStatus: LoadingStatus.Completed
            }
          },
          state
        )
      );
    }

    case FolderActionTypes.LoadSubFoldersFailed: {
      return adapter.updateOne(
        {
          id: action.id,
          changes: {
            loadingError: action.error,
            loadingStatus: LoadingStatus.Failed
          }
        },
        state
      );
    }

    case FolderActionTypes.Added: {
      return adapter.addOne(action.folder, state);
    }

    case FolderActionTypes.Modified: {
      return adapter.updateOne(action.payload, state);
    }

    case FolderActionTypes.Removed: {
      return adapter.removeOne(action.id, state);
    }

    case FolderActionTypes.ResetFolderForm: {
      return {
        ...state,
        formStatus: LoadingStatus.Waiting,
        formError: null
      };
    }

    case FolderActionTypes.CreateMainFolder:
    case FolderActionTypes.CreateSubFolder:
    case FolderActionTypes.UpdateFolderName: {
      return {
        ...state,
        formStatus: LoadingStatus.Loading
      };
    }

    case FolderActionTypes.CreateSubFolderSuccess:
    case FolderActionTypes.CreateMainFolderSuccess: {
      return adapter.addOne(action.folder, {
        ...state,
        formStatus: LoadingStatus.Completed
      });
    }

    case FolderActionTypes.UpdateFolderNameSuccess: {
      return adapter.updateOne(action.payload, {
        ...state,
        formStatus: LoadingStatus.Completed
      });
    }

    case FolderActionTypes.CreateMainFolderFailed:
    case FolderActionTypes.CreateSubFolderFailed:
    case FolderActionTypes.UpdateFolderNameFailed: {
      return {
        ...state,
        formStatus: LoadingStatus.Failed,
        formError: action.error
      };
    }

    case FolderActionTypes.DeleteFolderSuccess: {
      return adapter.removeOne(action.id, state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
export const selectFormStatus = (state: FolderState) => state.formStatus;
export const selectFormError = (state: FolderState) => state.formError;
export const selectLoadingStatus = (state: FolderState) => state.loadingStatus;
export const selectLoadingError = (state: FolderState) => state.loadingError;
