import { Update } from '@ngrx/entity';
import { Action } from '@ngrx/store';
import { FolderNamePost } from '../../models/api/folder-name.post';
import { MainFolderPost } from '../../models/api/main-folder.post';
import { SubFolderPost } from '../../models/api/sub-folder.post';
import { FolderStored } from '../../models/stored/folder.stored';

export enum FolderActionTypes {
  LoadSubFolders = '[Folder Overview] Load Sub Folders',
  StopLoadSubFolders = '[Folder Overview] Stop Load Sub Folders',
  LoadSubFoldersSuccess = '[API] Load Sub Folders Success',
  LoadSubFoldersFailed = '[API] Load Sub Folders Failed',
  Added = '[Websocket] Folder Added',
  Modified = '[Websocket] Folder Modified',
  Removed = '[Websocket] Folder Removed',
  ResetFolderForm = '[Folder Overview] Reset Folder Form',
  CreateMainFolder = '[Folder Overview] Create Main Folder',
  CreateMainFolderSuccess = '[API] Create Main Folder Success',
  CreateMainFolderFailed = '[API] Create Main Folder Failed',
  CreateSubFolder = '[Folder] Create Sub Folder',
  CreateSubFolderSuccess = '[API] Create Sub Folder Success',
  CreateSubFolderFailed = '[API] Create Sub Folder Failed',
  UpdateFolderName = '[Folder] Update Folder Name',
  UpdateFolderNameSuccess = '[API] Update Folder Name Success',
  UpdateFolderNameFailed = '[API] Update Folder Name Failed',
  DeleteFolder = '[Folder] Delete Folder',
  DeleteFolderSuccess = '[API] Delete Folder Success',
  DeleteFolderFailed = '[API] Delete Folder Failed'
}

export class LoadSubFolders implements Action {
  readonly type = FolderActionTypes.LoadSubFolders;
  constructor(public parentFolderId: number) {}
}

export class StopLoadSubFolders implements Action {
  readonly type = FolderActionTypes.StopLoadSubFolders;
  constructor(public parentFolderId: number) {}
}

export class LoadSubFoldersSuccess implements Action {
  readonly type = FolderActionTypes.LoadSubFoldersSuccess;
  constructor(public parentFolderId: number, public folders: FolderStored[]) {}
}

export class LoadSubFoldersFailed implements Action {
  readonly type = FolderActionTypes.LoadSubFoldersFailed;
  constructor(public id: number, public error: string) {}
}

export class FolderAdded implements Action {
  readonly type = FolderActionTypes.Added;
  constructor(public folder: FolderStored) {}
}

export class FolderModified implements Action {
  readonly type = FolderActionTypes.Modified;
  constructor(public payload: Update<FolderStored>) {}
}

export class FolderRemoved implements Action {
  readonly type = FolderActionTypes.Removed;
  constructor(public id: number) {}
}

export class ResetFolderForm implements Action {
  readonly type = FolderActionTypes.ResetFolderForm;
}

export class CreateMainFolder implements Action {
  readonly type = FolderActionTypes.CreateMainFolder;
  constructor(public payload: MainFolderPost) {}
}

export class CreateMainFolderSuccess implements Action {
  readonly type = FolderActionTypes.CreateMainFolderSuccess;
  constructor(public folder: FolderStored) {}
}

export class CreateMainFolderFailed implements Action {
  readonly type = FolderActionTypes.CreateMainFolderFailed;
  constructor(public error: string) {}
}

export class CreateSubFolder implements Action {
  readonly type = FolderActionTypes.CreateSubFolder;
  constructor(public payload: SubFolderPost) {}
}

export class CreateSubFolderSuccess implements Action {
  readonly type = FolderActionTypes.CreateSubFolderSuccess;
  constructor(public folder: FolderStored) {}
}

export class CreateSubFolderFailed implements Action {
  readonly type = FolderActionTypes.CreateSubFolderFailed;
  constructor(public error: string) {}
}

export class UpdateFolderName implements Action {
  readonly type = FolderActionTypes.UpdateFolderName;
  constructor(public payload: FolderNamePost) {}
}

export class UpdateFolderNameSuccess implements Action {
  readonly type = FolderActionTypes.UpdateFolderNameSuccess;
  constructor(public payload: Update<FolderStored>) {}
}

export class UpdateFolderNameFailed implements Action {
  readonly type = FolderActionTypes.UpdateFolderNameFailed;
  constructor(public error: string) {}
}

export class DeleteFolder implements Action {
  readonly type = FolderActionTypes.DeleteFolder;
  constructor(public id: number) {}
}

export class DeleteFolderSuccess implements Action {
  readonly type = FolderActionTypes.DeleteFolderSuccess;
  constructor(public id: number) {}
}

export class DeleteFolderFailed implements Action {
  readonly type = FolderActionTypes.DeleteFolderFailed;
  constructor(public error: string) {}
}

export type FolderActions =
  | LoadSubFolders
  | StopLoadSubFolders
  | LoadSubFoldersSuccess
  | LoadSubFoldersFailed
  | FolderAdded
  | FolderModified
  | FolderRemoved
  | ResetFolderForm
  | CreateMainFolder
  | CreateMainFolderSuccess
  | CreateMainFolderFailed
  | CreateSubFolder
  | CreateSubFolderSuccess
  | CreateSubFolderFailed
  | UpdateFolderName
  | UpdateFolderNameSuccess
  | UpdateFolderNameFailed
  | DeleteFolder
  | DeleteFolderSuccess
  | DeleteFolderFailed;
