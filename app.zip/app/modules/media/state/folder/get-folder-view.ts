import { FolderStored } from '../../models/stored/folder.stored';
import { FolderView } from '../../models/view/folder.view';

export const getFolderView = (folders: FolderStored[]): FolderView[] =>
  folders.filter(f => f.mainFolderId === null).map<FolderView>(folder => createFolderView(folder, folders));

const createFolderView = (folder: FolderStored, folders: FolderStored[]): FolderView => ({
  ...folder,
  subFolders: folders.filter(f => f.mainFolderId === folder.id).map(sub => createFolderView(sub, folders))
});
