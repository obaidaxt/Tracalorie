import { FolderStored } from '../../models/stored/folder.stored';
import { FolderPath } from '../../models/view/folder-path';
import { Dictionary } from '@ngrx/entity';

export const getFolderPath = (
  folderId: number,
  folders: FolderStored[],
  entities: Dictionary<FolderStored>
): FolderPath[] => {
  const paths: FolderPath[] = [];
  while (typeof folderId === 'number') {
    const path = createFolderPath(folderId, folders, entities);
    if (path) {
      paths.push(path);
    }
    folderId = path && path.active.mainFolderId;
  }
  return paths.reverse();
};

const createFolderPath = (
  folderId: number,
  folders: FolderStored[],
  entities: Dictionary<FolderStored>
): FolderPath => {
  const folder = entities[folderId];
  if (!folder) {
    return;
  }
  const sameLevel = folders
    .filter(
      f =>
        f.mainFolderId === folder.mainFolderId &&
        f.workspaceId === folder.workspaceId
    )
    .sort((a, b) => a.name.localeCompare(b.name));
  return {
    active: folder,
    sameLevel
  };
};
