import { Injectable } from '@angular/core';
import { LoadingStatus } from '@common/models/loading-status';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action, Store } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { catchError, filter, map, mergeMap, takeUntil } from 'rxjs/operators';
import { FolderStored } from '../../models/stored/folder.stored';
import { FolderService } from '../../services/folder.service';
import {
  CreateMainFolder,
  CreateMainFolderFailed,
  CreateMainFolderSuccess,
  CreateSubFolder,
  CreateSubFolderFailed,
  CreateSubFolderSuccess,
  DeleteFolder,
  DeleteFolderFailed,
  DeleteFolderSuccess,
  FolderActionTypes,
  LoadSubFolders,
  LoadSubFoldersFailed,
  LoadSubFoldersSuccess,
  StopLoadSubFolders,
  UpdateFolderName,
  UpdateFolderNameFailed,
  UpdateFolderNameSuccess
} from './folder.actions';
import { RootState } from '@root';

@Injectable()
export class FolderEffects {
  constructor(
    private actions$: Actions,
    private folderService: FolderService,
    private store: Store<RootState>
  ) {}

  @Effect()
  loadSubFolders$: Observable<Action> = this.actions$.pipe(
    ofType(FolderActionTypes.LoadSubFolders),
    mergeMap(({ parentFolderId }: LoadSubFolders) =>
      this.folderService.getSubFolders(parentFolderId).pipe(
        takeUntil(
          this.actions$.pipe(
            ofType(FolderActionTypes.StopLoadSubFolders),
            filter(
              ({ parentFolderId: id }: StopLoadSubFolders) =>
                id === parentFolderId
            )
          )
        ),
        map(
          folders =>
            new LoadSubFoldersSuccess(
              parentFolderId,
              folders.map<FolderStored>(folder => ({
                ...folder,
                loadingStatus: LoadingStatus.Waiting,
                loadingError: null
              }))
            )
        ),
        catchError(err => of(new LoadSubFoldersFailed(parentFolderId, err)))
      )
    )
  );

  @Effect()
  createMainFolder$: Observable<Action> = this.actions$.pipe(
    ofType(FolderActionTypes.CreateMainFolder),
    mergeMap(({ payload }: CreateMainFolder) =>
      this.folderService.createMainFolder(payload).pipe(
        map(
          folder =>
            new CreateMainFolderSuccess({
              ...folder,
              loadingError: null,
              loadingStatus: LoadingStatus.Waiting
            })
        ),
        catchError(err => of(new CreateMainFolderFailed(err)))
      )
    )
  );

  @Effect()
  createSubFolder$: Observable<Action> = this.actions$.pipe(
    ofType(FolderActionTypes.CreateSubFolder),
    mergeMap(({ payload }: CreateSubFolder) =>
      this.folderService.createSubFolder(payload).pipe(
        map(
          folder =>
            new CreateSubFolderSuccess({
              ...folder,
              loadingStatus: LoadingStatus.Waiting,
              loadingError: null
            })
        ),
        catchError(err => of(new CreateSubFolderFailed(err)))
      )
    )
  );

  @Effect()
  updateFolderName$: Observable<Action> = this.actions$.pipe(
    ofType(FolderActionTypes.UpdateFolderName),
    mergeMap(({ payload }: UpdateFolderName) =>
      this.folderService.updateFolderName(payload).pipe(
        map(
          () =>
            new UpdateFolderNameSuccess({
              id: payload.folderId,
              changes: {
                name: payload.name
              }
            })
        ),
        catchError(err => of(new UpdateFolderNameFailed(err)))
      )
    )
  );

  @Effect()
  delete$: Observable<Action> = this.actions$.pipe(
    ofType(FolderActionTypes.DeleteFolder),
    mergeMap(({ id }: DeleteFolder) =>
      this.folderService.deleteFolder(id).pipe(
        map(() => new DeleteFolderSuccess(id)),
        catchError(err => of(new DeleteFolderFailed(err)))
      )
    )
  );
}
