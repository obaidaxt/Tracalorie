import { Update } from '@ngrx/entity';
import { Action } from '@ngrx/store';
import { WorkspacePost } from '../../models/api/workspace.post';
import { FolderStored } from '../../models/stored/folder.stored';
import { WorkspaceStored } from '../../models/stored/workspace.stored';

export enum WorkspaceActionTypes {
  Load = '[Workspace Overview] Load Workspaces',
  StopLoad = '[Workspace Overview] Stop Load Workspaces',
  LoadSuccess = '[API] Load Workspaces Success',
  LoadFailed = '[API] Load Workspaces Failed',
  LoadFolders = '[Workspace] Load Folders',
  StopLoadFolders = '[Workspace] Stop Load Folders',
  LoadFoldersSuccess = '[API] Load Workspace Folders Success',
  LoadFoldersFailed = '[API] Load Workspace Folders Failed',
  Added = '[Websocket] Workspace Added',
  Modified = '[Websocket] Workspace Modified',
  Removed = '[Websocket] Workspace Removed',
  ResetForm = '[Workspace Dialog] Reset Workspace Form',
  Create = '[Workspace Dialog] Create Workspace',
  CreateSuccess = '[API] Create Workspace Success',
  CreateFailed = '[API] Create Workspace Failed',
  Update = '[Workspace Dialog] Update Workspace',
  UpdateSuccess = '[Workspace Dialog] Update Workspace Success',
  UpdateFailed = '[Workspace Dialog] Update Workspace Failed',
  Delete = '[Workspace Overview] Delete Workspace',
  DeleteSuccess = '[API] Delete Workspace Success',
  DeleteFailed = '[API] Delete Workspace Failed'
}

export class LoadWorkspaces implements Action {
  readonly type = WorkspaceActionTypes.Load;
  constructor(public workspaceId?: number, public folderId?: number) {}
}

export class StopLoadWorkspaces implements Action {
  readonly type = WorkspaceActionTypes.StopLoad;
}

export class LoadWorkspacesSuccess implements Action {
  readonly type = WorkspaceActionTypes.LoadSuccess;
  constructor(
    public workspaces: WorkspaceStored[],
    public folders: FolderStored[]
  ) {}
}

export class LoadWorkspacesFailed implements Action {
  readonly type = WorkspaceActionTypes.LoadFailed;
  constructor(public error: string) {}
}

export class LoadWorkspaceFolders implements Action {
  readonly type = WorkspaceActionTypes.LoadFolders;
  constructor(public workspaceId: number) {}
}

export class StopLoadWorkspaceFolders implements Action {
  readonly type = WorkspaceActionTypes.StopLoadFolders;
  constructor(public workspaceId: number) {}
}

export class LoadWorkspaceFoldersSuccess implements Action {
  readonly type = WorkspaceActionTypes.LoadFoldersSuccess;
  constructor(public workspaceId: number, public folders: FolderStored[]) {}
}

export class LoadWorkspaceFoldersFailed implements Action {
  readonly type = WorkspaceActionTypes.LoadFoldersFailed;
  constructor(public workspaceId: number, public error: string) {}
}

export class WorkspaceAdded implements Action {
  readonly type = WorkspaceActionTypes.Added;
  constructor(public workspace: WorkspaceStored) {}
}

export class WorkspaceModified implements Action {
  readonly type = WorkspaceActionTypes.Modified;
  constructor(public payload: Update<WorkspaceStored>) {}
}

export class WorkspaceRemoved implements Action {
  readonly type = WorkspaceActionTypes.Removed;
  constructor(public id: number) {}
}

export class ResetWorkspaceForm implements Action {
  readonly type = WorkspaceActionTypes.ResetForm;
}

export class CreateWorkspace implements Action {
  readonly type = WorkspaceActionTypes.Create;
  constructor(public payload: WorkspacePost) {}
}

export class CreateWorkspaceSuccess implements Action {
  readonly type = WorkspaceActionTypes.CreateSuccess;
  constructor(public workspace: WorkspaceStored) {}
}

export class CreateWorkspaceFailed implements Action {
  readonly type = WorkspaceActionTypes.CreateFailed;
  constructor(public error: string) {}
}

export class UpdateWorkspace implements Action {
  readonly type = WorkspaceActionTypes.Update;
  constructor(public id: number, public payload: WorkspacePost) {}
}

export class UpdateWorkspaceSuccess implements Action {
  readonly type = WorkspaceActionTypes.UpdateSuccess;
  constructor(public payload: Update<WorkspaceStored>) {}
}

export class UpdateWorkspaceFailed implements Action {
  readonly type = WorkspaceActionTypes.UpdateFailed;
  constructor(public error: string) {}
}

export class DeleteWorkspace implements Action {
  readonly type = WorkspaceActionTypes.Delete;
  constructor(public id: number) {}
}

export class DeleteWorkspaceSuccess implements Action {
  readonly type = WorkspaceActionTypes.DeleteSuccess;
  constructor(public id: number) {}
}

export class DeleteWorkspaceFailed implements Action {
  readonly type = WorkspaceActionTypes.DeleteFailed;
  constructor(public error: string) {}
}

export type WorkspaceActions =
  | LoadWorkspaces
  | StopLoadWorkspaces
  | LoadWorkspacesSuccess
  | LoadWorkspacesFailed
  | LoadWorkspaceFolders
  | StopLoadWorkspaceFolders
  | LoadWorkspaceFoldersSuccess
  | LoadWorkspaceFoldersFailed
  | WorkspaceAdded
  | WorkspaceModified
  | WorkspaceRemoved
  | ResetWorkspaceForm
  | CreateWorkspace
  | CreateWorkspaceSuccess
  | CreateWorkspaceFailed
  | UpdateWorkspace
  | UpdateWorkspaceSuccess
  | UpdateWorkspaceFailed
  | DeleteWorkspace
  | DeleteWorkspaceSuccess
  | DeleteWorkspaceFailed;
