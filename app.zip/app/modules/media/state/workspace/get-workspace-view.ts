import { WorkspaceStored } from '../../models/stored/workspace.stored';
import { FolderStored } from '../../models/stored/folder.stored';
import { WorkspaceView } from '../../models/view/workspace.view';
import { FolderView } from '../../models/view/folder.view';

export const getWorkspaceView = (
  workspace: WorkspaceStored,
  folders: FolderStored[]
): WorkspaceView => ({
  ...workspace,
  folders: folders
    .filter(f => f.workspaceId === workspace.id && f.mainFolderId === null)
    .sort((a, b) => a.name.localeCompare(b.name))
    .map(f => getFolderView(f, folders))
});

const getFolderView = (
  folder: FolderStored,
  folders: FolderStored[]
): FolderView => ({
  ...folder,
  subFolders: folders
    .filter(f => f.mainFolderId === folder.id)
    .sort((a, b) => a.name.localeCompare(b.name))
    .map(f => getFolderView(f, folders))
});
