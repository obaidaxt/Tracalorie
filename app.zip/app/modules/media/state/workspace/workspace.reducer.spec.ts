import { workspaceReducer, initialState } from './workspace.reducer';

describe('Workspace Reducer', () => {
  describe('unknown action', () => {
    it('should return the initial state', () => {
      const action = {} as any;

      const result = workspaceReducer(initialState, action);

      expect(result).toBe(initialState);
    });
  });
});
