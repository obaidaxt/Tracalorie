import { LoadingStatus } from '@common/models/loading-status';
import { createEntityAdapter, EntityState } from '@ngrx/entity';
import { WorkspaceStored } from '../../models/stored/workspace.stored';
import { WorkspaceActions, WorkspaceActionTypes } from './workspace.actions';

export interface WorkspaceState extends EntityState<WorkspaceStored> {
  loadingStatus: LoadingStatus;
  loadingError: string;
  formStatus: LoadingStatus;
  formError: string;
}

export const adapter = createEntityAdapter<WorkspaceStored>();

export const initialState: WorkspaceState = adapter.getInitialState({
  loadingStatus: LoadingStatus.Waiting,
  loadingError: null,
  formStatus: LoadingStatus.Waiting,
  formError: null
});

export function workspaceReducer(
  state = initialState,
  action: WorkspaceActions
): WorkspaceState {
  switch (action.type) {
    case WorkspaceActionTypes.Load: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Loading
      };
    }

    case WorkspaceActionTypes.StopLoad: {
      return initialState;
    }

    case WorkspaceActionTypes.LoadSuccess: {
      return adapter.addMany(action.workspaces, {
        ...state,
        loadingStatus: LoadingStatus.Completed
      });
    }

    case WorkspaceActionTypes.LoadFailed: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Failed,
        loadingError: action.error
      };
    }

    case WorkspaceActionTypes.LoadFolders: {
      return adapter.updateOne(
        {
          id: action.workspaceId,
          changes: {
            loadingStatus: LoadingStatus.Loading
          }
        },
        state
      );
    }

    case WorkspaceActionTypes.StopLoadFolders: {
      return adapter.updateOne(
        {
          id: action.workspaceId,
          changes: {
            loadingStatus: LoadingStatus.Waiting,
            loadingError: null
          }
        },
        state
      );
    }

    case WorkspaceActionTypes.LoadFoldersSuccess: {
      return adapter.updateOne(
        {
          id: action.workspaceId,
          changes: {
            loadingStatus: LoadingStatus.Completed
          }
        },
        state
      );
    }

    case WorkspaceActionTypes.LoadFoldersFailed: {
      return adapter.updateOne(
        {
          id: action.workspaceId,
          changes: {
            loadingError: action.error,
            loadingStatus: LoadingStatus.Failed
          }
        },
        state
      );
    }

    case WorkspaceActionTypes.Added: {
      return adapter.addOne(action.workspace, state);
    }

    case WorkspaceActionTypes.Modified: {
      return adapter.updateOne(action.payload, state);
    }

    case WorkspaceActionTypes.Removed: {
      return adapter.removeOne(action.id, state);
    }

    case WorkspaceActionTypes.ResetForm: {
      return {
        ...state,
        formStatus: LoadingStatus.Waiting,
        formError: null
      };
    }

    case WorkspaceActionTypes.Create: {
      return {
        ...state,
        formStatus: LoadingStatus.Loading
      };
    }

    case WorkspaceActionTypes.CreateSuccess: {
      return adapter.addOne(action.workspace, {
        ...state,
        formStatus: LoadingStatus.Completed
      });
    }

    case WorkspaceActionTypes.CreateFailed: {
      return {
        ...state,
        formStatus: LoadingStatus.Failed,
        formError: action.error
      };
    }

    case WorkspaceActionTypes.Update: {
      return {
        ...state,
        formStatus: LoadingStatus.Loading
      };
    }

    case WorkspaceActionTypes.UpdateSuccess: {
      return adapter.updateOne(action.payload, {
        ...state,
        formStatus: LoadingStatus.Completed
      });
    }

    case WorkspaceActionTypes.UpdateFailed: {
      return {
        ...state,
        formStatus: LoadingStatus.Failed,
        formError: action.error
      };
    }

    case WorkspaceActionTypes.DeleteSuccess: {
      return adapter.removeOne(action.id, state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
export const selectLoadingStatus = (state: WorkspaceState) =>
  state.loadingStatus;
export const selectLoadingError = (state: WorkspaceState) => state.loadingError;
export const selectFormStatus = (state: WorkspaceState) => state.formStatus;
export const selectFormError = (state: WorkspaceState) => state.formError;
