import * as fromWorkspace from './workspace.reducer';
import { createSelector } from '@ngrx/store';
import { selectMediaState } from '../media.reducers';
import { selectAllFolders } from '../folder/folder.selectors';
import { WorkspaceView } from '../../models/view/workspace.view';
import { getWorkspaceView } from './get-workspace-view';
import { selectCurrentWorkspaceId } from '@root';

export const selectWorkspaceState = createSelector(
  selectMediaState,
  state => state.workspaces
);

export const selectAllWorkspaces = createSelector(
  selectWorkspaceState,
  fromWorkspace.selectAll
);

export const selectWorkspaceEntities = createSelector(
  selectWorkspaceState,
  fromWorkspace.selectEntities
);

export const selectWorkspaceLoadingStatus = createSelector(
  selectWorkspaceState,
  fromWorkspace.selectLoadingStatus
);

export const selectWorkspaceLoadingError = createSelector(
  selectWorkspaceState,
  fromWorkspace.selectLoadingError
);

export const selectWorkspaceFormStatus = createSelector(
  selectWorkspaceState,
  fromWorkspace.selectFormStatus
);

export const selectWorkspaceFormError = createSelector(
  selectWorkspaceState,
  fromWorkspace.selectFormError
);

export const selectWorkspaceView = createSelector(
  selectAllWorkspaces,
  selectAllFolders,
  (workspaces, folders) =>
    workspaces.map<WorkspaceView>(workspace =>
      getWorkspaceView(workspace, folders)
    )
);

export const selectCurrentWorkspace = createSelector(
  selectWorkspaceEntities,
  selectCurrentWorkspaceId,
  (workspaces, id) => workspaces[id]
);
