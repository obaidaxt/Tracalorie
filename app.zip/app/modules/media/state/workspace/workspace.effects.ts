import { Injectable } from '@angular/core';
import { LoadingStatus } from '@common/models/loading-status';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import {
  catchError,
  filter,
  map,
  mergeMap,
  switchMap,
  takeUntil
} from 'rxjs/operators';
import { FolderStored } from '../../models/stored/folder.stored';
import { WorkspaceStored } from '../../models/stored/workspace.stored';
import { FolderService } from '../../services/folder.service';
import { WorkspaceService } from '../../services/workspace.service';
import {
  CreateWorkspace,
  CreateWorkspaceFailed,
  CreateWorkspaceSuccess,
  DeleteWorkspace,
  DeleteWorkspaceFailed,
  DeleteWorkspaceSuccess,
  LoadWorkspaceFolders,
  LoadWorkspaceFoldersFailed,
  LoadWorkspaceFoldersSuccess,
  LoadWorkspaces,
  LoadWorkspacesFailed,
  LoadWorkspacesSuccess,
  StopLoadWorkspaceFolders,
  UpdateWorkspace,
  UpdateWorkspaceFailed,
  UpdateWorkspaceSuccess,
  WorkspaceActionTypes
} from './workspace.actions';

@Injectable()
export class WorkspaceEffects {
  constructor(
    private actions$: Actions,
    private workspaceService: WorkspaceService,
    private folderService: FolderService
  ) {}

  @Effect()
  load$: Observable<Action> = this.actions$.pipe(
    ofType(WorkspaceActionTypes.Load),
    switchMap(({ workspaceId, folderId }: LoadWorkspaces) =>
      this.workspaceService.getWorkspaces(workspaceId, folderId).pipe(
        takeUntil(this.actions$.pipe(ofType(WorkspaceActionTypes.StopLoad))),
        map(
          ({ workspaces, folders, loadedFolders }) =>
            new LoadWorkspacesSuccess(
              workspaces.map<WorkspaceStored>(workspace => ({
                ...workspace,
                loadingStatus:
                  workspace.id === workspaceId
                    ? LoadingStatus.Completed
                    : LoadingStatus.Waiting,
                loadingError: null
              })),
              folders.map<FolderStored>(folder => ({
                ...folder,
                loadingStatus: loadedFolders.includes(folder.id)
                  ? LoadingStatus.Completed
                  : LoadingStatus.Waiting,
                loadingError: null
              }))
            )
        ),
        catchError(err => of(new LoadWorkspacesFailed(err)))
      )
    )
  );

  @Effect()
  loadFolders$: Observable<Action> = this.actions$.pipe(
    ofType(WorkspaceActionTypes.LoadFolders),
    mergeMap(({ workspaceId }: LoadWorkspaceFolders) =>
      this.folderService.getMainFolders(workspaceId).pipe(
        takeUntil(
          this.actions$.pipe(
            ofType(WorkspaceActionTypes.StopLoadFolders),
            filter(
              ({ workspaceId: id }: StopLoadWorkspaceFolders) =>
                workspaceId === id
            )
          )
        ),
        map(
          folders =>
            new LoadWorkspaceFoldersSuccess(
              workspaceId,
              folders.map<FolderStored>(folder => ({
                ...folder,
                loadingStatus: LoadingStatus.Waiting,
                loadingError: null
              }))
            )
        ),
        catchError(err => of(new LoadWorkspaceFoldersFailed(workspaceId, err)))
      )
    )
  );

  @Effect()
  create$: Observable<Action> = this.actions$.pipe(
    ofType(WorkspaceActionTypes.Create),
    switchMap(({ payload }: CreateWorkspace) =>
      this.workspaceService.createWorkspace(payload).pipe(
        map(
          workspace =>
            new CreateWorkspaceSuccess({
              ...workspace,
              loadingError: null,
              loadingStatus: LoadingStatus.Waiting
            })
        ),
        catchError(err => of(new CreateWorkspaceFailed(err)))
      )
    )
  );

  @Effect()
  update$: Observable<Action> = this.actions$.pipe(
    ofType(WorkspaceActionTypes.Update),
    switchMap(({ id, payload }: UpdateWorkspace) =>
      this.workspaceService.updateWorkspace(id, payload).pipe(
        map(
          workspace =>
            new UpdateWorkspaceSuccess({
              id: workspace.id,
              changes: workspace
            })
        ),
        catchError(err => of(new UpdateWorkspaceFailed(err)))
      )
    )
  );

  @Effect()
  delete$: Observable<Action> = this.actions$.pipe(
    ofType(WorkspaceActionTypes.Delete),
    mergeMap(({ id }: DeleteWorkspace) =>
      this.workspaceService.deleteWorkspace(id).pipe(
        map(() => new DeleteWorkspaceSuccess(id)),
        catchError(err => of(new DeleteWorkspaceFailed(err)))
      )
    )
  );
}
