import { ActionReducerMap, createFeatureSelector } from '@ngrx/store';
import {
  fileUploadReducer,
  FileUploadState
} from './file-upload/file-upload.reducer';
import { folderReducer, FolderState } from './folder/folder.reducer';
import {
  mediaFileReducer,
  MediaFileState
} from './media-file/media-file.reducer';
import {
  WorkspaceState,
  workspaceReducer
} from './workspace/workspace.reducer';

export interface MediaState {
  mediaFiles: MediaFileState;
  fileUploads: FileUploadState;
  folders: FolderState;
  workspaces: WorkspaceState;
}

export const mediaReducers: ActionReducerMap<MediaState> = {
  mediaFiles: mediaFileReducer,
  fileUploads: fileUploadReducer,
  folders: folderReducer,
  workspaces: workspaceReducer
};

export const selectMediaState = createFeatureSelector<MediaState>('media');
