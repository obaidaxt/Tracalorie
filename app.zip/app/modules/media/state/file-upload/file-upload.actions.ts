import { generateId } from '@common/functions/generate-id';
import { Action } from '@ngrx/store';
import { MediaFileStored } from '../../models/stored/media-file.stored';

export enum FileUploadActionTypes {
  Upload = '[Media Form] Upload File',
  UploadProgressed = '[API] Upload File Progresses',
  UploadSuccess = '[API] Upload File Success',
  UploadFailed = '[API] Upload File Failed',
  Download = '[Media Form] Download File',
  DownloadSuccess = '[API] Download File Success',
  DownloadFailed = '[API] Download File Failed',
  Cancel = '[Media Form] Cancel Fileupload',
  Remove = '[Media Form] Remove Fileupload'
}

export class UploadFile implements Action {
  readonly type = FileUploadActionTypes.Upload;
  constructor(
    public file: File,
    public workspaceId: number = null,
    public folderId: number = null,
    public id = generateId()
  ) {}
}

export class UploadFileProgressed implements Action {
  readonly type = FileUploadActionTypes.UploadProgressed;
  constructor(public id: string, public progress: number) {}
}

export class UploadFileSuccess implements Action {
  readonly type = FileUploadActionTypes.UploadSuccess;
  constructor(public id: string, public mediaFile: MediaFileStored) {}
}

export class UploadFileFailed implements Action {
  readonly type = FileUploadActionTypes.UploadFailed;
  constructor(public id: string, public error: string) {}
}

export class DownloadFile implements Action {
  readonly type = FileUploadActionTypes.Download;
  constructor(
    public url: string,
    public workspaceId: number = null,
    public folderId: number = null,
    public id = generateId()
  ) {}
}

export class DownloadFileSuccess implements Action {
  readonly type = FileUploadActionTypes.DownloadSuccess;
  constructor(public id: string, public media: MediaFileStored) {}
}

export class DownloadFileFailed implements Action {
  readonly type = FileUploadActionTypes.DownloadFailed;
  constructor(public id: string, public error: string) {}
}

export class CancelFileUpload implements Action {
  readonly type = FileUploadActionTypes.Cancel;
  constructor(public id: string) {}
}

export class RemoveFileUpload implements Action {
  readonly type = FileUploadActionTypes.Remove;
  constructor(public id: string) {}
}

export type FileUploadActions =
  | UploadFile
  | UploadFileProgressed
  | UploadFileSuccess
  | UploadFileFailed
  | DownloadFile
  | DownloadFileSuccess
  | DownloadFileFailed
  | CancelFileUpload
  | RemoveFileUpload;
