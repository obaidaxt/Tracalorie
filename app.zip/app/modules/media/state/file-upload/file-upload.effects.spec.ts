import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { FileUploadEffects } from './file-upload.effects';

describe('FileUploadEffects', () => {
  let actions$: Observable<any>;
  let effects: FileUploadEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        FileUploadEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(FileUploadEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
