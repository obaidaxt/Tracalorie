import { HttpEventType } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { catchError, filter, map, mergeMap, takeUntil } from 'rxjs/operators';
import { mediaFileApiToStored } from '../../models/mapper/media-file-api-to-stored';
import { MediaService } from '../../services/media.service';
import {
  CancelFileUpload,
  DownloadFile,
  DownloadFileFailed,
  DownloadFileSuccess,
  FileUploadActionTypes,
  RemoveFileUpload,
  UploadFile,
  UploadFileFailed,
  UploadFileProgressed,
  UploadFileSuccess
} from './file-upload.actions';

@Injectable()
export class FileUploadEffects {
  constructor(private actions$: Actions, private mediaService: MediaService) {}

  cancel$ = this.actions$.pipe(
    ofType(FileUploadActionTypes.Cancel, FileUploadActionTypes.Remove),
    map(({ id }: CancelFileUpload | RemoveFileUpload) => id)
  );

  @Effect()
  upload$: Observable<Action> = this.actions$.pipe(
    ofType(FileUploadActionTypes.Upload),
    mergeMap(({ file, id, workspaceId, folderId }: UploadFile) =>
      this.mediaService.uploadMediaFile(file, { workspaceId, folderId }).pipe(
        takeUntil(this.cancel$.pipe(filter(cancelId => cancelId === id))),
        filter(
          event =>
            event.type === HttpEventType.UploadProgress ||
            event.type === HttpEventType.Response
        ),
        map(event => {
          switch (event.type) {
            case HttpEventType.UploadProgress: {
              const progress = (event.loaded / event.total) * 100;
              return new UploadFileProgressed(id, progress);
            }
            case HttpEventType.Response: {
              return new UploadFileSuccess(
                id,
                mediaFileApiToStored(event.body[0])
              );
            }
          }
        }),
        catchError(err => of(new UploadFileFailed(id, err)))
      )
    )
  );

  @Effect()
  download$: Observable<Action> = this.actions$.pipe(
    ofType(FileUploadActionTypes.Download),
    mergeMap(({ id, url, workspaceId, folderId }: DownloadFile) =>
      this.mediaService.downloadMediaFile(url, { workspaceId, folderId }).pipe(
        takeUntil(this.cancel$.pipe(filter(cancelId => cancelId === id))),
        map(media => new DownloadFileSuccess(id, mediaFileApiToStored(media))),
        catchError(err => of(new DownloadFileFailed(id, err)))
      )
    )
  );
}
