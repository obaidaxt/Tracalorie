import * as fromFileUpload from './file-upload.reducer';
import { createSelector } from '@ngrx/store';
import { selectMediaState } from '../media.reducers';

export const selectFileUploadState = createSelector(
  selectMediaState,
  state => state.fileUploads
);

export const selectAllFileUploads = createSelector(
  selectFileUploadState,
  fromFileUpload.selectAll
);
