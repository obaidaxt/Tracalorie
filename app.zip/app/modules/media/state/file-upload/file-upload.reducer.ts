import { createEntityAdapter, EntityState } from '@ngrx/entity';
import { FileUploadStored } from '../../models/stored/file-upload.stored';
import {
  FileUploadActions,
  FileUploadActionTypes
} from './file-upload.actions';
import { LoadingStatus } from '@common/models/loading-status';
import { UploadStatus } from '../../models/stored/upload-status.enum';

export interface FileUploadState extends EntityState<FileUploadStored> {}

export const adapter = createEntityAdapter<FileUploadStored>();

export const initialState: FileUploadState = adapter.getInitialState({});

export function fileUploadReducer(
  state = initialState,
  action: FileUploadActions
): FileUploadState {
  switch (action.type) {
    case FileUploadActionTypes.Upload: {
      return adapter.upsertOne(
        {
          error: null,
          file: action.file,
          id: action.id,
          progress: 0,
          status: UploadStatus.Pending,
          mediaId: null,
          type: 'upload',
          fileName: action.file.name,
          workspaceId: action.workspaceId,
          folderId: action.folderId
        },
        state
      );
    }

    case FileUploadActionTypes.UploadProgressed: {
      return adapter.updateOne(
        {
          id: action.id,
          changes: {
            progress: action.progress,
            status: UploadStatus.Uploading
          }
        },
        state
      );
    }

    case FileUploadActionTypes.UploadSuccess: {
      return adapter.updateOne(
        {
          id: action.id,
          changes: {
            status: UploadStatus.Completed,
            mediaId: action.mediaFile.id,
            fileName: action.mediaFile.fileName
          }
        },
        state
      );
    }

    case FileUploadActionTypes.UploadFailed: {
      return adapter.updateOne(
        {
          id: action.id,
          changes: {
            error: action.error,
            status: UploadStatus.Failed
          }
        },
        state
      );
    }

    case FileUploadActionTypes.Download: {
      const urlSplit = action.url.split('/');
      return adapter.upsertOne(
        {
          id: action.id,
          error: null,
          mediaId: null,
          progress: 0,
          status: UploadStatus.Pending,
          type: 'download',
          url: action.url,
          fileName: urlSplit[urlSplit.length - 1],
          workspaceId: action.workspaceId,
          folderId: action.folderId
        },
        state
      );
    }

    case FileUploadActionTypes.DownloadSuccess: {
      return adapter.updateOne(
        {
          id: action.id,
          changes: {
            status: UploadStatus.Completed,
            mediaId: action.media.id,
            fileName: action.media.fileName
          }
        },
        state
      );
    }

    case FileUploadActionTypes.DownloadFailed: {
      return adapter.updateOne(
        {
          id: action.id,
          changes: {
            status: UploadStatus.Failed,
            error: action.error
          }
        },
        state
      );
    }

    case FileUploadActionTypes.Cancel: {
      return adapter.updateOne(
        {
          id: action.id,
          changes: {
            status: UploadStatus.Cancelled
          }
        },
        state
      );
    }

    case FileUploadActionTypes.Remove: {
      return adapter.removeOne(action.id, state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
