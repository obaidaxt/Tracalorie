import { MediaFileEffects } from './media-file/media-file.effects';
import { FileUploadEffects } from './file-upload/file-upload.effects';
import { FolderEffects } from './folder/folder.effects';
import { WorkspaceEffects } from './workspace/workspace.effects';

export const mediaEffects = [MediaFileEffects, FileUploadEffects, FolderEffects, WorkspaceEffects];
