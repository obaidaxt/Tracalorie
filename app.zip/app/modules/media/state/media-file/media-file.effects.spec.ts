import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { MediaFileEffects } from './media-file.effects';

describe('MediaFileEffects', () => {
  let actions$: Observable<any>;
  let effects: MediaFileEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MediaFileEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(MediaFileEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
