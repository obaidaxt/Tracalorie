import { mediaFileReducer, initialState } from './media-file.reducer';

describe('MediaFile Reducer', () => {
  describe('unknown action', () => {
    it('should return the initial state', () => {
      const action = {} as any;

      const result = mediaFileReducer(initialState, action);

      expect(result).toBe(initialState);
    });
  });
});
