import { Update } from '@ngrx/entity';
import { Action } from '@ngrx/store';
import { MediaFileStored } from '../../models/stored/media-file.stored';
import { MediaFileFilterApi } from '../../models/api/media-file-filter.api';

export enum MediaFileActionTypes {
  Load = '[Media Overview] Load Media Files',
  StopLoad = '[Media Overview] Stop Load Media Files',
  LoadSuccess = '[API] Load Media Files Success',
  LoadFailed = '[API] Load Media Files Failed',
  Added = '[Websocket] Media File Added',
  Modified = '[Websocket] Media File Modified',
  Removed = '[Websocket] Media File Removed'
}

export class LoadMediaFiles implements Action {
  readonly type = MediaFileActionTypes.Load;
  constructor(public filter: MediaFileFilterApi) {}
}

export class StopLoadMediaFiles implements Action {
  readonly type = MediaFileActionTypes.StopLoad;
}

export class LoadMediaFilesSuccess implements Action {
  readonly type = MediaFileActionTypes.LoadSuccess;
  constructor(public files: MediaFileStored[]) {}
}

export class LoadMediaFilesFailed implements Action {
  readonly type = MediaFileActionTypes.LoadFailed;
  constructor(public error: string) {}
}

export class MediaFileAdded implements Action {
  readonly type = MediaFileActionTypes.Added;
  constructor(public file: MediaFileStored) {}
}

export class MediaFileModified implements Action {
  readonly type = MediaFileActionTypes.Modified;
  constructor(public payload: Update<MediaFileStored>) {}
}

export class MediaFileRemoved implements Action {
  readonly type = MediaFileActionTypes.Removed;
  constructor(public id: number) {}
}

export type MediaFileActions =
  | LoadMediaFiles
  | StopLoadMediaFiles
  | LoadMediaFilesSuccess
  | LoadMediaFilesFailed
  | MediaFileAdded
  | MediaFileModified
  | MediaFileRemoved;
