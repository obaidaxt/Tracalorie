import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { catchError, map, switchMap, takeUntil } from 'rxjs/operators';
import { mediaFileApiToStored } from '../../models/mapper/media-file-api-to-stored';
import { MediaService } from '../../services/media.service';
import {
  LoadMediaFiles,
  LoadMediaFilesFailed,
  LoadMediaFilesSuccess,
  MediaFileActionTypes
} from './media-file.actions';

@Injectable()
export class MediaFileEffects {
  constructor(private actions$: Actions, private mediaService: MediaService) {}

  stop$ = this.actions$.pipe(ofType(MediaFileActionTypes.StopLoad));

  @Effect()
  load$: Observable<Action> = this.actions$.pipe(
    ofType(MediaFileActionTypes.Load),
    switchMap(({ filter }: LoadMediaFiles) =>
      this.mediaService.getMediaFiles(filter).pipe(
        takeUntil(this.stop$),
        map(
          files => new LoadMediaFilesSuccess(files.map(mediaFileApiToStored))
        ),
        catchError(err => of(new LoadMediaFilesFailed(err)))
      )
    )
  );
}
