import * as fromMediaFiles from './media-file.reducer';
import { createSelector } from '@ngrx/store';
import { selectMediaState } from '../media.reducers';
import {
  selectCurrentFolderId,
  selectCurrentWorkspaceId,
  selectCurrentGalleryId
} from '@root';

export const selectMediaFileState = createSelector(
  selectMediaState,
  state => state.mediaFiles
);

export const selectAllMediaFiles = createSelector(
  selectMediaFileState,
  fromMediaFiles.selectAll
);

export const selectMediaFileEntities = createSelector(
  selectMediaFileState,
  fromMediaFiles.selectEntities
);

export const selectMediaFileLoadingStatus = createSelector(
  selectMediaFileState,
  fromMediaFiles.selectLoadingStatus
);

export const selectMediaFileLoadingError = createSelector(
  selectMediaFileState,
  fromMediaFiles.selectLoadingError
);

export const selectMediaFileFormStatus = createSelector(
  selectMediaFileState,
  fromMediaFiles.selectFormStatus
);

export const selectMediaFileFormError = createSelector(
  selectMediaFileState,
  fromMediaFiles.selectFormError
);

export const selectCurrentMediaFiles = createSelector(
  selectAllMediaFiles,
  selectCurrentWorkspaceId,
  selectCurrentFolderId,
  (files, workspaceId, folderId) =>
    files
      .filter(
        f => f.workspaceId === workspaceId && f.folderId === (folderId || null)
      )
      .sort((a, b) => a.fileName.localeCompare(b.fileName))
);

export const selectCurrentGalleryFile = createSelector(
  selectCurrentMediaFiles,
  selectCurrentGalleryId,
  (files, id) => files.find(f => f.id === id)
);

export const selectCurrentGalleryIndex = createSelector(
  selectCurrentMediaFiles,
  selectCurrentGalleryId,
  (files, id) => files.findIndex(f => f.id === id)
);

export const selectNextGalleryFile = createSelector(
  selectCurrentMediaFiles,
  selectCurrentGalleryIndex,
  (files, index) => {
    if (index === -1 || files.length < 2) {
      return;
    }
    if (index >= files.length - 1) {
      return files[0];
    }
    return files[index + 1];
  }
);

export const selectPreviousGalleryFile = createSelector(
  selectCurrentMediaFiles,
  selectCurrentGalleryIndex,
  (files, index) => {
    if (index === -1 || files.length < 2) {
      return;
    }
    if (index === 0) {
      return files[files.length - 1];
    }
    return files[index - 1];
  }
);
