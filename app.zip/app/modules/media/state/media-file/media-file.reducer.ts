import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import { MediaFileActions, MediaFileActionTypes } from './media-file.actions';
import { LoadingStatus } from '@common/models/loading-status';
import { MediaFileStored } from '../../models/stored/media-file.stored';
import { UploadFileSuccess, FileUploadActionTypes } from '../file-upload/file-upload.actions';

export interface MediaFileState extends EntityState<MediaFileStored> {
  loadingStatus: LoadingStatus;
  loadingError: string;
  formStatus: LoadingStatus;
  formError: string;
}

export const adapter = createEntityAdapter<MediaFileStored>();

export const initialState: MediaFileState = adapter.getInitialState({
  loadingStatus: LoadingStatus.Waiting,
  loadingError: null,
  formStatus: LoadingStatus.Waiting,
  formError: null
});

export function mediaFileReducer(
  state = initialState,
  action: MediaFileActions | UploadFileSuccess
): MediaFileState {
  switch (action.type) {
    case MediaFileActionTypes.Load: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Loading
      };
    }

    case MediaFileActionTypes.StopLoad: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Waiting
      };
    }

    case MediaFileActionTypes.LoadSuccess: {
      return adapter.addMany(action.files, {
        ...state,
        loadingStatus: LoadingStatus.Completed
      });
    }

    case MediaFileActionTypes.LoadFailed: {
      return {
        ...state,
        loadingStatus: LoadingStatus.Failed,
        loadingError: action.error
      };
    }

    case MediaFileActionTypes.Added: {
      return adapter.addOne(action.file, state);
    }

    case MediaFileActionTypes.Modified: {
      return adapter.updateOne(action.payload, state);
    }

    case MediaFileActionTypes.Removed: {
      return adapter.removeOne(action.id, state);
    }

    case FileUploadActionTypes.UploadSuccess: {
      return adapter.addOne(action.mediaFile, state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal
} = adapter.getSelectors();
export const selectLoadingStatus = (state: MediaFileState) =>
  state.loadingStatus;
export const selectLoadingError = (state: MediaFileState) => state.loadingError;
export const selectFormStatus = (state: MediaFileState) => state.formStatus;
export const selectFormError = (state: MediaFileState) => state.formError;
