import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MediaOverviewComponent } from './containers/media-overview/media-overview.component';
import { MediaComponent } from './media.component';

const routes: Routes = [
  {
    path: '',
    component: MediaComponent,
    children: [
      {
        path: 'private',
        component: MediaOverviewComponent
      },
      {
        path: 'org',
        component: MediaOverviewComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MediaRoutingModule {}
