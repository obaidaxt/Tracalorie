import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { Store } from '@ngrx/store';
import { RootState } from '@root';
import { Observable, Subject } from 'rxjs';
import { FileUploadStored } from '../../models/stored/file-upload.stored';
import { MediaFileStored } from '../../models/stored/media-file.stored';
import {
  CancelFileUpload,
  DownloadFile,
  RemoveFileUpload,
  UploadFile
} from '../../state/file-upload/file-upload.actions';
import { selectAllFileUploads } from '../../state/file-upload/file-upload.selectors';

@Component({
  selector: 'app-upload-dialog',
  templateUrl: './upload-dialog.component.html',
  styleUrls: ['./upload-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UploadDialogComponent implements OnInit, OnDestroy {
  selectedFile: MediaFileStored;
  destroy$ = new Subject<void>();
  upload$: Observable<FileUploadStored[]>;

  constructor(
    private dialogRef: MatDialogRef<UploadDialogComponent>,
    private store: Store<RootState>
  ) {}

  ngOnInit() {
    this.upload$ = this.store.select(selectAllFileUploads);
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  uploadFiles(files: FileList) {
    for (let i = 0; i < files.length; i++) {
      this.store.dispatch(new UploadFile(files[i]));
    }
  }

  downloadFile(url: string) {
    this.store.dispatch(new DownloadFile(url));
  }

  cancelUpload(id: string) {
    this.store.dispatch(new CancelFileUpload(id));
  }

  retry(upload: FileUploadStored) {
    if (upload.type === 'download') {
      this.store.dispatch(
        new DownloadFile(
          upload.url,
          upload.folderId,
          upload.workspaceId,
          upload.id
        )
      );
    } else {
      this.store.dispatch(
        new UploadFile(
          upload.file,
          upload.folderId,
          upload.workspaceId,
          upload.id
        )
      );
    }
  }

  removeUpload(id: string) {
    this.store.dispatch(new RemoveFileUpload(id));
  }
}
