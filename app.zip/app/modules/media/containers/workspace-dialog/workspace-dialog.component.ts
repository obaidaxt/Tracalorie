import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  Inject,
  OnDestroy
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { WorkspaceView } from '../../models/view/workspace.view';
import { Store } from '@ngrx/store';
import { RootState } from '@root';
import { Observable, Subject } from 'rxjs';
import { UserStored } from '@organization/models/stored/user.stored';
import { LoadingStatus } from '@common/models/loading-status';
import { selectAllUsers } from '@organization/state';
import {
  selectWorkspaceFormStatus,
  selectWorkspaceFormError
} from '../../state/workspace/workspace.selectors';
import { takeUntil, filter, take } from 'rxjs/operators';
import {
  ResetWorkspaceForm,
  CreateWorkspace,
  UpdateWorkspace
} from '../../state/workspace/workspace.actions';
import { WorkspacePost } from '../../models/api/workspace.post';

@Component({
  selector: 'app-workspace-dialog',
  templateUrl: './workspace-dialog.component.html',
  styleUrls: ['./workspace-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WorkspaceDialogComponent implements OnInit, OnDestroy {
  users$: Observable<UserStored[]>;
  formStatus$: Observable<LoadingStatus>;
  formError$: Observable<string>;
  destroy$ = new Subject<void>();
  title: string;

  constructor(
    private dialogRef: MatDialogRef<WorkspaceDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public workspace: WorkspaceView,
    private store: Store<RootState>
  ) {}

  ngOnInit() {
    this.users$ = this.store.select(selectAllUsers);
    this.formStatus$ = this.store.select(selectWorkspaceFormStatus);
    this.formError$ = this.store.select(selectWorkspaceFormError);

    this.createTitle();
    this.closeAfterSave();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  closeAfterSave() {
    this.store.dispatch(new ResetWorkspaceForm());
    this.formStatus$
      .pipe(
        takeUntil(this.destroy$),
        filter(status => status === LoadingStatus.Completed),
        take(1)
      )
      .subscribe(() => {
        this.dialogRef.close();
      });
  }

  createTitle() {
    if (this.workspace) {
      this.title = `Bereich ${this.workspace.name} bearbeiten`;
    } else {
      this.title = `Bereich anlegen`;
    }
  }

  handleSubmit(payload: WorkspacePost) {
    if (this.workspace) {
      this.store.dispatch(new UpdateWorkspace(this.workspace.id, payload));
    } else {
      this.store.dispatch(new CreateWorkspace(payload));
    }
  }
}
