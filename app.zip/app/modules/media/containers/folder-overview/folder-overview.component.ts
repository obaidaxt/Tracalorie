import { ChangeDetectionStrategy, Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { selectOwnOrganization } from '@organization/state';
import { RootState } from '@root';
import { FormControl } from 'ngx-strongly-typed-forms';
import { Observable, timer } from 'rxjs';
import { map } from 'rxjs/operators';
import { FolderView } from '../../models/view/folder.view';

@Component({
  selector: 'app-folder-overview',
  templateUrl: './folder-overview.component.html',
  styleUrls: ['./folder-overview.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FolderOverviewComponent implements OnInit {
  organizationName$: Observable<string>;
  privateFolders$: Observable<FolderView[]>;
  orgFolders$: Observable<FolderView[]>;

  showPrivateCreateControl = false;
  showOrgCreateControl = false;
  privateCreateCtrl = new FormControl<string>();
  orgCreateCtrl = new FormControl<string>();

  @ViewChild('privateCreateInput')
  privateCreateInput: ElementRef<HTMLElement>;
  @ViewChild('orgCreateInput')
  orgCreateInput: ElementRef<HTMLElement>;

  constructor(private store: Store<RootState>) {}

  ngOnInit() {
    this.organizationName$ = this.store.pipe(
      select(selectOwnOrganization),
      map(org => org && org.name)
    );
    // this.privateFolders$ = this.store.select(selectPrivateFolders);
    // this.orgFolders$ = this.store.select(selectOrgFolders);

    // this.store.dispatch(new LoadMainFolders());
  }

  showCreateControl(event: Event, isPrivate: boolean) {
    event.preventDefault();
    if (isPrivate) {
      this.showPrivateCreateControl = true;
      timer(0).subscribe(() => {
        this.privateCreateInput.nativeElement.focus();
      });
    } else {
      this.showOrgCreateControl = true;
      timer(0).subscribe(() => {
        this.orgCreateInput.nativeElement.focus();
      });
    }
  }

  handleKeyDown(event: KeyboardEvent, isPrivate: boolean) {
    if (event.key === 'Enter') {
      event.preventDefault();
      // this.store.dispatch(
      //   new CreateMainFolder({
      //     isPrivate,
      //     name: isPrivate ? this.privateCreateCtrl.value : this.orgCreateCtrl.value
      //   })
      // );
      if (isPrivate) {
        this.privateCreateCtrl.setValue(null);
        this.privateCreateInput.nativeElement.blur();
      } else {
        this.orgCreateCtrl.setValue(null);
        this.orgCreateInput.nativeElement.blur();
      }
    }
  }
}
