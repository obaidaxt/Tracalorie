import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkspaceOverviewComponent } from './workspace-overview.component';

describe('WorkspaceOverviewComponent', () => {
  let component: WorkspaceOverviewComponent;
  let fixture: ComponentFixture<WorkspaceOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkspaceOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkspaceOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
