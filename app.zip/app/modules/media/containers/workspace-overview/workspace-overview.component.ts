import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';
import { MatDialog } from '@angular/material';
import { LoadingStatus } from '@common/models/loading-status';
import { Store } from '@ngrx/store';
import {
  RootState,
  selectCurrentFolderId,
  selectCurrentWorkspaceId
} from '@root';
import { ConfirmDialogComponent } from '@shared/components/confirm-dialog/confirm-dialog.component';
import { combineLatest, Observable } from 'rxjs';
import { first } from 'rxjs/operators';
import { MainFolderPost } from '../../models/api/main-folder.post';
import { WorkspaceView } from '../../models/view/workspace.view';
import {
  CreateMainFolder,
  ResetFolderForm
} from '../../state/folder/folder.actions';
import {
  selectFolderFormError,
  selectFolderFormStatus
} from '../../state/folder/folder.selectors';
import {
  DeleteWorkspace,
  LoadWorkspaceFolders,
  LoadWorkspaces,
  StopLoadWorkspaceFolders,
  StopLoadWorkspaces
} from '../../state/workspace/workspace.actions';
import {
  selectWorkspaceLoadingError,
  selectWorkspaceLoadingStatus,
  selectWorkspaceView
} from '../../state/workspace/workspace.selectors';
import { WorkspaceDialogComponent } from '../workspace-dialog/workspace-dialog.component';

@Component({
  selector: 'app-workspace-overview',
  templateUrl: './workspace-overview.component.html',
  styleUrls: ['./workspace-overview.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WorkspaceOverviewComponent implements OnInit, OnDestroy {
  workspaces$: Observable<WorkspaceView[]>;
  loadingStatus$: Observable<LoadingStatus>;
  loadingError$: Observable<string>;
  formStatus$: Observable<LoadingStatus>;
  formError$: Observable<string>;

  constructor(private store: Store<RootState>, private dialog: MatDialog) {}

  ngOnInit() {
    this.workspaces$ = this.store.select(selectWorkspaceView);
    this.loadingStatus$ = this.store.select(selectWorkspaceLoadingStatus);
    this.loadingError$ = this.store.select(selectWorkspaceLoadingError);
    this.formStatus$ = this.store.select(selectFolderFormStatus);
    this.formError$ = this.store.select(selectFolderFormError);

    this.loadWorkspaces();
  }

  ngOnDestroy() {
    this.store.dispatch(new StopLoadWorkspaces());
  }

  loadWorkspaces() {
    combineLatest(
      this.store.select(selectCurrentWorkspaceId),
      this.store.select(selectCurrentFolderId)
    )
      .pipe(first())
      .subscribe(([workspaceId, folderId]) => {
        this.store.dispatch(new LoadWorkspaces(workspaceId, folderId));
      });
  }

  openWorkspaceDialog(workspace?: WorkspaceView) {
    this.dialog.open(WorkspaceDialogComponent, {
      autoFocus: false,
      backdropClass: 'form-dialog-backdrop',
      disableClose: true,
      maxWidth: '97vw',
      data: workspace || null
    });
  }

  loadFolders(workspaceId: number) {
    this.store.dispatch(new LoadWorkspaceFolders(workspaceId));
  }

  stopLoadFolders(workspaceId: number) {
    this.store.dispatch(new StopLoadWorkspaceFolders(workspaceId));
  }

  createFolder(payload: MainFolderPost) {
    this.store.dispatch(new CreateMainFolder(payload));
  }

  resetFolderForm() {
    this.store.dispatch(new ResetFolderForm());
  }

  workspaceTrackByFn(index: number, workspace: WorkspaceView) {
    return workspace.id;
  }

  deleteWorkspace(workspace: WorkspaceView) {
    this.dialog
      .open<ConfirmDialogComponent, string, boolean>(ConfirmDialogComponent, {
        data: `Bist du sicher, dass du den Bereich ${
          workspace.name
        } und alle dazugehörigen Ordner unwiderruflich löschen möchtest?`
      })
      .afterClosed()
      .subscribe(confirmed => {
        if (confirmed) {
          this.store.dispatch(new DeleteWorkspace(workspace.id));
        }
      });
  }
}
