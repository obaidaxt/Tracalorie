import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';
import { LoadingStatus } from '@common/models/loading-status';
import { ResponsiveService } from '@core/services/responsive.service';
import { Store } from '@ngrx/store';
import {
  RootState,
  selectCurrentFileId,
  selectCurrentFolderId,
  selectCurrentWorkspaceId
} from '@root';
import { combineLatest, Observable, Subject } from 'rxjs';
import { filter, takeUntil, tap } from 'rxjs/operators';
import { MediaFileFilterApi } from '../../models/api/media-file-filter.api';
import { MediaFileStored } from '../../models/stored/media-file.stored';
import { FolderPath } from '../../models/view/folder-path';
import { selectFolderPath } from '../../state/folder/folder.selectors';
import {
  LoadMediaFiles,
  StopLoadMediaFiles
} from '../../state/media-file/media-file.actions';
import {
  selectCurrentMediaFiles,
  selectMediaFileLoadingError,
  selectMediaFileLoadingStatus
} from '../../state/media-file/media-file.selectors';
import { WorkspaceStored } from '../../models/stored/workspace.stored';
import {
  selectCurrentWorkspace,
  selectAllWorkspaces
} from '../../state/workspace/workspace.selectors';

@Component({
  selector: 'app-media-overview',
  templateUrl: './media-overview.component.html',
  styleUrls: ['./media-overview.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaOverviewComponent implements OnInit, OnDestroy {
  folderPaths$: Observable<FolderPath[]>;
  files$: Observable<MediaFileStored[]>;
  isMobile$: Observable<boolean>;
  destroy$ = new Subject<void>();
  mediaId$: Observable<number>;
  workspaceId$: Observable<number>;
  activeWorkspace$: Observable<WorkspaceStored>;
  workspaces$: Observable<WorkspaceStored[]>;
  folderId$: Observable<number>;
  loadingStatus$: Observable<LoadingStatus>;
  loadingError$: Observable<string>;

  constructor(
    private responsive: ResponsiveService,
    private store: Store<RootState>
  ) {}

  ngOnInit() {
    this.isMobile$ = this.responsive.isTablet;
    this.mediaId$ = this.store.select(selectCurrentFileId);
    this.workspaceId$ = this.store.select(selectCurrentWorkspaceId);
    this.activeWorkspace$ = this.store.select(selectCurrentWorkspace);
    this.workspaces$ = this.store.select(selectAllWorkspaces);
    this.folderId$ = this.store.select(selectCurrentFolderId);
    this.files$ = this.store.select(selectCurrentMediaFiles);
    this.loadingError$ = this.store.select(selectMediaFileLoadingError);
    this.loadingStatus$ = this.store.select(selectMediaFileLoadingStatus);
    this.folderPaths$ = this.store.select(selectFolderPath);

    combineLatest(this.workspaceId$, this.folderId$)
      .pipe(
        takeUntil(this.destroy$),
        filter(([workspaceId]) => typeof workspaceId === 'number')
      )
      .subscribe(([workspaceId, folderId]) => {
        this.store.dispatch(
          new LoadMediaFiles({
            folderId,
            skip: 0,
            take: 50,
            workspaceId
          })
        );
      });
  }

  ngOnDestroy() {
    this.store.dispatch(new StopLoadMediaFiles());
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadMediaFiles(mediaFilter: MediaFileFilterApi) {
    this.store.dispatch(new LoadMediaFiles(mediaFilter));
  }
}
