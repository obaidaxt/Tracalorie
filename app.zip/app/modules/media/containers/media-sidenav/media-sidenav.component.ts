import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  EventEmitter,
  Output
} from '@angular/core';
import { Store } from '@ngrx/store';
import { RootState } from '@root';
import { Observable } from 'rxjs';
import { selectOwnOrganization } from '@organization/state';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-media-sidenav',
  templateUrl: './media-sidenav.component.html',
  styleUrls: ['./media-sidenav.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaSidenavComponent implements OnInit {
  @Output()
  toggleSidenav = new EventEmitter<boolean>();

  organizationName$: Observable<string>;

  constructor(private store: Store<RootState>) {}

  ngOnInit() {
    this.organizationName$ = this.store
      .select(selectOwnOrganization)
      .pipe(map(org => org && org.name));
  }
}
