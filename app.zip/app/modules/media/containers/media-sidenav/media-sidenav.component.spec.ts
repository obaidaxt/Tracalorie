import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MediaSidenavComponent } from './media-sidenav.component';

describe('MediaSidenavComponent', () => {
  let component: MediaSidenavComponent;
  let fixture: ComponentFixture<MediaSidenavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MediaSidenavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MediaSidenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
