import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { RootState } from '@root';
import { Observable } from 'rxjs';
import { MediaFileStored } from '../../models/stored/media-file.stored';
import {
  selectCurrentGalleryFile,
  selectNextGalleryFile,
  selectPreviousGalleryFile
} from '../../state/media-file/media-file.selectors';

@Component({
  selector: 'app-media-gallery',
  templateUrl: './media-gallery.component.html',
  styleUrls: ['./media-gallery.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaGalleryComponent implements OnInit {
  currentFile$: Observable<MediaFileStored>;
  nextFile$: Observable<MediaFileStored>;
  previousFile$: Observable<MediaFileStored>;

  constructor(private store: Store<RootState>) {}

  ngOnInit() {
    this.currentFile$ = this.store.select(selectCurrentGalleryFile);
    this.nextFile$ = this.store.select(selectNextGalleryFile);
    this.previousFile$ = this.store.select(selectPreviousGalleryFile);
  }

  downloadFile(file: MediaFileStored) {
    // const url = `api/File/${file.url}`;
    // var a = document.createElement('A');
    // a.href = url;
    // a.download = url.substr(url.lastIndexOf('/') + 1);
    // document.body.appendChild(a);
    // a.click();
    // document.body.removeChild(a);
  }
}
