import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  OnDestroy
} from '@angular/core';
import { Store } from '@ngrx/store';
import { RootState, selectCurrentFileId, selectRouterFragment } from '@root';
import { MediaService } from '../../services/media.service';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { takeUntil, filter } from 'rxjs/operators';
import { MediaFileStored } from '../../models/stored/media-file.stored';
import { LoadingStatus } from '@common/models/loading-status';
import { mediaFileApiToStored } from '../../models/mapper/media-file-api-to-stored';

@Component({
  selector: 'app-media-details',
  templateUrl: './media-details.component.html',
  styleUrls: ['./media-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MediaDetailsComponent implements OnInit, OnDestroy {
  fileId$: Observable<number>;
  destroy$ = new Subject<void>();
  details$ = new BehaviorSubject<MediaFileStored>(null);
  status$ = new BehaviorSubject<LoadingStatus>(LoadingStatus.Waiting);
  error$ = new BehaviorSubject<string>(null);
  fragment$: Observable<string>;

  constructor(
    private store: Store<RootState>,
    private mediaService: MediaService
  ) {}

  ngOnInit() {
    this.fileId$ = this.store.select(selectCurrentFileId);
    this.fragment$ = this.store.select(selectRouterFragment);

    this.fileId$
      .pipe(
        takeUntil(this.destroy$),
        filter(id => typeof id === 'number')
      )
      .subscribe(id => {
        this.loadDetails(id);
      });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadDetails(id: number) {
    this.status$.next(LoadingStatus.Loading);
    this.mediaService.getMediaDetails(id).subscribe(
      details => {
        this.details$.next(mediaFileApiToStored(details));
        this.status$.next(LoadingStatus.Completed);
      },
      err => {
        this.error$.next(err);
        this.status$.next(LoadingStatus.Failed);
      }
    );
  }
}
