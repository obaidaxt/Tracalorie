import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { MatDialog } from '@angular/material';
import { LoadingStatus } from '@common/models/loading-status';
import { Store } from '@ngrx/store';
import { RootState } from '@root';
import { ConfirmDialogComponent } from '@shared/components/confirm-dialog/confirm-dialog.component';
import {
  AbstractControl,
  FormControl,
  ValidatorFn
} from 'ngx-strongly-typed-forms';
import { Observable, Subject, timer } from 'rxjs';
import { filter, take, takeUntil } from 'rxjs/operators';
import { FolderView } from '../../models/view/folder.view';
import {
  CreateSubFolder,
  DeleteFolder,
  LoadSubFolders,
  ResetFolderForm,
  StopLoadSubFolders,
  UpdateFolderName
} from '../../state/folder/folder.actions';
import {
  selectFolderFormError,
  selectFolderFormStatus
} from '../../state/folder/folder.selectors';

@Component({
  selector: 'app-folder',
  templateUrl: './folder.component.html',
  styleUrls: ['./folder.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FolderComponent implements OnInit, OnChanges, OnDestroy {
  @Input()
  folder: FolderView;
  @Input()
  sameLevelFolders: FolderView[];

  showCreateControl = false;
  showEditControl = false;
  createCtrl = new FormControl<string>(null, this.validateCreateFolderName());
  editCtrl = new FormControl<string>(null, this.validateEditFolderName());
  formStatus$: Observable<LoadingStatus>;
  formError$: Observable<string>;
  destroy$ = new Subject<void>();

  @ViewChild('createInput')
  createInput: ElementRef<HTMLElement>;
  @ViewChild('editInput')
  editInput: ElementRef<HTMLElement>;

  constructor(private store: Store<RootState>, private dialog: MatDialog) {}

  ngOnInit() {
    this.formStatus$ = this.store.select(selectFolderFormStatus);
    this.formError$ = this.store.select(selectFolderFormError);

    this.formStatus$
      .pipe(
        takeUntil(this.destroy$),
        filter(status => status === LoadingStatus.Completed),
        take(1)
      )
      .subscribe(() => {
        if (this.createCtrl.value) {
          this.createInput.nativeElement.blur();
        }
        if (this.editCtrl.value) {
          this.editInput.nativeElement.blur();
        }
      });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['folder']) {
      this.editCtrl.setValue(this.folder.name, { emitEvent: false });
    }
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadSubFolders() {
    if (this.folder.loadingStatus !== LoadingStatus.Completed) {
      this.store.dispatch(new LoadSubFolders(this.folder.id));
    }
  }

  stopLoadSubFolders() {
    this.store.dispatch(new StopLoadSubFolders(this.folder.id));
  }

  openCreateControl() {
    this.showCreateControl = true;
    if (this.folder.loadingStatus !== LoadingStatus.Completed) {
      this.loadSubFolders();
    }
    timer(0).subscribe(() => {
      this.createInput.nativeElement.focus();
    });
  }

  hideCreateControl() {
    this.showCreateControl = false;
    this.store.dispatch(new ResetFolderForm());
  }

  openEditControl() {
    this.showEditControl = true;
    timer(0).subscribe(() => {
      this.editInput.nativeElement.focus();
    });
  }

  hideEditControl() {
    this.showEditControl = false;
    this.store.dispatch(new ResetFolderForm());
  }

  handleKeyDown(event: KeyboardEvent) {
    switch (event.key) {
      case 'Enter': {
        if (this.createCtrl.invalid) {
          return;
        }
        const name = this.createCtrl.value && this.createCtrl.value.trim();
        if (!name || name.length === 0) {
          return;
        }
        this.store.dispatch(
          new CreateSubFolder({
            mainFolderId: this.folder.id,
            name
          })
        );
        break;
      }
      case 'Escape': {
        event.preventDefault();
        this.createInput.nativeElement.blur();
      }
    }
  }

  handleEditKeyDown(event: KeyboardEvent) {
    switch (event.key) {
      case 'Enter': {
        if (this.editCtrl.invalid) {
          return;
        }
        const name = this.editCtrl.value && this.editCtrl.value.trim();
        if (!name || name.length === 0) {
          return;
        }
        this.store.dispatch(
          new UpdateFolderName({
            folderId: this.folder.id,
            name: this.editCtrl.value
          })
        );
        break;
      }
      case 'Escape': {
        event.preventDefault();
        this.editInput.nativeElement.blur();
      }
    }
  }

  folderTrackByFn(index: number, folder: FolderView) {
    return folder.id;
  }

  private validateEditFolderName(): ValidatorFn<string> {
    return (control: AbstractControl<string>) => {
      if (
        control.value &&
        this.sameLevelFolders.some(
          f =>
            f.id !== this.folder.id &&
            f.name.toLocaleLowerCase() === control.value.toLocaleLowerCase()
        )
      ) {
        return {
          nameInUse: true
        };
      }
      return null;
    };
  }

  deleteFolder() {
    this.dialog
      .open<ConfirmDialogComponent, string, boolean>(ConfirmDialogComponent, {
        data: `Bist du sicher, dass du den Ordner ${
          this.folder.name
        } und alle dazugehörigen Unterordner unwiderruflich löschen möchtest?`
      })
      .afterClosed()
      .subscribe(confirmed => {
        if (confirmed) {
          this.store.dispatch(new DeleteFolder(this.folder.id));
        }
      });
  }

  private validateCreateFolderName(): ValidatorFn<string> {
    return (control: AbstractControl<string>) => {
      if (
        control.value &&
        this.folder.subFolders.some(
          f => f.name.toLocaleLowerCase() === control.value.toLocaleLowerCase()
        )
      ) {
        return {
          nameInUse: true
        };
      }
      return null;
    };
  }
}
