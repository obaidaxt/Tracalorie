import { TagPost } from "./../models/api/tag.post";
import { TagApi } from "./../models/api/tag.api";
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class TagsService {
  constructor(private http: HttpClient) {}

  getTags() {
    return this.http.get<TagApi[]>("api/Tags");
  }

  createTag(payload: TagPost) {
    return this.http.post<TagApi>("api/Tags", payload);
  }
}
