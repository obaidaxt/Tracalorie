import {
  HttpClient,
  HttpHeaders,
  HttpRequest,
  HttpParams
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MediaFileFilterApi } from '../models/api/media-file-filter.api';
import { MediaFileApi } from '../models/api/media-file.api';
import { MediaFilePost } from '../models/api/media-file.post';

@Injectable({
  providedIn: 'root'
})
export class MediaService {
  constructor(private http: HttpClient) {}

  uploadMediaFile(file: File, payload: MediaFilePost) {
    const headers = new HttpHeaders({ enctype: 'multipart/form-data' });
    const formData = new FormData();
    formData.append('files', file);
    const params = new HttpParams({
      fromObject: payload as any
    });
    const req = new HttpRequest('POST', 'api/File/UploadMediaFile', formData, {
      headers: headers,
      reportProgress: true,
      params
    });
    return this.http.request<MediaFileApi[]>(req);
  }

  downloadMediaFile(url: string, params: MediaFilePost) {
    url = encodeURIComponent(url);
    return this.http.get<MediaFileApi>(`api/File/DownloadMediaFile/${url}`, {
      params: params as any
    });
  }

  getMediaFiles(filter: MediaFileFilterApi) {
    return this.http.get<MediaFileApi[]>(`api/File/Media`, {
      params: filter as any
    });
  }

  getMediaDetails(id: number) {
    return this.http.get<MediaFileApi>(`api/File/MediaDetails/${id}`);
  }
}
