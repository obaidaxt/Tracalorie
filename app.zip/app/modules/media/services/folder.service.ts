import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FolderNamePost } from '../models/api/folder-name.post';
import { FolderApi } from '../models/api/folder.api';
import { MainFolderPost } from '../models/api/main-folder.post';
import { SubFolderPost } from '../models/api/sub-folder.post';

@Injectable({
  providedIn: 'root'
})
export class FolderService {
  constructor(private http: HttpClient) {}

  getMainFolders(workspaceId: number) {
    return this.http.get<FolderApi[]>(`api/File/MainFolders/${workspaceId}`);
  }

  getSubFolders(mainFolderId: number) {
    return this.http.get<FolderApi[]>(`api/File/SubFolders/${mainFolderId}`);
  }

  createMainFolder(payload: MainFolderPost) {
    return this.http.post<FolderApi>('api/File/CreateMainFolder', payload);
  }

  createSubFolder(payload: SubFolderPost) {
    return this.http.post<FolderApi>('api/File/CreateSubFolder', payload);
  }

  updateFolderName(payload: FolderNamePost) {
    return this.http.post<void>('api/File/UpdateFolderName', payload);
  }

  deleteFolder(id: number) {
    return this.http.delete<void>(`api/File/Folder/${id}`);
  }
}
