import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WorkspaceApi } from '../models/api/workspace.api';
import { WorkspacePost } from '../models/api/workspace.post';
import { WorkspacesDataApi } from '../models/api/workspaces-data.api';

@Injectable({
  providedIn: 'root'
})
export class WorkspaceService {
  constructor(private http: HttpClient) {}

  getWorkspaces(workspaceId?: number, folderId?: number) {
    return this.http.get<WorkspacesDataApi>('api/File/Workspaces', {
      params: {
        workspaceId,
        folderId
      } as any
    });
  }

  createWorkspace(payload: WorkspacePost) {
    return this.http.post<WorkspaceApi>('api/File/CreateWorkspace', payload);
  }

  updateWorkspace(id: number, payload: WorkspacePost) {
    return this.http.put<WorkspaceApi>(
      `api/File/UpdateWorkspace/${id}`,
      payload
    );
  }

  deleteWorkspace(id: number) {
    return this.http.delete<void>(`api/File/Workspace/${id}`);
  }
}
