import { Component, OnInit, ChangeDetectionStrategy } from "@angular/core";
import { DbMigrationService } from "../../services/db-migration.service";
import { BehaviorSubject } from "rxjs";
import { LoadingStatus } from "../../../../common/models/loading-status";

@Component({
  selector: "app-db-migration",
  templateUrl: "./db-migration.component.html",
  styleUrls: ["./db-migration.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DbMigrationComponent implements OnInit {
  setChatroomsStatus$ = new BehaviorSubject<LoadingStatus>(
    LoadingStatus.Waiting
  );
  setChatroomsError$ = new BehaviorSubject<string>(null);
  setChatroomsResults$ = new BehaviorSubject<{
    projects: number[];
    tasks: number[];
  }>(null);

  constructor(private migrationService: DbMigrationService) {}

  ngOnInit() {}

  setChatrooms() {
    this.setChatroomsStatus$.next(LoadingStatus.Loading);
    this.migrationService.setChatrooms().subscribe(
      results => {
        this.setChatroomsResults$.next(results);
        this.setChatroomsStatus$.next(LoadingStatus.Completed);
      },
      err => {
        this.setChatroomsError$.next(err);
        this.setChatroomsStatus$.next(LoadingStatus.Failed);
      }
    );
  }
}
