import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DbMigrationComponent } from './db-migration.component';

describe('DbMigrationComponent', () => {
  let component: DbMigrationComponent;
  let fixture: ComponentFixture<DbMigrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DbMigrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DbMigrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
