import { Component, OnInit, ChangeDetectionStrategy } from "@angular/core";
import { AdminProjectService } from "../../services/admin-project.service";
import { BehaviorSubject } from "rxjs";
import { LoadingStatus } from "../../../../common/models/loading-status";

@Component({
  selector: "app-project-admin",
  templateUrl: "./project-admin.component.html",
  styleUrls: ["./project-admin.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProjectAdminComponent implements OnInit {
  internIdsStatus$ = new BehaviorSubject<LoadingStatus>(LoadingStatus.Waiting);

  constructor(private projectService: AdminProjectService) {}

  ngOnInit() {}

  setInternProjectIds() {
    this.internIdsStatus$.next(LoadingStatus.Loading);
    this.projectService.setProjectInternIds().subscribe(
      () => {
        this.internIdsStatus$.next(LoadingStatus.Completed);
      },
      err => {
        console.error(err);
        this.internIdsStatus$.next(LoadingStatus.Failed);
      }
    );
  }
}
