import { AdminComponent } from '@admin/admin.component';
import { RouterModule, Routes } from '@angular/router';
import { DbMigrationComponent } from './components/db-migration/db-migration.component';
import { ProjectAdminComponent } from './containers/project-admin/project-admin.component';

const adminRoutes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: 'migration',
        component: DbMigrationComponent
      },
      {
        path: 'projects',
        component: ProjectAdminComponent
      }
    ]
  }
];

export const AdminRouterModule = RouterModule.forChild(adminRoutes);
