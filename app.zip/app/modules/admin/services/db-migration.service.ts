import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DbMigrationService {
  constructor(private http: HttpClient) {}

  setChatrooms() {
    return this.http.get<{ projects: number[]; tasks: number[] }>(
      'api/Admin/Chat/SetChatrooms'
    );
  }
}
