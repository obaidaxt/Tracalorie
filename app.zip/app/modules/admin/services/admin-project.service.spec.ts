import { TestBed, inject } from '@angular/core/testing';

import { AdminProjectService } from './admin-project.service';

describe('AdminProjectService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminProjectService]
    });
  });

  it('should be created', inject([AdminProjectService], (service: AdminProjectService) => {
    expect(service).toBeTruthy();
  }));
});
