import { TestBed, inject } from '@angular/core/testing';

import { DbMigrationService } from './db-migration.service';

describe('DbMigrationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DbMigrationService]
    });
  });

  it('should be created', inject([DbMigrationService], (service: DbMigrationService) => {
    expect(service).toBeTruthy();
  }));
});
