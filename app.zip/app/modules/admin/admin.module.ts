import { AdminRouterModule } from '@admin/admin.routes';
import { NgModule } from '@angular/core';
import { SharedModule } from 'app/shared/shared.module';
import { AdminComponent } from './admin.component';
import { DbMigrationComponent } from './components/db-migration/db-migration.component';
import { ProjectAdminComponent } from './containers/project-admin/project-admin.component';

@NgModule({
  imports: [SharedModule, AdminRouterModule],
  declarations: [AdminComponent, DbMigrationComponent, ProjectAdminComponent],
  providers: [],
  entryComponents: []
})
export class AdminModule {}
