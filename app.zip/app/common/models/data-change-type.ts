export enum DataChangeType {
  Added,
  Modified,
  Removed
}
