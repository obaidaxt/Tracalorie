export enum LoadingStatus {
  Waiting = 'waiting',
  Loading = 'loading',
  Completed = 'completed',
  Failed = 'failed'
}
