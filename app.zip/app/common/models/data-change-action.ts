import { DataChangeType } from './data-change-type';

export interface DataChangeAction<D, I> {
  id: I;
  type: DataChangeType;
  data: D;
}
