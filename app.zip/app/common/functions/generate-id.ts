export const generateId = () =>
  fourRandomChars() + fourRandomChars() + fourRandomChars() + fourRandomChars();

const fourRandomChars = () =>
  Math.floor((1 + Math.random()) * 0x10000)
    .toString(16)
    .substring(1);
