export const getInitials = (name: string): string =>
  name
    .split(' ', 2)
    .filter(s => s.length > 0)
    .map(s => s[0].toLocaleUpperCase())
    .join('');
