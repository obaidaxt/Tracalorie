export interface ProjectFilterParams {
  serviceProvider: number;
  customer: number;
  status: 'critical' | 'on_hold' | 'in_time' | 'today' | 'week' | 'month';
  type: 'intern' | 'cooperations' | 'own' | 'delegated' | 'completed';
  briefings: boolean;
}
