import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { TitleService } from '@core/services/title.service';
import * as fromRoot from '@root';
import { combineLatest } from 'rxjs';
import { IconService } from './core/services/icon.service';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  constructor(
    private iconService: IconService,
    private title: Title,
    private titleService: TitleService,
    private store: Store<fromRoot.RootState>
  ) {}

  ngOnInit(): void {
    this.addIcons();
    this.setTitle();
  }

  setTitle() {
    const intialTitle = this.title.getTitle();
    combineLatest(
      this.store.select(fromRoot.selectPageTitle),
      this.titleService.getNewNotifications()
    ).subscribe(([page, notificationCount]) => {
      let title = intialTitle;
      if (page) {
        title = `${page} - ${title}`;
      }
      if (notificationCount > 0) {
        title = `(${notificationCount}) ${title}`;
      }
      this.title.setTitle(title);
    });
  }

  addIcons() {
    const icons: { name: string; path: string }[] = [
      {
        name: 'Excel Mappe',
        path: 'assets/images/Icons/Microsoft_Excel_2013_logo.svg'
      },
      {
        name: 'user-group',
        path: 'assets/icons/user-group.svg'
      },
      {
        name: 'skull-head',
        path: 'assets/icons/skull-head.svg'
      },
      {
        name: 'letter',
        path: 'assets/icons/letter.svg'
      },
      {
        name: 'reload',
        path: 'assets/icons/reload.svg'
      },
      {
        name: 'pencil',
        path: 'assets/icons/pencil.svg'
      },
      {
        name: 'image-sync',
        path: 'assets/icons/image-sync.svg'
      },
      {
        name: 'align-bottom',
        path: 'assets/icons/align-bottom.svg'
      },
      {
        name: 'delete-circle',
        path: 'assets/icons/delete-circle.svg'
      },
      {
        name: 'paper-plane',
        path: 'assets/icons/paper-plane.svg'
      },
      {
        name: 'menu-hamburger',
        path: 'assets/icons/menu-hamburger.svg'
      },
      {
        name: 'add-circle',
        path: 'assets/icons/add-circle.svg'
      },
      {
        name: 'mailbox',
        path: 'assets/icons/mailbox.svg'
      },
      {
        name: 'add-image',
        path: 'assets/icons/add-image.svg'
      },
      {
        name: 'chats',
        path: 'assets/icons/chats.svg'
      },
      {
        name: 'favorite',
        path: 'assets/icons/favorite.svg'
      },
      {
        name: 'favorite-filled',
        path: 'assets/icons/favorite-filled.svg'
      },
      {
        name: 'loop',
        path: 'assets/icons/loop.svg'
      },
      {
        name: 'repeat',
        path: 'assets/icons/repeat.svg'
      },
      {
        name: 'calendar',
        path: 'assets/icons/calendar.svg'
      },
      {
        name: 'calendar-today',
        path: 'assets/icons/calendar-today.svg'
      },
      {
        name: 'calendar-week',
        path: 'assets/icons/calendar-week.svg'
      },
      {
        name: 'calendar-month',
        path: 'assets/icons/calendar-month.svg'
      },
      {
        name: 'done',
        path: 'assets/icons/done.svg'
      },
      {
        name: 'portfolio-grid',
        path: 'assets/icons/portfolio-grid.svg'
      },
      {
        name: 'sliders',
        path: 'assets/icons/sliders.svg'
      },
      {
        name: 'upload',
        path: 'assets/icons/upload.svg'
      }
    ];
    for (const icon of icons) {
      this.iconService.addSvg(icon.name, icon.path);
    }
  }
}
