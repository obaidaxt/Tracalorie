import {
  HttpErrorResponse,
  HttpHandler,
  HttpHeaderResponse,
  HttpInterceptor,
  HttpProgressEvent,
  HttpRequest,
  HttpResponse,
  HttpSentEvent,
  HttpUserEvent
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthService } from '@core/services/auth.service';
import { throwError } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { catchError, switchMap } from 'rxjs/operators';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private noAuthRequiredUrls = [
    'api/Account/Password/ResetPassword',
    'api/Account/Register/SetFirstPassword',
    'api/Account/Register/Registration',
    'api/Account/Password/SetNewPassword'
  ];

  constructor(private auth: AuthService) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<
    | HttpSentEvent
    | HttpHeaderResponse
    | HttpProgressEvent
    | HttpResponse<any>
    | HttpUserEvent<any>
  > {
    if (
      !req.url.startsWith('api/') ||
      this.noAuthRequiredUrls.includes(req.url)
    ) {
      return next
        .handle(req)
        .pipe(catchError(err => this.handleHttpError(err, req, next)));
    }
    if (this.auth.hasValidAccessToken()) {
      const token = this.auth.getAccessToken();
      const authReq = req.clone({
        headers: req.headers
          .set('Authorization', 'Bearer ' + token)
          .set('Cache-Control', 'no-cache')
      });
      return next
        .handle(authReq)
        .pipe(catchError(error => this.handleHttpError(error, req, next)));
    } else {
      return this.auth.refreshToken().pipe(
        switchMap(token => {
          const authReq = req.clone({
            headers: req.headers.set('Authorization', 'Bearer ' + token)
          });
          return next.handle(authReq);
        }),
        catchError(err => throwError(err))
      );
    }
  }

  private handleHttpError(
    error: any,
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<any> {
    if (error instanceof HttpErrorResponse) {
      switch (error.status) {
        case 0:
        case 504: {
          // Keine Serververbindung
          return throwError('Es konnte keine Verbindung hergestellt werden.');
        }
        case 400: {
          if (typeof error.error === 'string') {
            return throwError(error.error);
          } else if (typeof error.error === 'object') {
            if (error.error.message) {
              return throwError(error.error.message);
            } else if (error.error.error_description) {
              return throwError(error.error.error_description);
            }
          }
          break;
        }
        case 401: {
          return this.auth.refreshToken().pipe(
            switchMap(newToken => {
              const repeatAuthReq = req.clone({
                headers: req.headers.set('Authorization', 'Bearer ' + newToken)
              });
              return next.handle(repeatAuthReq);
            }),
            catchError(err => throwError(err))
          );
        }
        case 403: {
          return throwError('Fehlende Berechtigung.');
        }
        case 404: {
          return throwError('Die Funktion ist nicht verfügbar.');
        }
        case 500: {
          return throwError('Fehler beim Verarbeiten der Anfrage.');
        }
      }
    }
    return throwError('Unbekannter Fehler.');
  }
}
