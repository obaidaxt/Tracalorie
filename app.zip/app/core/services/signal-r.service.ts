import { Injectable } from '@angular/core';
import {
  HubConnection,
  HubConnectionBuilder,
  IStreamResult
} from '@aspnet/signalr';
import { AuthService } from '@core/services/auth.service';
import { environment } from 'environments/environment';
import { of } from 'rxjs';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { timer } from 'rxjs/observable/timer';
import {
  catchError,
  debounceTime,
  filter,
  first,
  switchMap
} from 'rxjs/operators';
import { DataChangeAction } from '../../common/models/data-change-action';

@Injectable()
export class SignalRService {
  private connectionBuilder: HubConnectionBuilder;
  private connection: HubConnection;
  private status$ = new BehaviorSubject<'open' | 'closed'>('closed');

  constructor(private auth: AuthService) {}

  startConnection() {
    const token = this.auth.getAccessToken();
    const baseUrl = environment.baseUrl;
    this.connectionBuilder = new HubConnectionBuilder().withUrl(
      `${baseUrl}/dashboardHub?access_token=${token}`
    );
    this.connect();
  }

  private connect() {
    this.connection = this.connectionBuilder.build();
    this.connection
      .start()
      .then(() => {
        this.status$.next('open');
        this.connection.onclose(err => {
          this.status$.next('closed');
          timer(10000).subscribe(() => {
            this.connect();
          });
        });
      })
      .catch((err: Error) => {
        this.status$.next('closed');
        if (err.message === 'Unauthorized') {
          this.auth.refreshToken().subscribe(
            token => {
              const baseUrl = environment.baseUrl;
              this.connectionBuilder.withUrl(
                `${baseUrl}/dashboardHub?access_token=${token}`
              );
              this.connect();
            },
            () => {
              this.auth.getNewToken().subscribe(token => {
                const baseUrl = environment.baseUrl;
                this.connectionBuilder.withUrl(
                  `${baseUrl}/dashboardHub?access_token=${token}`
                );
                this.connect();
              });
            }
          );
        } else {
          timer(10000).subscribe(() => {
            this.connect();
          });
        }
      });
  }

  disconnect() {
    this.connection.stop();
    this.status$.next('closed');
  }

  listenFor<T>(name: string) {
    return this.status$.pipe(
      filter(status => status === 'open'),
      switchMap(() => {
        return new Observable<T>(obs => {
          this.connection.on(name, (data: T) => {
            obs.next(data);
          });
          // Wird hoffentlich beim unsubscriben ausgeführt
          return () => {
            // TODO: testen
            this.connection.off(name);
          };
        });
      })
    );
  }

  getData<T>(name: string, ...args: any[]): Observable<T> {
    return this.status$.pipe(
      filter(status => status === 'open'),
      switchMap(() =>
        this.asObservable(this.connection.stream<T>(name, ...args))
      )
    );
  }

  getChanges<D, I>(name: string, ...args: any[]) {
    return this.getData<DataChangeAction<D, I>>(name, ...args);
  }

  // wandelt das Observable von SignalR in ein rxjs Observable um
  private asObservable<T>(stream: IStreamResult<T>) {
    return new Observable<T>(observer => {
      const sub = stream.subscribe(observer);
      // unsubscribe muss mit der dispose methode überschrieben werden (könnte evt. probleme machen)
      // damit wird dem server vermittelt, dass er keine daten mehr an den observer senden muss
      observer.unsubscribe = () => {
        if (observer.closed) {
          return;
        }
        observer.closed = true;
        this.status$
          .pipe(
            debounceTime(10),
            first(),
            filter(status => status === 'open')
          )
          .subscribe(() => {
            sub.dispose();
          });
      };
    }).pipe(
      catchError(err => {
        console.log(err);
        return of(null);
      }),
      filter(data => !!data)
    );
  }
}
