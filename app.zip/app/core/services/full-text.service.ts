import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { SearchResult } from '../../modules/search/models/api/search-result';
import { SearchResultType } from '../../modules/search/models/api/search-result-type';
import { SearchResultView } from '@search/models/view/search-result-view';
import { Observable } from 'rxjs';

@Injectable()
export class FullTextService {
  constructor(private http: HttpClient) {}

  searchText(text: string, types: SearchResultType[], skip = 0, take = 10): Observable<SearchResultView[]> {
    return this.http.get<SearchResult[]>(`api/Search/${text}/${skip}/${take}`, { params: { types: types.join(',') } }).pipe(
      map(results => {
        return results.map(result => {
          let params = {};
          let target = '_self';
          let routerLink = '';
          let fragment = '';
          switch (result.type) {
            case SearchResultType.Correction: {
              params = { taskId: undefined, projectId: result.refId, mailtaskId: undefined };
              routerLink = '/overview/projects';
              fragment = 'korrekturen';
              break;
            }
            case SearchResultType.Chat: {
              params = { taskId: undefined, projectId: result.refId, mailtaskId: undefined };
              routerLink = '/overview/projects';
              fragment = 'chat';
              break;
            }
            case SearchResultType.Briefing:
            case SearchResultType.Layoutversion:
            case SearchResultType.Project: {
              params = { taskId: undefined, projectId: result.refId, mailtaskId: undefined };
              routerLink = '/overview/projects';
              break;
            }
            case SearchResultType.File: {
              target = '_blank';
              break;
            }
            case SearchResultType.Task: {
              params = { taskId: result.refId, projectId: undefined, mailtaskId: undefined };
              routerLink = '/overview/tasks';
              break;
            }
            case SearchResultType.Mailtask: {
              params = { taskId: undefined, projectId: undefined, mailtaskId: result.refId };
              routerLink = '/overview/mail2task';
              break;
            }
          }
          return <SearchResultView>{
            ...result,
            params,
            target,
            routerLink,
            fragment
          };
        });
      })
    );
  }
}
