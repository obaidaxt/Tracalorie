import { Injectable } from "@angular/core";
import { Http, Headers } from "@angular/http";

@Injectable()
export class ShareAuthService {
  constructor(private http: Http) {}

  authenticate(code: string) {
    // TODO:
    return new Promise((resolve, reject) => {
      const search = new URLSearchParams();
      search.set("grant_type", "password");
      search.set("client_id", "clientid");
      search.set("scope", "scope");
      search.set("username", " ");
      search.set("password", " ");
      search.set("code", code);

      if ("clientsecret") {
        search.set("client_secret", "clientsecret");
      }

      const headers = new Headers();
      headers.set("Content-Type", "application/x-www-form-urlencoded");

      const params = search.toString();

      this.http
        .post("endpoint", params, { headers })
        .map(r => r.json())
        .subscribe(
          tokenResponse => {
            localStorage.setItem("access_token", tokenResponse.access_token);

            if (tokenResponse.expires_in) {
              const expiresInMilliSeconds = tokenResponse.expires_in * 1000;
              const now = new Date();
              const expiresAt = now.getTime() + expiresInMilliSeconds;
              localStorage.setItem("expires_at", "" + expiresAt);
            }

            if (tokenResponse.refresh_token) {
              localStorage.setItem(
                "refresh_token",
                tokenResponse.refresh_token
              );
            }

            resolve(tokenResponse);
          },
          err => {
            console.error("Error performing password flow", err);
            reject(err);
          }
        );
    });
  }
}
