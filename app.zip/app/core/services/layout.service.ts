import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs/Observable';

@Injectable({
  providedIn: 'root'
})
export class LayoutService {
  private sidenavState$ = new Subject<boolean>();

  constructor() {}

  openSidenav(state: boolean) {
    this.sidenavState$.next(state);
  }

  getSidenavOpened(): Observable<boolean> {
    return this.sidenavState$.asObservable();
  }
}
