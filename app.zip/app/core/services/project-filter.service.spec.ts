import { TestBed, inject } from '@angular/core/testing';

import { ProjectFilterService } from '@project/services/project-filter.service';

describe('ProjectFilterService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProjectFilterService]
    });
  });

  it('should be created', inject([ProjectFilterService], (service: ProjectFilterService) => {
    expect(service).toBeTruthy();
  }));
});
