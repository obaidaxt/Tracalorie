import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ResponsiveService {
  mobileBreakpoint = 700;
  tabletBreakpoint = 1400;

  get isMobile() {
    return this.windowSize$.pipe(map(size => size.width <= this.mobileBreakpoint));
  }

  get isTablet() {
    return this.windowSize$.pipe(map(size => size.width <= this.tabletBreakpoint));
  }

  get isDesktop() {
    return this.windowSize$.pipe(map(size => size.width > this.tabletBreakpoint));
  }

  get isFirefox() {
    return navigator.userAgent.toLowerCase().includes('firefox');
  }

  private windowSize$ = new BehaviorSubject<{ width: number; height: number }>({
    width: 0,
    height: 0
  });

  constructor() {
    this.setEvents();
  }

  private setEvents() {
    this.setSize();
    window.addEventListener('resize', event => {
      this.setSize();
    });
  }

  private setSize() {
    this.windowSize$.next({
      width: window.innerWidth,
      height: window.innerHeight
    });
  }

  getWindowWidth() {
    return this.windowSize$.pipe(map(size => size.width));
  }
}
