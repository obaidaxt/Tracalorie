import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AccountApi } from '../../modules/account/models/api/account.api';

@Injectable({
  providedIn: 'root'
})
export class ProtectedService {
  constructor(private http: HttpClient) {}

  loadAccount(): Observable<AccountApi> {
    return this.http.get<AccountApi>('api/Data/Account');
  }
}
