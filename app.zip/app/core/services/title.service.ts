import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TitleService {
  private newNotifications$ = new BehaviorSubject<number>(0);

  constructor() {}

  getNewNotifications() {
    return this.newNotifications$.asObservable();
  }

  setNewNotifications(value: number) {
    this.newNotifications$.next(value);
  }
}
