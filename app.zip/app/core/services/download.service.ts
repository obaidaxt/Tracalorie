import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import * as FileSaver from "file-saver";

@Injectable()
export class DownloadService {
  constructor(private http: HttpClient) {}

  getProjectPdf(id: number, name: string) {
    return this.http
      .get(`api/Pdf/Projekt/${id}`, {
        headers: new HttpHeaders({ Accept: "application/pdf" }),
        responseType: "blob"
      })
      .map(res => {
        FileSaver.saveAs(res, name);
      });
  }

  getProjectListPdf(filter: any) {
    return this.http
      .post(`api/Pdf/Projektliste`, filter, {
        headers: new HttpHeaders({ Accept: "application/pdf" }),
        responseType: "blob"
      })
      .map(res => {
        FileSaver.saveAs(res, "Projektliste");
      });
  }

  getProjectCsv(filter: any) {
    return this.http.post('api/Project/Excel', filter, {
      headers: new HttpHeaders({ Accept: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }),
      responseType: "blob"
    })
    .map(res => {
      FileSaver.saveAs(res, "Projektliste");
    });
  }
}
