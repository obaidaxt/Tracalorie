import { TestBed, inject } from '@angular/core/testing';

import { ShareAuthService } from './share-auth.service';

describe('ShareAuthService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ShareAuthService]
    });
  });

  it('should be created', inject([ShareAuthService], (service: ShareAuthService) => {
    expect(service).toBeTruthy();
  }));
});
