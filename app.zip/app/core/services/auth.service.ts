import { Injectable, Injector } from '@angular/core';
import { environment } from 'environments/environment';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import {
  tap,
  map,
  switchMap,
  filter,
  first,
  withLatestFrom
} from 'rxjs/operators';
import {
  Router,
  RouterStateSnapshot,
  ActivatedRoute,
  RouterState
} from '@angular/router';
import { throwError, BehaviorSubject } from 'rxjs';
import { LoadingStatus } from '../../common/models/loading-status';

interface TokenResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private refreshStatus$ = new BehaviorSubject<LoadingStatus>(
    LoadingStatus.Waiting
  );
  private redirect: string;
  private baseUrl = environment.baseUrl;

  get http() {
    const http = this.injector.get(HttpClient);
    return http;
  }

  constructor(private injector: Injector, private router: Router) {}

  login(username: string, password: string, rememberMe: boolean) {
    let headers = new HttpHeaders();
    const params = new HttpParams()
      .set('grant_type', 'password')
      .set('client_id', 'AngularApp')
      .set('scope', 'profile email offline_access');
    (params as any) +=
      '&username=' +
      encodeURIComponent(username) +
      '&password=' +
      encodeURIComponent(password);

    headers = headers.set('Content-Type', 'application/x-www-form-urlencoded');

    return this.http
      .post<TokenResponse>(`${this.baseUrl}/connect/token`, params, {
        headers: headers
      })
      .pipe(
        tap(tokenResponse => {
          this.storeToken(
            tokenResponse.access_token,
            tokenResponse.refresh_token,
            tokenResponse.expires_in,
            rememberMe
          );
        })
      );
  }

  storeToken(
    accessToken: string,
    refreshToken: string,
    expiresIn: number,
    rememberMe: boolean
  ) {
    localStorage.setItem('access_token', accessToken);
    localStorage.setItem(
      'access_token_stored_at',
      Date.now()
        .valueOf()
        .toString()
    );
    if (refreshToken && rememberMe) {
      localStorage.setItem('refresh_token', refreshToken);
    }
    if (typeof expiresIn === 'number') {
      localStorage.setItem('expires_in', (expiresIn * 1000).toString());
    }
  }

  logout(returnUrl?: string) {
    localStorage.removeItem('access_token');
    localStorage.removeItem('access_token_stored_at');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('expires_in');
    this.router.navigate(['/public'], {
      queryParams: {
        returnUrl
      }
    });
  }

  hasValidAccessToken() {
    const expiresIn = localStorage.getItem('expires_in');
    const storeTime = localStorage.getItem('access_token_stored_at');

    if (!expiresIn || !storeTime) {
      return false;
    }
    const timeToExpire = parseInt(expiresIn, 10);
    const storedAt = parseInt(storeTime, 10);
    const currentTime = Date.now().valueOf();
    return timeToExpire > currentTime - storedAt;
  }

  refreshToken() {
    return this.refreshStatus$.pipe(
      tap(status => {
        if (status === LoadingStatus.Waiting) {
          this.refreshStatus$.next(LoadingStatus.Loading);
          const refreshToken = localStorage.getItem('refresh_token');
          if (!refreshToken) {
            this.logout(this.router.routerState.snapshot.url);
            this.refreshStatus$.next(LoadingStatus.Failed);
            this.refreshStatus$.next(LoadingStatus.Waiting);
            return;
          }
          const params = new HttpParams()
            .set('grant_type', 'refresh_token')
            .set('client_id', 'AngularApp')
            .set('scope', 'profile email offline_access')
            .set('refresh_token', refreshToken);
          const headers = new HttpHeaders().set(
            'Content-Type',
            'application/x-www-form-urlencoded'
          );
          this.http
            .post<TokenResponse>(`${this.baseUrl}/connect/token`, params, {
              headers: headers
            })
            .pipe(
              tap(tokenResponse => {
                this.storeToken(
                  tokenResponse.access_token,
                  tokenResponse.refresh_token,
                  tokenResponse.expires_in,
                  true
                );
              }),
              map(res => res.access_token)
            )
            .subscribe(
              () => {
                this.refreshStatus$.next(LoadingStatus.Completed);
                this.refreshStatus$.next(LoadingStatus.Waiting);
              },
              err => {
                // TODO: Nur bei 401 redirecten
                this.logout(this.router.routerState.snapshot.url);
                this.refreshStatus$.next(LoadingStatus.Failed);
                this.refreshStatus$.next(LoadingStatus.Waiting);
              }
            );
        }
      }),
      filter(
        status =>
          status === LoadingStatus.Completed || status === LoadingStatus.Failed
      ),
      first(),
      map(status => {
        if (status === LoadingStatus.Completed) {
          return this.getAccessToken();
        } else {
          throw Error('Fehler beim Tokenrefresh');
        }
      })
    );
  }

  getAccessToken() {
    const token = localStorage.getItem('access_token');
    return token;
  }

  getNewToken() {
    return this.refreshStatus$.pipe(
      filter(status => status === LoadingStatus.Completed),
      first(),
      map(() => this.getAccessToken())
    );
  }
}
