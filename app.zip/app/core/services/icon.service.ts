import { Injectable } from '@angular/core';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';

@Injectable()
export class IconService {
  constructor(
    private iconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer
  ) {}

  addSvg(name: string, path: string) {
    this.iconRegistry.addSvgIcon(name, this.domSanitizer.bypassSecurityTrustResourceUrl(path));
  }

  addFileExtIcon(ext: string) {
    this.addSvg(`ext-${ext}`, `assets/icons/file/${ext}.svg`);
  }
}
