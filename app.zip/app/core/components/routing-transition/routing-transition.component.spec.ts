import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoutingTransitionComponent } from './routing-transition.component';

describe('RoutingTransitionComponent', () => {
  let component: RoutingTransitionComponent;
  let fixture: ComponentFixture<RoutingTransitionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoutingTransitionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoutingTransitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
