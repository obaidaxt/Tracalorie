import { Component, OnInit, ChangeDetectionStrategy } from "@angular/core";
import { Router, NavigationStart, NavigationEnd } from "@angular/router";
import { BehaviorSubject } from "rxjs";

@Component({
  selector: "app-routing-transition",
  templateUrl: "./routing-transition.component.html",
  styleUrls: ["./routing-transition.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RoutingTransitionComponent implements OnInit {
  showTransition$ = new BehaviorSubject<boolean>(false);

  constructor(private router: Router) {}

  ngOnInit() {
    this.handleRouterEvents();
  }

  handleRouterEvents() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.showTransition$.next(true);
      } else if (event instanceof NavigationEnd) {
        this.showTransition$.next(false);
      }
    });
  }
}
