import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot
} from '@angular/router';
import { SignalRService } from '@core/services/signal-r.service';
import { Store } from '@ngrx/store';
import * as fromRoot from 'app/store';
import { map, tap } from 'rxjs/operators';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private store: Store<fromRoot.RootState>,
    private signalR: SignalRService
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (
      !localStorage.getItem('access_token') &&
      !localStorage.getItem('refresh_token')
    ) {
      this.router.navigate(['/public'], {
        queryParams: {
          returnUrl: state.url
        }
      });
      return false;
    }
    return true;
  }
}
