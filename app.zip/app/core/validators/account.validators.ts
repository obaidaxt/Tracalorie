import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { invalidDomains } from '@core/validators/invalidDomains';
import { Observable, timer } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AccountValidators {
  private invalidDomainRegex: RegExp;

  constructor(private http: HttpClient) {
    this.createInvalidDomainRegex();
  }

  private createInvalidDomainRegex() {
    this.invalidDomainRegex = new RegExp(
      `^[a-zA-Z0-9_.+-]+@(?:(?:[a-zA-Z0-9-]+\\.)?[a-zA-Z]+\\.)?(${invalidDomains.join(
        '|'
      )})$`
    );
  }

  matchEmail(control: AbstractControl): ValidationErrors | null {
    const emailControl = control.get('email');
    const confirmEmailControl = control.get('confirmEmail');
    if (
      emailControl.dirty &&
      !emailControl.pristine &&
      confirmEmailControl.value !== emailControl.value
    ) {
      confirmEmailControl.setErrors({
        matchEmail: true
      });
      return {
        matchEmail: true
      };
    }
    return null;
  }

  oldPassword(control: AbstractControl): ValidationErrors | null {
    const oldPassword = control.get('oldPassword');
    const password = control.get('password');
    if (password.dirty && !password.errors && !oldPassword.value) {
      oldPassword.setErrors({
        oldPassword: true
      });
      return {
        oldPassword: true
      };
    }
    return null;
  }

  matchPassword(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');
    if (
      password.dirty &&
      !password.errors &&
      password.value !== confirmPassword.value
    ) {
      confirmPassword.setErrors({
        matchPassword: true
      });
      return {
        matchPassword: true
      };
    }
    return null;
  }

  checkInvalidDomain(): (control: AbstractControl) => ValidationErrors | null {
    return (control: AbstractControl) => {
      if (
        control.dirty &&
        !control.pristine &&
        this.invalidDomainRegex.test(control.value)
      ) {
        control.setErrors({
          invalidEmailDomain: true
        });
        return {
          invalidEmailDomain: true
        };
      }
      return null;
    };
  }

  checkEmailAvailable(): (
    control: AbstractControl
  ) => Observable<ValidationErrors | null> {
    return (control: AbstractControl) => {
      return timer(500).pipe(
        switchMap(() =>
          this.http
            .get<boolean>(`api/Account/Email/CheckEmail/${control.value}`)
            .pipe(map(available => (available ? null : { inUse: true })))
        )
      );
    };
  }
}
