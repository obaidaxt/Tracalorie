import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { AuthInterceptor } from '@core/http/auth.interceptor';
import { FullTextService } from 'app/core/services/full-text.service';
import { SignalRService } from 'app/core/services/signal-r.service';
import { AccountValidators } from 'app/core/validators/account.validators';
import { SharedModule } from 'app/shared/shared.module';
import { RoutingTransitionComponent } from './components/routing-transition/routing-transition.component';
import { AuthGuard } from './guards/auth.guard';
import { DownloadService } from './services/download.service';
import { IconService } from './services/icon.service';
import { ShareAuthService } from './services/share-auth.service';

@NgModule({
  declarations: [RoutingTransitionComponent],
  imports: [SharedModule],
  exports: [RoutingTransitionComponent],
  providers: [
    ShareAuthService,
    AuthGuard,
    AccountValidators,
    SignalRService,
    DownloadService,
    FullTextService,
    IconService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ]
})
export class CoreModule {}
